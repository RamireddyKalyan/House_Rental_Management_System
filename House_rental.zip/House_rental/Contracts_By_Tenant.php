<!DOCTYPE html>
<head>
<style>

 table,th{
        border-color:blue;
        border:2px solid black;
        border-collapse: collapse;
    }

th,td{
    padding:20px;
}

   tr:nth-child(even){ 
  background-color:#eee;
  }

  tr:nth-child(odd){
  background-color:#fff;
  }

      th{
        background-color: rgb(209, 186, 214);
     }

    .button {
        background-color: skyblue;
        border: 2px solid black;
        padding: 8px 8px;
        text-align: center;
        text-decoration: none;
        color:red;
        width:170px;
        display: inline-block;
        font-size:20px;
      }


</style>
</head>
<body>
<?php
session_start();
include ('Tenent_View_prev.php');
 /*Connect to mysql server*/ 
if(isset($_SESSION['IS_AUTHENTICATED'])){
   
$link = mysqli_connect('localhost', 'root', '', 'house_rent');  

/*Check link to the mysql server*/ 
if(!$link)
{ 
die('Failed to connect to server: ');
} 
$Name=$_SESSION['Uname'];
 /*Create query*/ 
$qry = "SELECT  HOUSE_NO,USER_NAME_S,USER_NAME_T,RENT_OR_SALE,NO_OF_DAYS,RECEIVE,AMOUNT_PAID FROM contracts WHERE USER_NAME_T='$Name'"; 

/*Execute query*/ 
$result = mysqli_query($link, $qry);
if(mysqli_num_rows($result)){
echo '<center><h1>The Contracts Between Sellers and You are - </h1></center>';

 /*Draw the table for Players*/ 
echo '<center><table class="H" border="5"> 
<tr>
 <th> HOUSE NUMBER </th> 
 <th>USER NAME OF SELLER</th>
 <th>USER NAME OF TENENT</th>
 <th>RENT/SALE</th>
 <th>NO OF DAYS FOR RENT</th>
 <th>AMOUNT PAID/NOT</th>
 <th>AMOUNT TO BE PAID</th>
';

/*Show the rows in the fetched result set one by one*/ 
while ($row = mysqli_fetch_assoc($result))
{ 

echo '<tr> 
<td>'.$row['HOUSE_NO'].'</td>
<td>'.$row['USER_NAME_S'].'</td>
<td>'.$row['USER_NAME_T'].'</td> 
<td>'.$row['RENT_OR_SALE'].'</td>
<td>'.$row['NO_OF_DAYS'].'</td>
<td>'.$row['RECEIVE'].'</td>
<td>'.$row['AMOUNT_PAID'].'</td>
</tr>';
}
echo '</table></center>';
}
else{
  echo '<center><h1>No contacts have been made till now </h1></center>';
}
 }else{
  echo '<center><h1>You are not able to view this content </h1></center>';
 }
?>

</body>
</html>
