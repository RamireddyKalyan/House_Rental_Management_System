<!DOCTYPE html>
<html lang="en">
<head>
    <style>
        h1
        {
            color:black;
            text-align:center;
            padding:100px;
            padding-bottom:20px;
        }
        a
        {
            text-align:center;
            text-decoration:none;
            font-size:25px;
            padding-left:650px;
            padding-bottom:20px;
        }
        </style>
</head>
<?php 
session_start();

if($_POST['log']=='Login'){
$Name = $_POST['Uname']; 
$Password = $_POST['Pass'];
$Role=$_POST['Role']; 
if ($Name && $Password && $Role){
//Connect to mysql server 
$link = mysqli_connect('localhost', 'root', '','house_rent'); 
//Check link to the mysql server 
if(!$link) { 
die('Failed to connect to server: '); 
} 
//Create query (if you have a Logins table the you can select login id and password from there)
$qry="SELECT * FROM user_account WHERE USER_NAME = '$Name'"; 
//Execute query 
$result=mysqli_query($link, $qry); 

$row=mysqli_fetch_assoc($result);

if($row["USER_NAME"]==$Name && $row["PASSWORD"]==$Password && $row["ROLE"]==$Role)
{
    $_SESSION['Uname']=$Name;
    $_SESSION['IS_AUTHENTICATED']=1;
    if($Role=='Buyer')
    {
        include('Tenent_View.php');
    }
    if($Role=='Seller')
    {
        include('Seller_View.php');
    }
    if($Role=='Admin')
    {
        include('Admin_View.php');
       
    }
   
}
else
 {
    echo '<script>
    window.alert("Invalid Credentials ");
    </script>';
    session_destroy();
    include 'login.php';
 }
}else{
    echo '<script>
    window.alert("Fill all the details ");
    </script>';
    session_destroy();
    include 'login.php';
} 

}else{
    include 'login.php';
    echo '<center>Click on submit button </center> ';
}

?>
