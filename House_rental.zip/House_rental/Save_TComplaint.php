<?php
session_start();
if($_POST['To_Post']=='Post')
{
    $Message=$_POST['Complaint'];
    $To=$_POST['user_name'];
    $From=$_POST['user_name_u'];
    $who='Tenant';
    if($Message && $To && $From )
    {
         //Connect to mysql server 
         $link = mysqli_connect('localhost', 'root', '','house_rent'); 
         //Check link to the mysql server 
         if(!$link) { 
         die('Failed to connect to server: '); 
         } 
        //Create query (if you have a Logins table the you can select login id and password from there)
        $qry="INSERT INTO COMPLAINT VALUES('$To','$From','$Message','$who')";     
        //Execute query 
        $result=mysqli_query($link, $qry); 
        if($result)
        {
          echo '<script>
           window.alert(" Sucessfully Posted" );
           </script>';
           include 'Tenent_View.php';
        }
        else
        {
            echo '<script>
            window.alert(" error! Try again" );
            </script>';
            include 'Tenent_View.php';
        
        }
    }
    else
    {
        echo '<script>
        window.alert(" Enter All Details " );
        </script>';
        include 'Tenent_View.php';
    }
}
?>
