<?php
session_start();
if($_POST['To_Post']=='Post')
{
    $Message=$_POST['Complaint'];
    $To=$_POST['user_name'];
    $From=$_POST['user_name_u'];
    $who='Seller';
    if($Message && $To && $From )
    {
         //Connect to mysql server 
         $link = mysqli_connect('localhost', 'root', '','house_rent'); 
         //Check link to the mysql server 
         if(!$link) { 
         die('Failed to connect to server: '); 
         } 
        //Create query (if you have a Logins table the you can select login id and password from there)
        $qry="INSERT INTO COMPLAINT VALUES('$From','$To','$Message','$who')";     
        //Execute query 
        $result=mysqli_query($link, $qry);
        if($result)
        {
              echo '<script>
              window.alert("Complaint Posted Successfully");
              </script>';
              include 'Seller_View.php';
        }
        else
        {
            echo '<script>
            window.alert("error! try again ");
            </script>';
            include 'Seller_View.php';
        }
    }
    else
    {
        
        header('location:Post_SComplaint.php');
    }
}
?>