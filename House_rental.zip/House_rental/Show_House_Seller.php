<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Seller view</title>
<style>

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color:rgb(119, 240, 220);
  border:1px solid black;
  border-collapse: collapse;
}

li {
  border:1px solid black;
   width:150px;
  text-align:center;
  font-weight: bold;
  float: left;
  border-collapse: collapse;
}

li a, .dropbtn {
  display: inline-block;
  color:rgb(17, 14, 14);
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}
li a:hover, .dropdown:hover .dropbtn {
  background-color: rgb(97, 185, 219);
  width:117px;
}

li.dropdown {
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #A0DAA9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {
  width:83%;
  background-color: #f1b4f1;}

.dropdown:hover .dropdown-content {
  display: block;
}

.start{
            border:1px solid black;
            background-color: #B55A30;
            display:block;
            text-align: center;
        }


        table,th{
        border-color:blue;
        border:2px solid black;
        border-collapse: collapse;
      }
    th,td{
      padding:20px;
    }
   tr:nth-child(even){ 
  background-color:#eee;
  }
  tr:nth-child(odd){
  background-color:#fff;
  }
      th{
        background-color: rgb(209, 186, 214);
     }
     .button {
        background-color: skyblue;
        border: 2px solid black;
        padding: 8px 8px;
        text-align: center;
        text-decoration: none;
        color:red;
        width:170px;
        display: inline-block;
        font-size:20px;
    }
    .perfect{
      margin:40px 10px;
      float:left;
    }
</style>
</head>
<body>
  <div class="start"> <h2> RENTAL HOUSE MANAGEMENT SYSTEM </h2></div>
<ul>
    <li class="dropdown">
        <a href="#" class="dropbtn"><img src="http://localhost/House_rental/Images/House_image.png" style="width:25px; height:25px;">
House</a>
        <div class="dropdown-content">
          <a href="house_registrationform.php">Register House</a>
          <a href="Update_Delete_House.php">update/delete</a>
          <a href="Show_House_Seller.php">Show My Houses</a>
        </div></li>

  <li><a href="Contracts_By_Seller.php"><img src="http://localhost/House_rental/Images/contract.png" style="width:25px; height:25px;" >

Contracts</a></li>
  <li><a href="Tenent_By_Seller.php"><img src="http://localhost/House_rental/Images/group.png" style="width:25px; height:25px;" >
Tenents</a></li>
  <li class="dropdown">
        <a href="#" class="dropbtn"><img src="http://localhost/House_rental/Images/complaint.png" style="width:25px; height:25px;" >

Complaint</a>
        <div class="dropdown-content">
          <a href="Post_SComplaint.php">Post Complaint</a>
          <a href="View_SComplaint.php">View Complaints</a>
        </div></li>
  <li><a href="Payment_View_Seller.php"><img src="http://localhost/House_rental/Images/payment.png" style="width:25px; height:25px;" >

Payments</a></li>
  <li><a href="Requests_By_Seller.php"><img src="http://localhost/House_rental/Images/request.png" style="width:25px; height:25px;" >

Requests</a></li>
  <li class="dropdown" style="float:right;">
  <?php
  session_start();
  $Name=$_SESSION['Uname'];
  echo '<a href="#" class="dropbtn"><img src="http://localhost/House_rental/Images/user.png" style="width:25px; height:25px;" >

  '.$Name.'</a>';

?>
  <div class="dropdown-content">
      <a href="Start.php">Sign out</a>
    </div>
  </li>
</ul>



  
<?php

    $link = mysqli_connect('localhost', 'root', '', 'house_rent');  

    /*Check link to the mysql server*/ 
    if(!$link)
    { 
    die('Failed to connect to server: ');
     } 
    
     /*Create query*/ 
    $qry = "SELECT  * FROM sellers WHERE USER_NAME='$Name' "; 
    
    /*Execute query*/ 
    $result = mysqli_query($link, $qry);
    if(mysqli_num_rows($result)>0){

    echo '<center><h1>Registered Houses are - </h1></center>';
    
    $count=1;
    while ($row = mysqli_fetch_assoc($result))
    {

   echo '<form method="post" action="Delete_House_Seller.php">';
   
   if($row['RENT_OR_SALE']=='Rent'){
    echo '<center><table style="width:75%" > 
    <tr>
    <th colspan="2">OWNER DETAILS</th>
    <th colspan="2">ROOM DETAILS</th>
    </tr>
  
    <tr>
    <td> <b>FULL NAME</b> </td> 
    <td>'.$row['FULL_NAME'].'</td>
    <td><b>HOUSE NO </b></td>
    <td>'.$row['HOUSE_NO'].'</td>
    </tr>
    <tr>
    <td><b>EMAIL</b></td>
    <td>'.$row['EMAIL'].'</td> 
    <td><b>ROOM TYPE</b></td>
    <td>'.$row['ROOM_TYPE'].'</td>
    </tr>
    <tr>
    <td><b>PHONE NUMBER</b></td>
    <td>'.$row['PHONE_NUMBER'].'</td> 
    <td><b>AC/NOT</b></td>
    <td>'.$row['AC_OR_NOT'].'</td>
    </tr>
    <tr>
    <td><b>USERNAME</b></td>
    <td>'.$row['USER_NAME'].'</td>
    <td><b>RENT/SALE</b></td>
    <td>'.$row['RENT_OR_SALE'].'</td>
    </tr>
    <tr>
    <td><b>COUNTRY</b></td>
    <td>'.$row['COUNTRY'].'</td>
    <td><b>STATUS</b></td>
    <td>'.$row['STATUS'].'</td>
    </tr>
    <tr>
    <td style="height:30px" ><b>DESCRIPTION</b></td>
    <td>'.$row['DESCRIPTION'].'</td>
    <td><b>STATE</b></td>
    <td>'.$row['STATE'].'</td>
    </tr>


    <tr>
    <td rowspan="4">
      <img src="http://localhost/House_rental/Images/'.$row['IMAGE'].'" width="200px" height="200px" >
    </td>
    <td></td>
    <td><b>CITY</b></td>
    <td>'.$row['CITY'].'</td>
    </tr>



    <tr>
    <td></td>
    <td><b>ADDRESS</b></td>
    <td>'.$row['ADDRESS'].'</td>
    </tr>
    <tr>
  
    <td></td>
    <td><b>PINCODE</b></td>
    <td>'.$row['PINCODE'].'</td>
    </tr>
    <tr>
  
    <td></td>
    <td><b>RENT PER DAY </b></td>
    <td>'.$row['RENTPRICE'].'</td>
    </tr>
    <tr>
    <td><input class="button" type="submit" name="Del" value=" Delete  House    No:'.$row['HOUSE_NO'].'"> </td>
    <td><input class="button" type="submit" name="Upd" value=" Update  House    No:'.$row['HOUSE_NO'].'"></td>
    <td><b>LANDMARK</b> </td>
    <td>'.$row['LANDMARK'].'</td>
    </table> </center>';
   
    }else{
      echo '<center><table style="width:75%" > 
    <tr>
    <th colspan="2">OWNER DETAILS</th>
    <th colspan="2">ROOM DETAILS</th>
    </tr>
  
    <tr>
    <td><b>FULL NAME <b></td> 
    <td>'.$row['FULL_NAME'].'</td>
    <td><b>HOUSE NO</b></td>
    <td>'.$row['HOUSE_NO'].'</td>
    </tr>
    <tr>
    <td><b>EMAIL</b></td>
    <td>'.$row['EMAIL'].'</td> 
    <td><b>ROOM TYPE</b></td>
    <td>'.$row['ROOM_TYPE'].'</td>
    </tr>
    <tr>
    <td><b>PHONE NUMBER</b></td>
    <td>'.$row['PHONE_NUMBER'].'</td> 
    <td><b>AC/NOT</b></td>
    <td>'.$row['AC_OR_NOT'].'</td>
    </tr>
    <tr>
    <td><b>USERNAME</b></td>
    <td>'.$row['USER_NAME'].'</td>
    <td><b>RENT/SALE</b></td>
    <td>'.$row['RENT_OR_SALE'].'</td>
    </tr>
    <tr>
    <td><b>COUNTRY</b></td>
    <td>'.$row['COUNTRY'].'</td>
    <td><b>STATUS</b></td>
    <td>'.$row['STATUS'].'</td>
    </tr>
    <tr>
    <td style="height:30px" ><b>DESCRIPTION</b></td>
    <td>'.$row['DESCRIPTION'].'</td>
    <td><b>STATE</b></td>
    <td>'.$row['STATE'].'</td>
    </tr>

    <tr>
    <td rowspan="4">
    <img src="http://localhost/House_rental/Images/'.$row['IMAGE'].'" width="200px" height="200px" >
    </td>
    <td></td>
    <td><b>CITY</b></td>
    <td>'.$row['CITY'].'</td>
    </tr>

    <tr>

    <td></td>
    <td><b>ADDRESS</b></td>
    <td>'.$row['ADDRESS'].'</td>
    </tr>
    <tr>
  
    <td></td>
    <td><b>PINCODE</b></td>
    <td>'.$row['PINCODE'].'</td>
    </tr>
    <tr>
  
    <td></td>
    <td><b>SELLING PRICE</b></td>
    <td>'.$row['SELLINGPRICE'].'</td>
    <tr>
    <td><input class="button" type="submit" name="Del" value=" Delete  House    No:'.$row['HOUSE_NO'].'"></td>
    <td><input class="button" type="submit" name="Upd" value=" Update  House    No:'.$row['HOUSE_NO'].'"></td>
    <td><b>LANDMARK</b></td>
    <td>'.$row['LANDMARK'].'</td>
    </table> </center>';
  }
    echo '</form><br><br><br><br><br><br>';
}
      
} else{
  echo '<center><h1>Oops!You did not registered any house </h1></center> ';
} 

?>

</body>
</html>



