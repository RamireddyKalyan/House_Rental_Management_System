<?php
session_start();
?>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Seller view</title>
<style>
body
        {
            background-image: url('data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxAPDw0PDxAPDw8PEA8PDw8PDw8PDw8PFRUWFhYVFRUYHSggGBolHRUVITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGxAQGzcmHyUtLS4tLS0tMC0tLy0rNTYuLS0tMC03LS0tKzItLi8tLS0tLS0wLS8vLS8tLS0rLS0tLf/AABEIAKcBLQMBIgACEQEDEQH/xAAcAAACAgMBAQAAAAAAAAAAAAAAAQIDBAUHBgj/xABHEAABBAADAwgFCAcGBwAAAAABAAIDEQQSIQUTMQYWIkFRVJPSBzJhgZEjQnGhsbLR8BQkUlNidOEVM2Ryc5IlNUODo8Hx/8QAGwEBAAIDAQEAAAAAAAAAAAAAAAQFAQIDBgf/xAA5EQACAQICBwUHAwIHAAAAAAAAAQIDEQQhEjFBUZGh0QUUFWHwEyIyUnGBsULB4TPxFlNigqLC0v/aAAwDAQACEQMRAD8A63lRSspKlgEKRSnSKQFeVFKykUgK6RSspFICvKlStpKkBCkqVlIpAV0ilZlRSArpKlZSKQFdIpWUlSAhSVKykUgK6RSnSKQFdIpTpFICFJUrKSpAV0ilZSRCArpKlZSKQFZCVKykqQFZCVK2ksqAqypEK0hRyoCukqVlJZUBtKRSspKkBCkqVlJEICFIpTDUUgIUilPKikBCkqVmVLKgIUilZXs+vVKkBCkqVlJUgIUilOkUgIUlSspIhAQQpBqKQEKRSnSKQEKSIU6RSAhSVK2vyTVpEICukqVlJUgIUlSspKkBCkqVlJEICukqVmVKkBXSRCtpKkBVSVK2kqQGypFKdIpZBWUBqmGopARpFKVKnGYlkMcksrgyONpc97uDWhAYm2drQYKLfYmQRszNYNCS554NaBqTxP0AnqWoHLrZ/wC9f4Tlx30icrpMdMMttYCRBGdcrL4uHDM6hfYNOqzhbNn3jQDo7sP3VArYqcVpQ1Ho8B2Th6j9niJNT15NWV9jyedtdt9juHPjZ3753hv/AAUhy22d+/8A/FL+C44Iv/qMqieI1Ny4Fv8A4awfzS4x/wDJ2Xnns7vA8Ka/uI56bO7wPBn8i4djMWxh3fTEjxbTl0PvRhnOLmgmwT2Bb99rWvZcP5I/gOB0tFTk7a845fX3TvWzuUmDxMgignY95BIble0kDjWYC/oW2pcDa4w5JYyWyMcHDKacCNQV13kdyjbj4ukQMRGBvWcMw/eNHYesdR91ycLjFVylk/yVfavYzwsfa0buG29rrhbJ/TLbsN9SKU6RSnFCVlLKrMqKQEKSpWUikBXSVK2kqWAV0hTpFICBH560ip0ikBXSKVlJUgIUlSnSKQEFGlZlRSAhSVKdJ0gKqSpWUlSArpKlbSVIDYUilKkUsghSKU6QgILiPpM5bDFSbmA3hInesDpiJR872sHV28eyt96VOWWXeYDDO1qsZK0+oD/0mkdZ+d7NO2uPAb12b5vzQoeIqJ+6tW3oXnZ2EcEq0l7z+Ff9unEWHiLiZHcXcL6llC2mxpXFWxx6exReOrqUJzuy1VLRXmbnB4kSN9o+v2q8hedgkMbgR2rf4eYSNse8KHVp6Oa1Fzg8V7RaMviRj4yASBrTo5js7D2FY+C0kYDo7Nw7Fssnx6v6ql+Gt8b+BadfaFiM1azO1WknLTjr2+Zlzer70tmY+TCzMlidke02DqQR1gjrB4Uk46Kssv8AFc4Sa1HZJOLUldPWdw5Pbajx0LZWGnDSSMmzG/s+g8Qese8La0uEcnttyYGdsserT0ZGE02Rt6tPt7D1H3323ZW0Y8VEyaJ2Zjh7MzT1tcOohX+FxPtY2fxI8D2v2U8FU0of03q8vJ/s9q+5lUlSnSVKWU5GkUpUikBBFKdJUgI0ilKkUgIUilKkUgI0kp0kgIUilOkUgIUlSspKkBXSKVlJUgK6SpWUikBXSVKykqQGchQtFoCa8P6R+V4wMW4hcP0uVvR69zGdN4R28Q0duvVR9ra5Ptv0W4vFYieY46O5ZHODpI3uflPqg0QNBQ000XOpp2tAk4T2KnpVnks7Z5vd6+hymaQzOIs6ElzibJJ42e32q+KOhXADisnH7MOEnlwpcHuge+JzwMoeWmrrqSqx9HD+qqZuz0T11OLmlN62kQHD2JOarGtTLVy0jto5GLlVmEnMTh7erqr2q3JX09ix5471/NrdO+TI7UotSjrPRMeHgOHAoWk2Vjcjsr3HKesNc4k+wNHFbWPHQOvpSACxmMb2jMOrUCupRpYaafuq6LKn2jQ0bzkk9zZdX57EisN214uGSc12RlQ/tdnVh8Wf+23zLX2Ml/dHVY2g/wBV+Jlvat7yO5TOwEtOt0EhAmYNa/jb/EPrGnZXlX7U/wALiveGfivW8keSMm0YDiA4YcCV0WSRhkdo1pzaED531LvQo1dJOGv6o5YvG4N0XHEX0Hl8Mv2WT3M7HhZ2SsbIxwex7Q5jhwc08CrlouSewnYGAwumM1vLh0cjGggeq0kkWbJ14lb1X0W2k2rM+eVowjUkqbvG+Tta6+gkIQtjmCEIQCQmkgBCLSLkA0k0IBUikIQCQhCAEqTQgEikIQCpKlJJATzIzKrOjMgLbRf5vVV5ksyA+f8Al1hyNobRF+vJiHtI0IvN9YIPwXkNnSyvfKxz39HeDj1tBpe05bPzbSxzeAbLiGj2k53E/FxXlNniLfyubK8udvM8ZheA00b1/hVVJ5z++z1Y9goXhQbdtSedrqy+l9nEjsLEvlc/O4mmcPeFtpB0ZK0OR9HsNcVq9hQsa9+7m3tsNjdPjoZm66n6luALNew/YuGIaVR28tlvzY74BSlQjpO7fnfmm1zNJs/FzPmMT3Cg8C6Nn60tmYuSV+V+WhmsBp10+lW7PgaJzIJoiXPHyQPyl16v0qzYezi2azLC5pDyQx9ucA3UD204HXtXeWh71lsWzaQoKqnBybtpNP3lqutHaeh2FEA1xo0HuOg10AsC/YsfFYqZ2JfA2QNj3TnsIYdHdp11Fg/H3DMwktsc1vqh9D4D8/m1gvyDEvk30VMhp0ecbxmWyXOHV6ygJ+9L1nkXej7sG3bNbbZZ7rfxr2FGwcVK9x3ryf71tCw3oGOjXvciZkn6SY9/Lkex7hRrISH1l+iktiMaHdCQSgic5mggamLRXySx/pBd8rvWRv8Ak92aIaHklpPrddLZ/HKy2bjWH9GGlLPSj+rXvzvn9OGZg4IPErw6SR+SYhueuG7k4hui7h6Lj+oP/mH/AHI1xLCSMdJIYxM0mYmTegN6W7d6v9V2v0Xn9Qf/ADEn3I1MwrviF9Cv7VSXZrs7+/8Au957G0rUcyV/nrVseMJ2i1C07QErRajaLQErRahaC5ASJSAUQnaAlaLUbRaAkhRtK0BK0KNoJQEkKFozICaVqNpWgJ2lajaWZAVZ0w9YW+Ut+gMvMjMsUTJiZAcO5X/8y2j/AK2I+xy8vgG5cTOaNOdKWkg16pXo+WZ/4jjqOu/kr2arUsv9uTXj03Kpm7Sl53R7KnedKlb9Oi/rksjW8mndOQG7yE6/5mL0EfrfH7FjxNrtJ7TxVmvUa9qj1pe0m5IkYOm6FKMHnY1GzSP0140HSjN/SwKWzMVnlyUBlziu0hhHu6/ifdsQOFHhw6DL+xRbE1pDsrc2tEAM6qors6qafmkuBFjhpRlGW6blq2Np2yb3G12b6jv8x+wLFaQMeeH9xr7dT+CyNmOtj9K+UP2BZIAu8ozcM1C6VffRlK+1WLyMdKMGtjT4Gm5OgAkj/E+7px8VkzNccW004jdOGejlvp9ayc36w3/Rk+9GrTGNdP6FbSqXk5b1+TWnQcYKF9TWf0s/M1GHhe2WcuaQHTEtJHEZHLs3oyP6g7+Yk+5GuVSMHU0D20F1L0bn9QP8xL9yJTcDLSrX8iu7cp6HZ7X+tPi2z1+ZLMqsyMyuTwxbmRmVWZGZAW5kZlVmRmQF2ZK1VmRmQFuZGZVZkZkBbmRmVWZGZAW5kZlVmRmQFuZLMq8yMyAszIzKrMjMgLcyWZV5ksyAtzJEqvMjMgPNnFo/TPatqcK09Q+CgcAw8Wj4IDXfpftU24z2rLOyYj834EhVu2HGf2x9DvxQHGOVbrx+MPbK4rWtcutY/wBHWGnkkkMuJD5DmNOjLb+gsv61hP8ARdF83Eyj/NHG77KVfUw022z0lDtTDxhGMm7pJatyOcRlTLvgveyei93BuL0/igH/AKcqH+jCf5uJiP0te38VweEq7iXHtTCP9fKXQ8QCoPK9o70Z40cJMK4f6kwP1xqh/o6x44CFx6ql81LXu1RbDp4hhXqqLmvyaLZbhkffHOSPgOKsGMis/K0bNg0Nfet3g+QO0NQ5kbelmszMoj3WVQ/0a7QzPNQusucC2YcOw2AufdJybumS5dp4anTgo1It7c+hrBRkDwQW5HNu71sfgrVnt5FbVZTRh2lo6xLD268XArZQ8hcc7i2OMfxzC/fVrjLCVb/C+DJFPtLCaN3Viv8AcuWdzzEpXT/Rwf1E/wAxL9yJYexPR+1jnHGGKVpaMojklBDr1JsNXrdn7Kiw7N3CxsbC4uDQXEZjQJtxJ6gp+Dws6ctOXnltKTtztbD16Pd6V27p3VtHje/IvtFqYhT3StDyhXaLVojT3aAqQrsiN2gKUK/do3awCkBKir92nu0Bj0iisjdo3aAx6RSyN2jdoDHpGVZO7Ru1kGNSMqyd2jdrAMakUsndo3aAxqSyrL3aju0BhgKQSCaAKQhNACdJBSQBSdJJhZAwFKlFSCASlSAPp+I+xCAKTpCaAKTpJSCAVJ0pJFAKlJJoUwgFlRSaaAVIpNNAKkUn+exMIBZUZVNCAgjKppoCGVGVTpBQFaYam1qkgIZUZVYhAV5UZVYhAeL524DvA8Obyo53YDvA8Obyrw3JLZccxnllbvRCYWMizFjZJp5MjA9w1DQbJr+h3uO2Zh8RE9sccLXsDt3LBBLhsjw2QttrnOEsbjFI3NoQRw41PnhqMZWbfnqy5etlytp4mvOGklHyVnnz9bcszec7sB3geHN5VLnfgO8Dw5vKud7F2QJyx0jwyN75Y2tsiSRzGZnZdCKFssmvW01U8LyalkfkEkbTu45HlznBse8GZrXENPSLelpYAuyKK6PCUFdOTy9bjnHGYiSTUFn5fydB534DvA8Obyp878B3geHN5VzUbGkMO/D4ichlEQcd46ISbsvGlZcwI43oTVLJx3JqSGORxlieWZ88bHSF/Qe2N/FoHRc9oOut2LCdzoXtpPds18DHfcRa+gt+p6uPkdC54YDvA8Obyo54YDvA8ObyrnsOwLa8vxEUbmR4eXLkkfl3xbka7KwnMQ8EBodx1pPDcn3yiAMdHFnYCXPe7K5z5nwsaAG20ksqjdVZIuhjutH5n6z3GyxeIbtor07bzoXPDAd4HhzeVNvLHZ/eB4c3lXPYOTEj5CxssGURteJi94jc12aq6OYf3cl2AAGOJ0WJhtkPkhdNniY0OeyNsj8r5nsALms0onpN4kWSALWe50Pmf9/sa99xHyLby17fWw6bzx2f3lvhz+VPnls/vI8ObyrwD+ScwzXLh8rBJvX5nlkToywOY+heYbxvAEcdVhbZ2HLhADI9j/lJInZHOdkewNJa6wOpzTpfFYWFoN2Un6+xmWMxMVdwVvo+p0vnls/vI8ObyqXPLZ/eR4c3lXH0Lp4fT3vl0OXidXcuD6nYeeez+8jw5vKlzz2f3keHP5Vx9CeH0975dB4nV3Lg+p2Hnns/vI8Ofyo557P7y3w5/KuPITw+nvfLoPE6u5cH1Oyc9Nnd5b4U/lQOWmzu8t8KfyrjaE8Pp73y6DxOruXB9TsnPXZ3eW+FP5U+euzu8t8KfyrjSE8Pp73y6DxOruXB9TsvPXZ3eW+FP5U+euzu8t8KfyrjKE8Pp73y6DxOruXB9Ts3PXZ3em+FP5Ec9tnd5b4U/lXGUJ4fT3vl0HidXcuD6naOeuzu9N8Kfyp89dm95b4U/lXFkJ4fT3vl0HidXcuD6naOe2zu9N8Kfyo577N70PCn8i5Bs7AvxEgjZlDiLtxIFWB1A9oWVhthTSPexpjzMeGGy4CywvafV4ECu2+IC1lgqEdcnxXQ3jj8RLVBcH1Oq89tm96b4U/lS57bN703wp/IuZM5NTFrXB7KcQ1tue0klmcaEX7PYQey0ubU1uGdlhwbWZ4txaSALGvquHuvhqte64f5nxXQ275ifkXr7nUOe2ze9Dwp/Kjnts3vTfCn8q5PidjSxmYOyfIta59OJBBbm009h+CyDyYxPyZqMtfVOEgoA1lJvtDmmhZojRZ7pQ16T4roarG4h/oXB9TqHPfZvem+FP5Uc99m96b4U/lXKhydxevyI0BJuWEAAGjrm7bHuPYUzycxdNJirMaAMkQPAEX0uzX3FO6Yf5ua6Ge+4n/L/wCL6nVOe+ze9N8Kfyp899m96b4U/lXKpuTmKY2R7owBG0OeM8dhtEk8eqq9p4WtUto4KjLU3xXQ1l2hXjlKKX2fU2GxNruwrpOgJYpAI5YnOczPRzMpw1a4EWHDgs/aPKp0gc2GPdB7XCR0kr8RI62lvrkCgBI+gBxe48dU0Kb7KEpq69fjkQYVZqDinl9vzr5mqwm05oo3xxvytfdjKwkFwyOLXEWwkaEtIsKUe05mve8ODi9jWPa+OJ8b2MDWtDmOBaaDG0avRCE0YvZrNNOS26uof2tPkMeZoZ8poI4xlY52ZzWkNtrSdco0HUE3bYxBzgvBz71zgWRkOzva99gitXMaa9lcE0JoR3GdOW98X59Ai21iGSvnbJUjw0POSMtpuXLTCMoy5W1Q0yikodrzt3YbIegYyyw0kFj3SN1I1p73HXtQhNCO70h7Sa1N8d+sI9rzt0DmluQMLHxxyMMeYvALXAgkOcSDVi049tzsjdG17WscOAjjttxhpLXZbaSwCyKJ69UIRwjuNI1pvK74stn5Q4p4e18gIe2RjwI4m5w/KXudlaLccjelx0WPj9rzT5t67Nme+c9Frem5rQ46DsY3T2IQihFZpHSVWbycmYaEIWxzBCEIAQhCAEIQgBCEIAQhCAEIQgBCEIAa8tOhLT2tJB+IUhK4EkOcCSSSHEEk3ZPxPxKEIwhnEP8A23/7ndmX7NPoQcQ/9t/+53Zl+zT6EIWDLIulcbtzjdA24mwOF9qYmeODnDq0ceGn4D4BCEFhmd5+e/8A3u9n4D4BPfv06b9OHTdp9aELNghHEPNgveQbvpu1sUfqUEIQwf/Z');
            background-size: 1700px;
            background-repeat: no-repeat;
        }
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color:rgb(119, 240, 220);
  border:1px solid black;
  border-collapse: collapse;
}

li {
  border:1px solid black;
   width:150px;
  text-align:center;
  font-weight: bold;
  float: left;
  border-collapse: collapse;
}

li a, .dropbtn {
  display: inline-block;
  color:rgb(17, 14, 14);
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}
li a:hover, .dropdown:hover .dropbtn {
  background-color: rgb(97, 185, 219);
  width:117px;
}

li.dropdown {
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #A0DAA9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {
  width:83%;
  background-color: #f1b4f1;}

.dropdown:hover .dropdown-content {
  display: block;
}
form
{
    padding-left:400px;
    padding-top:100px;
}
.B:hover,.B:active,.B:visited,.B:link
        {
            text-decoration: none;
            color: black;
        }
        .B:hover
        {
            color:hotpink;
        }
        .B:active
        {
            color:red;
        }
.start{
            border:1px solid black;
            background-color: #B55A30;
            display:block;
            text-align: center;
        }
        input[type="submit"]
        {
          color:
        }
</style>
</head>
<body>
  <div class="start"> <h2> RENTAL HOUSE MANAGEMENT SYSTEM </h2></div>
<ul>
    <li class="dropdown">
        <a href="#" class="dropbtn"><img src="http://localhost/House_rental/Images/House_image.png" style="width:25px; height:25px;">

House</a>
        <div class="dropdown-content">
          <a href="house_registrationform.php">Register House</a>
          <a href="Update_Delete_House.php">update/delete</a>
          <a href="Show_House_Seller.php">Show My Houses</a>
        </div></li>

  <li><a href="Contracts_By_Seller.php"><img src="http://localhost/House_rental/Images/contract.png" style="width:25px; height:25px;">
Contracts</a></li>
  <li><a href="Tenent_By_Seller.php"><img src="http://localhost/House_rental/Images/group.png" style="width:25px; height:25px;" >
Tenents</a></li>
  <li class="dropdown">
        <a href="#" class="dropbtn"><img src="http://localhost/House_rental/Images/complaint.png" style="width:25px; height:25px;" >
Complaint</a>
        <div class="dropdown-content">
          <a href="Post_SComplaint.php">Post Complaint</a>
          <a href="View_SComplaint.php">View Complaints</a>
        </div></li>
  <li><a href="Payment_View_Seller.php"><img src="http://localhost/House_rental/Images/payment.png" style="width:25px; height:25px;" >
Payments</a></li>
  <li><a href="Requests_By_Seller.php"><img src="http://localhost/House_rental/Images/request.png" style="width:25px; height:25px;" >
Requests</a></li>
  <li class="dropdown" style="float:right;">
  <?php

  $Name=$_SESSION['Uname'];

  echo '<a href="#" class="dropbtn"><img src="http://localhost/House_rental/Images/user.png" style="width:25px; height:25px;" >
  '.$Name.'</a>';

?>

  <div class="dropdown-content">
      <a href="Start.php">Sign out</a>
    </div>
  </li>
</ul>

<style >
  form
  {
    position:relative;
    top:0px;
    left:-30px;
  }
  input[type="text"]
  {
    border-radius:15px;
    border:solid 5px;
    height:50px;
    size:20px;
  }
  textarea
  {
    border-radius:15px;
    border:solid 5px;
  }
  div.df
  {
    position:absolute;
    top:377px;
    left:830px;
  }
  div.s
  {
    position:absolute;
    left:600px;
  }
  input[type="submit"]
  {
    position:relative;
    top:160px;
    left:360px;
    border-radius:15px;
    border:solid 5px;
    height:50px;
    width:100px;
    background-color:#45B8AC;
  }
  </style>
<form method="post" action="Save_SComplaint.php">
<h1>Complaint :</h1>
        <textarea style="background-color:white" rows="10" cols="100" name="Complaint" value="Post Ur Complaint Here" placeholder="Post Ur Complaint Here" cols="95" rows="10" border-radius:10px></textarea>
        <br><br><br>
        <div class="S">
                    <h1>To Whom</h1>
                    <input class="label" type="text" placeholder="user name of Tenant" name="user_name"><br><br><br></div>
                   <div class="df">
                    <h1>Username</h1>
            
                  <input class="labe" type="text" placeholder="ur Username" name="user_name_u" ></div>
                    <input  type="submit" name="To_Post" value="Post">
      
</form>
</body>
</html>


