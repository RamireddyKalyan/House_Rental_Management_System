<!DOCTYPE html>
<html lang="en">
<head>
    <style>
        h1
        {
            color:black;
            text-align:center;
            padding:100px;
        }
        a
        {
            text-align:center;
            text-decoration:none;
            font-size:25px;
            padding-left:650px;
        }
        </style>
</head>
<body>
    <h1>Please Enter House Number OR User Name Correctly....</h1>
    <a href="http://localhost/House_rental/house_registrationform.php">Register Here</a>
</body>