<!DOCTYPE html>
<head>
<style>

  table,th{
        border-color:blue;
        border:2px solid black;
        border-collapse: collapse;
  
      }
    th,td{
      padding:20px;
    }
   tr:nth-child(even){ 
  background-color:#eee;
  }
  tr:nth-child(odd){
  background-color:#fff;
  }
      th{
        background-color: rgb(209, 186, 214);
     }
     .button {
        background-color: skyblue;
        border: 2px solid black;
        padding: 8px 8px;
        text-align: center;
        text-decoration: none;
        color:red;
        width:170px;
        display: inline-block;
        font-size:20px;
    }
</style>
</head>
    </body>
<?php
session_start();
include 'Tenent_View_prev.php';

 if(isset($_POST['filter']) && $_POST['filter']=='search')
 {
     if(isset($_POST['search_state'])&& trim($_POST['search_state']) !== ""){
      $state=$_POST['search_state'];
     }
     if(isset($_POST['search_city'])&& trim($_POST['search_city']) !== ""){
     $filter_city=$_POST['search_city'];
     }
     if(isset($_POST['ac'])&& trim($_POST['ac']) !== "")
     $conditioner=$_POST['ac'];
     if(isset($_POST['room_status'])&& trim($_POST['room_status']) !== "")
     $status=$_POST['room_status'];
     if(isset($_POST['select_room'])&& trim($_POST['select_room']) !== "")
     $room_type=$_POST['select_room'];
     $link = mysqli_connect('localhost', 'root', '', 'house_rent');  
/*Check link to the mysql server*/ 
if(!$link)
{ 
die('Failed to connect to server: ');
} 
if(isset($_POST['search_state']) && trim($_POST['search_state']) !== "" && isset($_POST['search_city'])&& trim($_POST['search_city']) !== "" && isset($_POST['ac']) && trim($_POST['ac']) !== ""&& isset($_POST['room_status'])&& trim($_POST['room_status']) !== "" && isset($_POST['select_room'])&& trim($_POST['select_room']) !== ""){
/*Create query*/ 
//echo empty($_POST['ac']);
$qry = "SELECT  * FROM sellers WHERE RENT_OR_SALE='$status' AND ROOM_TYPE='$room_type'AND STATE='$state' AND CITY='$filter_city' AND AC_OR_NOT= '$conditioner' "; 

$result = mysqli_query($link, $qry);

if(mysqli_num_rows($result)>0){
  echo '<center><h1>The Houses are - </h1></center>';
  while ($row = mysqli_fetch_assoc($result))
  {

  if($row['RENT_OR_SALE']=='Rent'){

  echo '<center><table style="width:75%" > 
  <tr>
  <th colspan="2">OWNER DETAILS</th>
  <th colspan="2">ROOM DETAILS</th>
  </tr>

  <tr>
  <td> FULL NAME </td> 
  <td>'.$row['FULL_NAME'].'</td>
  <td>HOUSE NO</td>
  <td>'.$row['HOUSE_NO'].'</td>
  </tr>
  <tr>
  <td>EMAIL</td>
  <td>'.$row['EMAIL'].'</td> 
  <td>ROOM TYPE</td>
  <td>'.$row['ROOM_TYPE'].'</td>
  </tr>
  <tr>
  <td>PHONE NUMBER</td>
  <td>'.$row['PHONE_NUMBER'].'</td> 
  <td>AC/NOT</td>
  <td>'.$row['AC_OR_NOT'].'</td>
  </tr>
  <tr>
  <td>USERNAME</td>
  <td>'.$row['USER_NAME'].'</td>
  <td>RENT/SALE</td>
  <td>'.$row['RENT_OR_SALE'].'</td>
  </tr>
  <tr>
  <td>COUNTRY</td>
  <td>'.$row['COUNTRY'].'</td>
  <td>STATUS</td>
  <td>'.$row['STATUS'].'</td>
  </tr>
  <tr>
  <td style="height:30px" >DESCRIPTION</td>
  <td>'.$row['DESCRIPTION'].'</td>
  <td>STATE</td>
  <td>'.$row['STATE'].'</td>
  </tr>
  <tr>
  <td></td>
  <td></td>
  <td>CITY</td>
  <td>'.$row['CITY'].'</td>
  </tr>
  <tr>
  <td></td>
  <td></td>
  <td>ADDRESS</td>
  <td>'.$row['ADDRESS'].'</td>
  </tr>
  <tr>
  <td>RENT PER DAY </td>
  <td>'.$row['RENTPRICE'].'</td>
  <td>PINCODE</td>
  <td>'.$row['PINCODE'].'</td>
  </tr>
  <tr>
  <td><a class="button" href="tenent_registration(rent).php">Rent</a></td>
  <td></td>
  <td>LANDMARK</td>
  <td>'.$row['LANDMARK'].'</td>
  </table> </center>';
  }
  else{
   
    echo '<center><table style="width:75%" > 
    <tr>
    <th colspan="2">OWNER DETAILS</th>
    <th colspan="2">ROOM DETAILS</th>
    </tr>
  
    <tr>
    <td> FULL NAME </td> 
    <td>'.$row['FULL_NAME'].'</td>
    <td>HOUSE NO</td>
    <td>'.$row['HOUSE_NO'].'</td>
    </tr>
    <tr>
    <td>EMAIL</td>
    <td>'.$row['EMAIL'].'</td> 
    <td>ROOM TYPE</td>
    <td>'.$row['ROOM_TYPE'].'</td>
    </tr>
    <tr>
    <td>PHONE NUMBER</td>
    <td>'.$row['PHONE_NUMBER'].'</td> 
    <td>AC/NOT</td>
    <td>'.$row['AC_OR_NOT'].'</td>
    </tr>
    <tr>
    <td>USERNAME</td>
    <td>'.$row['USER_NAME'].'</td>
    <td>RENT/SALE</td>
    <td>'.$row['RENT_OR_SALE'].'</td>
    </tr>
    <tr>
    <td>COUNTRY</td>
    <td>'.$row['COUNTRY'].'</td>
    <td>STATUS</td>
    <td>'.$row['STATUS'].'</td>
    </tr>
    <tr>
    <td style="height:30px" >DESCRIPTION</td>
    <td>'.$row['DESCRIPTION'].'</td>
    <td>STATE</td>
    <td>'.$row['STATE'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td>CITY</td>
    <td>'.$row['CITY'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td>ADDRESS</td>
    <td>'.$row['ADDRESS'].'</td>
    </tr>
    <tr>
    <td>SELLING PRICE</td>
    <td>'.$row['SELLINGPRICE'].'</td>
    <td>PINCODE</td>
    <td>'.$row['PINCODE'].'</td>
    </tr>
    <tr>
    <td><a class="button" href="tenent_registration(buy).php">Sale</a></td>
    <td></td>
    <td>LANDMARK</td>
    <td>'.$row['LANDMARK'].'</td>
    </table> </center>';

  }
  echo '<br><br><br><br><br><br>';

}

}else{
   echo '<center><h1>Oops ! NO HOUSES FOUND </h1></center> ';
}



}


else if(isset($_POST['search_state']) && trim($_POST['search_state']) !== "" && isset($_POST['search_city'])&& trim($_POST['search_city']) !== "" && isset($_POST['ac']) && trim($_POST['ac']) !== ""&& isset($_POST['room_status'])&& trim($_POST['room_status']) !== "" ){


    $qry = "SELECT  * FROM sellers WHERE RENT_OR_SALE='$status' AND STATE='$state' AND CITY='$filter_city'  AND AC_OR_NOT= '$conditioner' "; 

  /*Execute query*/ 
  $result = mysqli_query($link, $qry);
  
  if(mysqli_num_rows($result)>0){
    echo '<center><h1>The Houses are - </h1></center>';
    while ($row = mysqli_fetch_assoc($result))
    {
  
    if($row['RENT_OR_SALE']=='Rent'){
  
    echo '<center><table style="width:75%" > 
    <tr>
    <th colspan="2">OWNER DETAILS</th>
    <th colspan="2">ROOM DETAILS</th>
    </tr>
  
    <tr>
    <td> FULL NAME </td> 
    <td>'.$row['FULL_NAME'].'</td>
    <td>HOUSE NO</td>
    <td>'.$row['HOUSE_NO'].'</td>
    </tr>
    <tr>
    <td>EMAIL</td>
    <td>'.$row['EMAIL'].'</td> 
    <td>ROOM TYPE</td>
    <td>'.$row['ROOM_TYPE'].'</td>
    </tr>
    <tr>
    <td>PHONE NUMBER</td>
    <td>'.$row['PHONE_NUMBER'].'</td> 
    <td>AC/NOT</td>
    <td>'.$row['AC_OR_NOT'].'</td>
    </tr>
    <tr>
    <td>USERNAME</td>
    <td>'.$row['USER_NAME'].'</td>
    <td>RENT/SALE</td>
    <td>'.$row['RENT_OR_SALE'].'</td>
    </tr>
    <tr>
    <td>COUNTRY</td>
    <td>'.$row['COUNTRY'].'</td>
    <td>STATUS</td>
    <td>'.$row['STATUS'].'</td>
    </tr>
    <tr>
    <td style="height:30px" >DESCRIPTION</td>
    <td>'.$row['DESCRIPTION'].'</td>
    <td>STATE</td>
    <td>'.$row['STATE'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td>CITY</td>
    <td>'.$row['CITY'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td>ADDRESS</td>
    <td>'.$row['ADDRESS'].'</td>
    </tr>
    <tr>
    <td>RENT PER DAY </td>
    <td>'.$row['RENTPRICE'].'</td>
    <td>PINCODE</td>
    <td>'.$row['PINCODE'].'</td>
    </tr>
    <tr>
    <td><a class="button" href="tenent_registration(rent).php">Rent</a></td>
    <td></td>
    <td>LANDMARK</td>
    <td>'.$row['LANDMARK'].'</td>
    </table> </center>';
    }

    else{
     
      echo '<center><table style="width:75%" > 
      <tr>
      <th colspan="2">OWNER DETAILS</th>
      <th colspan="2">ROOM DETAILS</th>
      </tr>
    
      <tr>
      <td> FULL NAME </td> 
      <td>'.$row['FULL_NAME'].'</td>
      <td>HOUSE NO</td>
      <td>'.$row['HOUSE_NO'].'</td>
      </tr>
      <tr>
      <td>EMAIL</td>
      <td>'.$row['EMAIL'].'</td> 
      <td>ROOM TYPE</td>
      <td>'.$row['ROOM_TYPE'].'</td>
      </tr>
      <tr>
      <td>PHONE NUMBER</td>
      <td>'.$row['PHONE_NUMBER'].'</td> 
      <td>AC/NOT</td>
      <td>'.$row['AC_OR_NOT'].'</td>
      </tr>
      <tr>
      <td>USERNAME</td>
      <td>'.$row['USER_NAME'].'</td>
      <td>RENT/SALE</td>
      <td>'.$row['RENT_OR_SALE'].'</td>
      </tr>
      <tr>
      <td>COUNTRY</td>
      <td>'.$row['COUNTRY'].'</td>
      <td>STATUS</td>
      <td>'.$row['STATUS'].'</td>
      </tr>
      <tr>
      <td style="height:30px" >DESCRIPTION</td>
      <td>'.$row['DESCRIPTION'].'</td>
      <td>STATE</td>
      <td>'.$row['STATE'].'</td>
      </tr>
      <tr>
      <td></td>
      <td></td>
      <td>CITY</td>
      <td>'.$row['CITY'].'</td>
      </tr>
      <tr>
      <td></td>
      <td></td>
      <td>ADDRESS</td>
      <td>'.$row['ADDRESS'].'</td>
      </tr>
      <tr>
      <td>SELLING PRICE</td>
      <td>'.$row['SELLINGPRICE'].'</td>
      <td>PINCODE</td>
      <td>'.$row['PINCODE'].'</td>
      </tr>
      <tr>
      <td><a class="button" href="tenent_registration(buy).php">buy</a></td>
      <td></td>
      <td>LANDMARK</td>
      <td>'.$row['LANDMARK'].'</td>
      </table> </center>';
  
    }
    echo '<br><br><br><br><br><br>';
  
  }
  }else{
     echo '<center><h1>Oops ! NO HOUSES FOUND </h1></center> ';
  }
  
}


else if(isset($_POST['search_state']) && trim($_POST['search_state']) !== "" && isset($_POST['search_city'])&& trim($_POST['search_city']) !== "" && isset($_POST['ac']) && trim($_POST['ac']) !== ""&&  isset($_POST['select_room'])&& trim($_POST['select_room']) !== ""){
  /*Create query*/ 
  //echo empty($_POST['ac']);
  $qry = "SELECT  * FROM sellers WHERE  ROOM_TYPE='$room_type'AND STATE='$state' AND CITY='$filter_city' AND AC_OR_NOT= '$conditioner' "; 
  
  $result = mysqli_query($link, $qry);
  
  if(mysqli_num_rows($result)>0){
    echo '<center><h1>The Houses are - </h1></center>';
    while ($row = mysqli_fetch_assoc($result))
    {
  
    if($row['RENT_OR_SALE']=='Rent'){
  
    echo '<center><table style="width:75%" > 
    <tr>
    <th colspan="2">OWNER DETAILS</th>
    <th colspan="2">ROOM DETAILS</th>
    </tr>
  
    <tr>
    <td> FULL NAME </td> 
    <td>'.$row['FULL_NAME'].'</td>
    <td>HOUSE NO</td>
    <td>'.$row['HOUSE_NO'].'</td>
    </tr>
    <tr>
    <td>EMAIL</td>
    <td>'.$row['EMAIL'].'</td> 
    <td>ROOM TYPE</td>
    <td>'.$row['ROOM_TYPE'].'</td>
    </tr>
    <tr>
    <td>PHONE NUMBER</td>
    <td>'.$row['PHONE_NUMBER'].'</td> 
    <td>AC/NOT</td>
    <td>'.$row['AC_OR_NOT'].'</td>
    </tr>
    <tr>
    <td>USERNAME</td>
    <td>'.$row['USER_NAME'].'</td>
    <td>RENT/SALE</td>
    <td>'.$row['RENT_OR_SALE'].'</td>
    </tr>
    <tr>
    <td>COUNTRY</td>
    <td>'.$row['COUNTRY'].'</td>
    <td>STATUS</td>
    <td>'.$row['STATUS'].'</td>
    </tr>
    <tr>
    <td style="height:30px" >DESCRIPTION</td>
    <td>'.$row['DESCRIPTION'].'</td>
    <td>STATE</td>
    <td>'.$row['STATE'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td>CITY</td>
    <td>'.$row['CITY'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td>ADDRESS</td>
    <td>'.$row['ADDRESS'].'</td>
    </tr>
    <tr>
    <td>RENT PER DAY </td>
    <td>'.$row['RENTPRICE'].'</td>
    <td>PINCODE</td>
    <td>'.$row['PINCODE'].'</td>
    </tr>
    <tr>
    <td><a class="button" href="tenent_registration(rent).php">Rent</a></td>
    <td></td>
    <td>LANDMARK</td>
    <td>'.$row['LANDMARK'].'</td>
    </table> </center>';
    }
    else{
     
      echo '<center><table style="width:75%" > 
      <tr>
      <th colspan="2">OWNER DETAILS</th>
      <th colspan="2">ROOM DETAILS</th>
      </tr>
    
      <tr>
      <td> FULL NAME </td> 
      <td>'.$row['FULL_NAME'].'</td>
      <td>HOUSE NO</td>
      <td>'.$row['HOUSE_NO'].'</td>
      </tr>
      <tr>
      <td>EMAIL</td>
      <td>'.$row['EMAIL'].'</td> 
      <td>ROOM TYPE</td>
      <td>'.$row['ROOM_TYPE'].'</td>
      </tr>
      <tr>
      <td>PHONE NUMBER</td>
      <td>'.$row['PHONE_NUMBER'].'</td> 
      <td>AC/NOT</td>
      <td>'.$row['AC_OR_NOT'].'</td>
      </tr>
      <tr>
      <td>USERNAME</td>
      <td>'.$row['USER_NAME'].'</td>
      <td>RENT/SALE</td>
      <td>'.$row['RENT_OR_SALE'].'</td>
      </tr>
      <tr>
      <td>COUNTRY</td>
      <td>'.$row['COUNTRY'].'</td>
      <td>STATUS</td>
      <td>'.$row['STATUS'].'</td>
      </tr>
      <tr>
      <td style="height:30px" >DESCRIPTION</td>
      <td>'.$row['DESCRIPTION'].'</td>
      <td>STATE</td>
      <td>'.$row['STATE'].'</td>
      </tr>
      <tr>
      <td></td>
      <td></td>
      <td>CITY</td>
      <td>'.$row['CITY'].'</td>
      </tr>
      <tr>
      <td></td>
      <td></td>
      <td>ADDRESS</td>
      <td>'.$row['ADDRESS'].'</td>
      </tr>
      <tr>
      <td>SELLING PRICE</td>
      <td>'.$row['SELLINGPRICE'].'</td>
      <td>PINCODE</td>
      <td>'.$row['PINCODE'].'</td>
      </tr>
      <tr>
      <td><a class="button" href="tenent_registration(buy).php">buy</a></td>
      <td></td>
      <td>LANDMARK</td>
      <td>'.$row['LANDMARK'].'</td>
      </table> </center>';
  
    }
    echo '<br><br><br><br><br><br>';
  
  }
    
  }else{
     echo '<center><h1>Oops ! NO HOUSES FOUND </h1></center> ';
  }
  
  
  
  }


 


    else if(isset($_POST['search_state']) && trim($_POST['search_state']) !== "" && isset($_POST['search_city'])&& trim($_POST['search_city']) !== "" && isset($_POST['room_status'])&& trim($_POST['room_status']) !== "" && isset($_POST['select_room'])&& trim($_POST['select_room']) !== ""){
      /*Create query*/ 
      //echo empty($_POST['ac']);
      $qry = "SELECT * FROM sellers WHERE RENT_OR_SALE='$status' AND ROOM_TYPE='$room_type'AND STATE='$state' AND CITY='$filter_city'"; 
      
      $result = mysqli_query($link, $qry);
      
      if(mysqli_num_rows($result)>0){
        echo '<center><h1>The Houses are - </h1></center>';
      
        while ($row = mysqli_fetch_assoc($result))
        {
      
        if($row['RENT_OR_SALE']=='Rent'){
      
        echo '<center><table style="width:75%" > 
        <tr>
        <th colspan="2">OWNER DETAILS</th>
        <th colspan="2">ROOM DETAILS</th>
        </tr>
      
        <tr>
        <td> FULL NAME </td> 
        <td>'.$row['FULL_NAME'].'</td>
        <td>HOUSE NO</td>
        <td>'.$row['HOUSE_NO'].'</td>
        </tr>
        <tr>
        <td>EMAIL</td>
        <td>'.$row['EMAIL'].'</td> 
        <td>ROOM TYPE</td>
        <td>'.$row['ROOM_TYPE'].'</td>
        </tr>
        <tr>
        <td>PHONE NUMBER</td>
        <td>'.$row['PHONE_NUMBER'].'</td> 
        <td>AC/NOT</td>
        <td>'.$row['AC_OR_NOT'].'</td>
        </tr>
        <tr>
        <td>USERNAME</td>
        <td>'.$row['USER_NAME'].'</td>
        <td>RENT/SALE</td>
        <td>'.$row['RENT_OR_SALE'].'</td>
        </tr>
        <tr>
        <td>COUNTRY</td>
        <td>'.$row['COUNTRY'].'</td>
        <td>STATUS</td>
        <td>'.$row['STATUS'].'</td>
        </tr>
        <tr>
        <td style="height:30px" >DESCRIPTION</td>
        <td>'.$row['DESCRIPTION'].'</td>
        <td>STATE</td>
        <td>'.$row['STATE'].'</td>
        </tr>
        <tr>
        <td></td>
        <td></td>
        <td>CITY</td>
        <td>'.$row['CITY'].'</td>
        </tr>
        <tr>
        <td></td>
        <td></td>
        <td>ADDRESS</td>
        <td>'.$row['ADDRESS'].'</td>
        </tr>
        <tr>
        <td>RENT PER DAY </td>
        <td>'.$row['RENTPRICE'].'</td>
        <td>PINCODE</td>
        <td>'.$row['PINCODE'].'</td>
        </tr>
        <tr>
        <td><a class="button" href="tenent_registration(rent).php">rent</a></td>
        <td></td>
        <td>LANDMARK</td>
        <td>'.$row['LANDMARK'].'</td>
        </table> </center>';
        }
        else{
         
          echo '<center><table style="width:75%" > 
          <tr>
          <th colspan="2">OWNER DETAILS</th>
          <th colspan="2">ROOM DETAILS</th>
          </tr>
        
          <tr>
          <td> FULL NAME </td> 
          <td>'.$row['FULL_NAME'].'</td>
          <td>HOUSE NO</td>
          <td>'.$row['HOUSE_NO'].'</td>
          </tr>
          <tr>
          <td>EMAIL</td>
          <td>'.$row['EMAIL'].'</td> 
          <td>ROOM TYPE</td>
          <td>'.$row['ROOM_TYPE'].'</td>
          </tr>
          <tr>
          <td>PHONE NUMBER</td>
          <td>'.$row['PHONE_NUMBER'].'</td> 
          <td>AC/NOT</td>
          <td>'.$row['AC_OR_NOT'].'</td>
          </tr>
          <tr>
          <td>USERNAME</td>
          <td>'.$row['USER_NAME'].'</td>
          <td>RENT/SALE</td>
          <td>'.$row['RENT_OR_SALE'].'</td>
          </tr>
          <tr>
          <td>COUNTRY</td>
          <td>'.$row['COUNTRY'].'</td>
          <td>STATUS</td>
          <td>'.$row['STATUS'].'</td>
          </tr>
          <tr>
          <td style="height:30px" >DESCRIPTION</td>
          <td>'.$row['DESCRIPTION'].'</td>
          <td>STATE</td>
          <td>'.$row['STATE'].'</td>
          </tr>
          <tr>
          <td></td>
          <td></td>
          <td>CITY</td>
          <td>'.$row['CITY'].'</td>
          </tr>
          <tr>
          <td></td>
          <td></td>
          <td>ADDRESS</td>
          <td>'.$row['ADDRESS'].'</td>
          </tr>
          <tr>
          <td>SELLING PRICE</td>
          <td>'.$row['SELLINGPRICE'].'</td>
          <td>PINCODE</td>
          <td>'.$row['PINCODE'].'</td>
          </tr>
          <tr>
          <td><a class="button" href="tenent_registration(buy).php">buy</a></td>
          <td></td>
          <td>LANDMARK</td>
          <td>'.$row['LANDMARK'].'</td>
          </table> </center>';
      
        }
        echo '<br><br><br><br><br><br>';
      
      }

      }else{
         echo '<center><h1>Oops ! NO HOUSES FOUND </h1></center> ';
      }
      
      
      
      }



      else if(isset($_POST['search_state']) && trim($_POST['search_state']) !== "" && isset($_POST['search_city'])&& trim($_POST['search_city']) !== ""&&isset($_POST['room_status'])&& trim($_POST['room_status']) !== ""){
        /*Create query*/ 
        //echo empty($_POST['ac']);
        $qry = "SELECT * FROM sellers WHERE RENT_OR_SALE='$status' AND STATE='$state' AND CITY='$filter_city'"; 
        
        $result = mysqli_query($link, $qry);
        
        if(mysqli_num_rows($result)>0){
          echo '<center><h1>The Houses are - </h1></center>';
        
         while ($row = mysqli_fetch_assoc($result))
  {

  if($row['RENT_OR_SALE']=='Rent'){

  echo '<center><table style="width:75%" > 
  <tr>
  <th colspan="2">OWNER DETAILS</th>
  <th colspan="2">ROOM DETAILS</th>
  </tr>

  <tr>
  <td> FULL NAME </td> 
  <td>'.$row['FULL_NAME'].'</td>
  <td>HOUSE NO</td>
  <td>'.$row['HOUSE_NO'].'</td>
  </tr>
  <tr>
  <td>EMAIL</td>
  <td>'.$row['EMAIL'].'</td> 
  <td>ROOM TYPE</td>
  <td>'.$row['ROOM_TYPE'].'</td>
  </tr>
  <tr>
  <td>PHONE NUMBER</td>
  <td>'.$row['PHONE_NUMBER'].'</td> 
  <td>AC/NOT</td>
  <td>'.$row['AC_OR_NOT'].'</td>
  </tr>
  <tr>
  <td>USERNAME</td>
  <td>'.$row['USER_NAME'].'</td>
  <td>RENT/SALE</td>
  <td>'.$row['RENT_OR_SALE'].'</td>
  </tr>
  <tr>
  <td>COUNTRY</td>
  <td>'.$row['COUNTRY'].'</td>
  <td>STATUS</td>
  <td>'.$row['STATUS'].'</td>
  </tr>
  <tr>
  <td style="height:30px" >DESCRIPTION</td>
  <td>'.$row['DESCRIPTION'].'</td>
  <td>STATE</td>
  <td>'.$row['STATE'].'</td>
  </tr>
  <tr>
  <td></td>
  <td></td>
  <td>CITY</td>
  <td>'.$row['CITY'].'</td>
  </tr>
  <tr>
  <td></td>
  <td></td>
  <td>ADDRESS</td>
  <td>'.$row['ADDRESS'].'</td>
  </tr>
  <tr>
  <td>RENT PER DAY </td>
  <td>'.$row['RENTPRICE'].'</td>
  <td>PINCODE</td>
  <td>'.$row['PINCODE'].'</td>
  </tr>
  <tr>
  <td><a class="button" href="tenent_registration(rent).php">Rent</a></td>
  <td></td>
  <td>LANDMARK</td>
  <td>'.$row['LANDMARK'].'</td>
  </table> </center>';
  }
  else{
   
    echo '<center><table style="width:75%" > 
    <tr>
    <th colspan="2">OWNER DETAILS</th>
    <th colspan="2">ROOM DETAILS</th>
    </tr>
  
    <tr>
    <td> FULL NAME </td> 
    <td>'.$row['FULL_NAME'].'</td>
    <td>HOUSE NO</td>
    <td>'.$row['HOUSE_NO'].'</td>
    </tr>
    <tr>
    <td>EMAIL</td>
    <td>'.$row['EMAIL'].'</td> 
    <td>ROOM TYPE</td>
    <td>'.$row['ROOM_TYPE'].'</td>
    </tr>
    <tr>
    <td>PHONE NUMBER</td>
    <td>'.$row['PHONE_NUMBER'].'</td> 
    <td>AC/NOT</td>
    <td>'.$row['AC_OR_NOT'].'</td>
    </tr>
    <tr>
    <td>USERNAME</td>
    <td>'.$row['USER_NAME'].'</td>
    <td>RENT/SALE</td>
    <td>'.$row['RENT_OR_SALE'].'</td>
    </tr>
    <tr>
    <td>COUNTRY</td>
    <td>'.$row['COUNTRY'].'</td>
    <td>STATUS</td>
    <td>'.$row['STATUS'].'</td>
    </tr>
    <tr>
    <td style="height:30px" >DESCRIPTION</td>
    <td>'.$row['DESCRIPTION'].'</td>
    <td>STATE</td>
    <td>'.$row['STATE'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td>CITY</td>
    <td>'.$row['CITY'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td>ADDRESS</td>
    <td>'.$row['ADDRESS'].'</td>
    </tr>
    <tr>
    <td>SELLING PRICE</td>
    <td>'.$row['SELLINGPRICE'].'</td>
    <td>PINCODE</td>
    <td>'.$row['PINCODE'].'</td>
    </tr>
    <tr>
    <td><a class="button" href="tenent_registration(buy).php">buy</a></td>
    <td></td>
    <td>LANDMARK</td>
    <td>'.$row['LANDMARK'].'</td>
    </table> </center>';

  }
  echo '<br><br><br><br><br><br>';

}
        }else{
           echo '<center><h1>Oops ! NO HOUSES FOUND </h1></center> ';
        }
        
        
        
        }
  




       else if(isset($_POST['search_state']) && trim($_POST['search_state']) !== ""  && isset($_POST['ac']) && trim($_POST['ac']) !== ""&& isset($_POST['room_status'])&& trim($_POST['room_status']) !== ""){
          /*Create query*/ 
          //echo empty($_POST['ac']);
          $qry = "SELECT  * FROM sellers WHERE RENT_OR_SALE='$status AND STATE='$state'  AND AC_OR_NOT= '$conditioner' "; 
          
          $result = mysqli_query($link, $qry);
          
          if(mysqli_num_rows($result)>0){
            echo '<center><h1>The Houses are - </h1></center>';
            while ($row = mysqli_fetch_assoc($result))
            {
          
            if($row['RENT_OR_SALE']=='Rent'){
          
            echo '<center><table style="width:75%" > 
            <tr>
            <th colspan="2">OWNER DETAILS</th>
            <th colspan="2">ROOM DETAILS</th>
            </tr>
          
            <tr>
            <td> FULL NAME </td> 
            <td>'.$row['FULL_NAME'].'</td>
            <td>HOUSE NO</td>
            <td>'.$row['HOUSE_NO'].'</td>
            </tr>
            <tr>
            <td>EMAIL</td>
            <td>'.$row['EMAIL'].'</td> 
            <td>ROOM TYPE</td>
            <td>'.$row['ROOM_TYPE'].'</td>
            </tr>
            <tr>
            <td>PHONE NUMBER</td>
            <td>'.$row['PHONE_NUMBER'].'</td> 
            <td>AC/NOT</td>
            <td>'.$row['AC_OR_NOT'].'</td>
            </tr>
            <tr>
            <td>USERNAME</td>
            <td>'.$row['USER_NAME'].'</td>
            <td>RENT/SALE</td>
            <td>'.$row['RENT_OR_SALE'].'</td>
            </tr>
            <tr>
            <td>COUNTRY</td>
            <td>'.$row['COUNTRY'].'</td>
            <td>STATUS</td>
            <td>'.$row['STATUS'].'</td>
            </tr>
            <tr>
            <td style="height:30px" >DESCRIPTION</td>
            <td>'.$row['DESCRIPTION'].'</td>
            <td>STATE</td>
            <td>'.$row['STATE'].'</td>
            </tr>
            <tr>
            <td></td>
            <td></td>
            <td>CITY</td>
            <td>'.$row['CITY'].'</td>
            </tr>
            <tr>
            <td></td>
            <td></td>
            <td>ADDRESS</td>
            <td>'.$row['ADDRESS'].'</td>
            </tr>
            <tr>
            <td>RENT PER DAY </td>
            <td>'.$row['RENTPRICE'].'</td>
            <td>PINCODE</td>
            <td>'.$row['PINCODE'].'</td>
            </tr>
            <tr>
            <td><a class="button" href="tenent_registration(rent).php">Rent</a></td>
            <td></td>
            <td>LANDMARK</td>
            <td>'.$row['LANDMARK'].'</td>
            </table> </center>';
            }
            else{
             
              echo '<center><table style="width:75%" > 
              <tr>
              <th colspan="2">OWNER DETAILS</th>
              <th colspan="2">ROOM DETAILS</th>
              </tr>
            
              <tr>
              <td> FULL NAME </td> 
              <td>'.$row['FULL_NAME'].'</td>
              <td>HOUSE NO</td>
              <td>'.$row['HOUSE_NO'].'</td>
              </tr>
              <tr>
              <td>EMAIL</td>
              <td>'.$row['EMAIL'].'</td> 
              <td>ROOM TYPE</td>
              <td>'.$row['ROOM_TYPE'].'</td>
              </tr>
              <tr>
              <td>PHONE NUMBER</td>
              <td>'.$row['PHONE_NUMBER'].'</td> 
              <td>AC/NOT</td>
              <td>'.$row['AC_OR_NOT'].'</td>
              </tr>
              <tr>
              <td>USERNAME</td>
              <td>'.$row['USER_NAME'].'</td>
              <td>RENT/SALE</td>
              <td>'.$row['RENT_OR_SALE'].'</td>
              </tr>
              <tr>
              <td>COUNTRY</td>
              <td>'.$row['COUNTRY'].'</td>
              <td>STATUS</td>
              <td>'.$row['STATUS'].'</td>
              </tr>
              <tr>
              <td style="height:30px" >DESCRIPTION</td>
              <td>'.$row['DESCRIPTION'].'</td>
              <td>STATE</td>
              <td>'.$row['STATE'].'</td>
              </tr>
              <tr>
              <td></td>
              <td></td>
              <td>CITY</td>
              <td>'.$row['CITY'].'</td>
              </tr>
              <tr>
              <td></td>
              <td></td>
              <td>ADDRESS</td>
              <td>'.$row['ADDRESS'].'</td>
              </tr>
              <tr>
              <td>SELLING PRICE</td>
              <td>'.$row['SELLINGPRICE'].'</td>
              <td>PINCODE</td>
              <td>'.$row['PINCODE'].'</td>
              </tr>
              <tr>
              <td><a class="button" href="tenent_registration(buy).php">buy</a></td>
              <td></td>
              <td>LANDMARK</td>
              <td>'.$row['LANDMARK'].'</td>
              </table> </center>';
          
            }
            echo '<br><br><br><br><br><br>';
          
          }
          
          }else{
             echo '<center><h1>Oops ! NO HOUSES FOUND </h1></center> ';
          }
          
          
          
          }

          else if(isset($_POST['search_state']) && trim($_POST['search_state']) !== ""&& isset($_POST['ac']) && trim($_POST['ac']) !== "" && isset($_POST['select_room'])&& trim($_POST['select_room']) !== ""){
            /*Create query*/ 
            //echo empty($_POST['ac']);
            $qry = "SELECT  * FROM sellers WHERE  ROOM_TYPE='$room_type'AND STATE='$state' AND AC_OR_NOT= '$conditioner' "; 
            
            $result = mysqli_query($link, $qry);
            
            if(mysqli_num_rows($result)>0){
              echo '<center><h1>The Houses are - </h1></center>';
              while ($row = mysqli_fetch_assoc($result))
              {
            
              if($row['RENT_OR_SALE']=='Rent'){
            
              echo '<center><table style="width:75%" > 
              <tr>
              <th colspan="2">OWNER DETAILS</th>
              <th colspan="2">ROOM DETAILS</th>
              </tr>
            
              <tr>
              <td> FULL NAME </td> 
              <td>'.$row['FULL_NAME'].'</td>
              <td>HOUSE NO</td>
              <td>'.$row['HOUSE_NO'].'</td>
              </tr>
              <tr>
              <td>EMAIL</td>
              <td>'.$row['EMAIL'].'</td> 
              <td>ROOM TYPE</td>
              <td>'.$row['ROOM_TYPE'].'</td>
              </tr>
              <tr>
              <td>PHONE NUMBER</td>
              <td>'.$row['PHONE_NUMBER'].'</td> 
              <td>AC/NOT</td>
              <td>'.$row['AC_OR_NOT'].'</td>
              </tr>
              <tr>
              <td>USERNAME</td>
              <td>'.$row['USER_NAME'].'</td>
              <td>RENT/SALE</td>
              <td>'.$row['RENT_OR_SALE'].'</td>
              </tr>
              <tr>
              <td>COUNTRY</td>
              <td>'.$row['COUNTRY'].'</td>
              <td>STATUS</td>
              <td>'.$row['STATUS'].'</td>
              </tr>
              <tr>
              <td style="height:30px" >DESCRIPTION</td>
              <td>'.$row['DESCRIPTION'].'</td>
              <td>STATE</td>
              <td>'.$row['STATE'].'</td>
              </tr>
              <tr>
              <td></td>
              <td></td>
              <td>CITY</td>
              <td>'.$row['CITY'].'</td>
              </tr>
              <tr>
              <td></td>
              <td></td>
              <td>ADDRESS</td>
              <td>'.$row['ADDRESS'].'</td>
              </tr>
              <tr>
              <td>RENT PER DAY </td>
              <td>'.$row['RENTPRICE'].'</td>
              <td>PINCODE</td>
              <td>'.$row['PINCODE'].'</td>
              </tr>
              <tr>
              <td><a class="button" href="tenent_registration(rent).php">Rent</a></td>
              <td></td>
              <td>LANDMARK</td>
              <td>'.$row['LANDMARK'].'</td>
              </table> </center>';
              }
              else{
               
                echo '<center><table style="width:75%" > 
                <tr>
                <th colspan="2">OWNER DETAILS</th>
                <th colspan="2">ROOM DETAILS</th>
                </tr>
              
                <tr>
                <td> FULL NAME </td> 
                <td>'.$row['FULL_NAME'].'</td>
                <td>HOUSE NO</td>
                <td>'.$row['HOUSE_NO'].'</td>
                </tr>
                <tr>
                <td>EMAIL</td>
                <td>'.$row['EMAIL'].'</td> 
                <td>ROOM TYPE</td>
                <td>'.$row['ROOM_TYPE'].'</td>
                </tr>
                <tr>
                <td>PHONE NUMBER</td>
                <td>'.$row['PHONE_NUMBER'].'</td> 
                <td>AC/NOT</td>
                <td>'.$row['AC_OR_NOT'].'</td>
                </tr>
                <tr>
                <td>USERNAME</td>
                <td>'.$row['USER_NAME'].'</td>
                <td>RENT/SALE</td>
                <td>'.$row['RENT_OR_SALE'].'</td>
                </tr>
                <tr>
                <td>COUNTRY</td>
                <td>'.$row['COUNTRY'].'</td>
                <td>STATUS</td>
                <td>'.$row['STATUS'].'</td>
                </tr>
                <tr>
                <td style="height:30px" >DESCRIPTION</td>
                <td>'.$row['DESCRIPTION'].'</td>
                <td>STATE</td>
                <td>'.$row['STATE'].'</td>
                </tr>
                <tr>
                <td></td>
                <td></td>
                <td>CITY</td>
                <td>'.$row['CITY'].'</td>
                </tr>
                <tr>
                <td></td>
                <td></td>
                <td>ADDRESS</td>
                <td>'.$row['ADDRESS'].'</td>
                </tr>
                <tr>
                <td>SELLING PRICE</td>
                <td>'.$row['SELLINGPRICE'].'</td>
                <td>PINCODE</td>
                <td>'.$row['PINCODE'].'</td>
                </tr>
                <tr>
                <td><a class="button" href="tenent_registration(buy).php">buy</a></td>
                <td></td>
                <td>LANDMARK</td>
                <td>'.$row['LANDMARK'].'</td>
                </table> </center>';
            
              }
              echo '<br><br><br><br><br><br>';
            
            }
            
            }else{
               echo '<center><h1>Oops ! NO HOUSES FOUND </h1></center> ';
            }
            
            
            
            }

            else if(isset($_POST['search_state']) && trim($_POST['search_state']) !== "" && isset($_POST['room_status'])&& trim($_POST['room_status']) !== "" && isset($_POST['select_room'])&& trim($_POST['select_room']) !== ""){
              /*Create query*/ 
              //echo empty($_POST['ac']);
              $qry = "SELECT  * FROM sellers WHERE RENT_OR_SALE='$status' AND ROOM_TYPE='$room_type'AND STATE='$state' "; 
              
              $result = mysqli_query($link, $qry);
              
              if(mysqli_num_rows($result)>0){
                echo '<center><h1>The Houses are - </h1></center>';
                while ($row = mysqli_fetch_assoc($result))
                {
              
                if($row['RENT_OR_SALE']=='Rent'){
              
                echo '<center><table style="width:75%" > 
                <tr>
                <th colspan="2">OWNER DETAILS</th>
                <th colspan="2">ROOM DETAILS</th>
                </tr>
              
                <tr>
                <td> FULL NAME </td> 
                <td>'.$row['FULL_NAME'].'</td>
                <td>HOUSE NO</td>
                <td>'.$row['HOUSE_NO'].'</td>
                </tr>
                <tr>
                <td>EMAIL</td>
                <td>'.$row['EMAIL'].'</td> 
                <td>ROOM TYPE</td>
                <td>'.$row['ROOM_TYPE'].'</td>
                </tr>
                <tr>
                <td>PHONE NUMBER</td>
                <td>'.$row['PHONE_NUMBER'].'</td> 
                <td>AC/NOT</td>
                <td>'.$row['AC_OR_NOT'].'</td>
                </tr>
                <tr>
                <td>USERNAME</td>
                <td>'.$row['USER_NAME'].'</td>
                <td>RENT/SALE</td>
                <td>'.$row['RENT_OR_SALE'].'</td>
                </tr>
                <tr>
                <td>COUNTRY</td>
                <td>'.$row['COUNTRY'].'</td>
                <td>STATUS</td>
                <td>'.$row['STATUS'].'</td>
                </tr>
                <tr>
                <td style="height:30px" >DESCRIPTION</td>
                <td>'.$row['DESCRIPTION'].'</td>
                <td>STATE</td>
                <td>'.$row['STATE'].'</td>
                </tr>
                <tr>
                <td></td>
                <td></td>
                <td>CITY</td>
                <td>'.$row['CITY'].'</td>
                </tr>
                <tr>
                <td></td>
                <td></td>
                <td>ADDRESS</td>
                <td>'.$row['ADDRESS'].'</td>
                </tr>
                <tr>
                <td>RENT PER DAY </td>
                <td>'.$row['RENTPRICE'].'</td>
                <td>PINCODE</td>
                <td>'.$row['PINCODE'].'</td>
                </tr>
                <tr>
                <td><a class="button" href="tenent_registration(rent).php">Rent</a></td>
                <td></td>
                <td>LANDMARK</td>
                <td>'.$row['LANDMARK'].'</td>
                </table> </center>';
                }
                else{
                 
                  echo '<center><table style="width:75%" > 
                  <tr>
                  <th colspan="2">OWNER DETAILS</th>
                  <th colspan="2">ROOM DETAILS</th>
                  </tr>
                
                  <tr>
                  <td> FULL NAME </td> 
                  <td>'.$row['FULL_NAME'].'</td>
                  <td>HOUSE NO</td>
                  <td>'.$row['HOUSE_NO'].'</td>
                  </tr>
                  <tr>
                  <td>EMAIL</td>
                  <td>'.$row['EMAIL'].'</td> 
                  <td>ROOM TYPE</td>
                  <td>'.$row['ROOM_TYPE'].'</td>
                  </tr>
                  <tr>
                  <td>PHONE NUMBER</td>
                  <td>'.$row['PHONE_NUMBER'].'</td> 
                  <td>AC/NOT</td>
                  <td>'.$row['AC_OR_NOT'].'</td>
                  </tr>
                  <tr>
                  <td>USERNAME</td>
                  <td>'.$row['USER_NAME'].'</td>
                  <td>RENT/SALE</td>
                  <td>'.$row['RENT_OR_SALE'].'</td>
                  </tr>
                  <tr>
                  <td>COUNTRY</td>
                  <td>'.$row['COUNTRY'].'</td>
                  <td>STATUS</td>
                  <td>'.$row['STATUS'].'</td>
                  </tr>
                  <tr>
                  <td style="height:30px" >DESCRIPTION</td>
                  <td>'.$row['DESCRIPTION'].'</td>
                  <td>STATE</td>
                  <td>'.$row['STATE'].'</td>
                  </tr>
                  <tr>
                  <td></td>
                  <td></td>
                  <td>CITY</td>
                  <td>'.$row['CITY'].'</td>
                  </tr>
                  <tr>
                  <td></td>
                  <td></td>
                  <td>ADDRESS</td>
                  <td>'.$row['ADDRESS'].'</td>
                  </tr>
                  <tr>
                  <td>SELLING PRICE</td>
                  <td>'.$row['SELLINGPRICE'].'</td>
                  <td>PINCODE</td>
                  <td>'.$row['PINCODE'].'</td>
                  </tr>
                  <tr>
                  <td><a class="button" href="tenent_registration(buy).php">buy</a></td>
                  <td></td>
                  <td>LANDMARK</td>
                  <td>'.$row['LANDMARK'].'</td>
                  </table> </center>';
              
                }
                echo '<br><br><br><br><br><br>';
              
              }
              
              }else{
                 echo '<center><h1>Oops ! NO HOUSES FOUND </h1></center> ';
              }
              
              
              
              }




       else if(isset($_POST['search_state']) && trim($_POST['search_state']) !== "" && isset($_POST['search_city'])&& trim($_POST['search_city']) !== "" && isset($_POST['select_room'])&& trim($_POST['select_room']) !== ""){
          /*Create query*/ 
          //echo empty($_POST['ac']);
          $qry = "SELECT  * FROM sellers WHERE ROOM_TYPE='$room_type'AND STATE='$state' AND CITY='$filter_city' "; 
          
          $result = mysqli_query($link, $qry);
          
          if(mysqli_num_rows($result)>0){
            echo '<center><h1>The Houses are - </h1></center>';
          
            while ($row = mysqli_fetch_assoc($result))
            {
          
            if($row['RENT_OR_SALE']=='Rent'){
          
            echo '<center><table style="width:75%" > 
            <tr>
            <th colspan="2">OWNER DETAILS</th>
            <th colspan="2">ROOM DETAILS</th>
            </tr>
          
            <tr>
            <td> FULL NAME </td> 
            <td>'.$row['FULL_NAME'].'</td>
            <td>HOUSE NO</td>
            <td>'.$row['HOUSE_NO'].'</td>
            </tr>
            <tr>
            <td>EMAIL</td>
            <td>'.$row['EMAIL'].'</td> 
            <td>ROOM TYPE</td>
            <td>'.$row['ROOM_TYPE'].'</td>
            </tr>
            <tr>
            <td>PHONE NUMBER</td>
            <td>'.$row['PHONE_NUMBER'].'</td> 
            <td>AC/NOT</td>
            <td>'.$row['AC_OR_NOT'].'</td>
            </tr>
            <tr>
            <td>USERNAME</td>
            <td>'.$row['USER_NAME'].'</td>
            <td>RENT/SALE</td>
            <td>'.$row['RENT_OR_SALE'].'</td>
            </tr>
            <tr>
            <td>COUNTRY</td>
            <td>'.$row['COUNTRY'].'</td>
            <td>STATUS</td>
            <td>'.$row['STATUS'].'</td>
            </tr>
            <tr>
            <td style="height:30px" >DESCRIPTION</td>
            <td>'.$row['DESCRIPTION'].'</td>
            <td>STATE</td>
            <td>'.$row['STATE'].'</td>
            </tr>
            <tr>
            <td></td>
            <td></td>
            <td>CITY</td>
            <td>'.$row['CITY'].'</td>
            </tr>
            <tr>
            <td></td>
            <td></td>
            <td>ADDRESS</td>
            <td>'.$row['ADDRESS'].'</td>
            </tr>
            <tr>
            <td>RENT PER DAY </td>
            <td>'.$row['RENTPRICE'].'</td>
            <td>PINCODE</td>
            <td>'.$row['PINCODE'].'</td>
            </tr>
            <tr>
            <td><a class="button" href="tenent_registration(rent).php">Rent</a></td>
            <td></td>
            <td>LANDMARK</td>
            <td>'.$row['LANDMARK'].'</td>
            </table> </center>';
            }
            else{
             
              echo '<center><table style="width:75%" > 
              <tr>
              <th colspan="2">OWNER DETAILS</th>
              <th colspan="2">ROOM DETAILS</th>
              </tr>
            
              <tr>
              <td> FULL NAME </td> 
              <td>'.$row['FULL_NAME'].'</td>
              <td>HOUSE NO</td>
              <td>'.$row['HOUSE_NO'].'</td>
              </tr>
              <tr>
              <td>EMAIL</td>
              <td>'.$row['EMAIL'].'</td> 
              <td>ROOM TYPE</td>
              <td>'.$row['ROOM_TYPE'].'</td>
              </tr>
              <tr>
              <td>PHONE NUMBER</td>
              <td>'.$row['PHONE_NUMBER'].'</td> 
              <td>AC/NOT</td>
              <td>'.$row['AC_OR_NOT'].'</td>
              </tr>
              <tr>
              <td>USERNAME</td>
              <td>'.$row['USER_NAME'].'</td>
              <td>RENT/SALE</td>
              <td>'.$row['RENT_OR_SALE'].'</td>
              </tr>
              <tr>
              <td>COUNTRY</td>
              <td>'.$row['COUNTRY'].'</td>
              <td>STATUS</td>
              <td>'.$row['STATUS'].'</td>
              </tr>
              <tr>
              <td style="height:30px" >DESCRIPTION</td>
              <td>'.$row['DESCRIPTION'].'</td>
              <td>STATE</td>
              <td>'.$row['STATE'].'</td>
              </tr>
              <tr>
              <td></td>
              <td></td>
              <td>CITY</td>
              <td>'.$row['CITY'].'</td>
              </tr>
              <tr>
              <td></td>
              <td></td>
              <td>ADDRESS</td>
              <td>'.$row['ADDRESS'].'</td>
              </tr>
              <tr>
              <td>SELLING PRICE</td>
              <td>'.$row['SELLINGPRICE'].'</td>
              <td>PINCODE</td>
              <td>'.$row['PINCODE'].'</td>
              </tr>
              <tr>
              <td><a class="button" href="tenent_registration(buy).php">buy</a></td>
              <td></td>
              <td>LANDMARK</td>
              <td>'.$row['LANDMARK'].'</td>
              </table> </center>';
          
            }
            echo '<br><br><br><br><br><br>';
          
          }
          }else{
             echo '<center><h1>Oops ! NO HOUSES FOUND </h1></center> ';
          }
          
          
          
          }



else if(isset($_POST['search_state']) && trim($_POST['search_state']) !== "" && isset($_POST['search_city'])&& trim($_POST['search_city']) !== "" && isset($_POST['ac']) && trim($_POST['ac']) !== ""){

 $qry = "SELECT * FROM sellers WHERE  STATE='$state' AND CITY='$filter_city' AND AC_OR_NOT= '$conditioner' "; 

  /*Execute query*/ 
  $result = mysqli_query($link, $qry);
  
  if(mysqli_num_rows($result)>0){
    echo '<center><h1>The Houses are - </h1></center>';
   
    while ($row = mysqli_fetch_assoc($result))
    {
  
    if($row['RENT_OR_SALE']=='Rent'){
  
    echo '<center><table style="width:75%" > 
    <tr>
    <th colspan="2">OWNER DETAILS</th>
    <th colspan="2">ROOM DETAILS</th>
    </tr>
  
    <tr>
    <td> FULL NAME </td> 
    <td>'.$row['FULL_NAME'].'</td>
    <td>HOUSE NO</td>
    <td>'.$row['HOUSE_NO'].'</td>
    </tr>
    <tr>
    <td>EMAIL</td>
    <td>'.$row['EMAIL'].'</td> 
    <td>ROOM TYPE</td>
    <td>'.$row['ROOM_TYPE'].'</td>
    </tr>
    <tr>
    <td>PHONE NUMBER</td>
    <td>'.$row['PHONE_NUMBER'].'</td> 
    <td>AC/NOT</td>
    <td>'.$row['AC_OR_NOT'].'</td>
    </tr>
    <tr>
    <td>USERNAME</td>
    <td>'.$row['USER_NAME'].'</td>
    <td>RENT/SALE</td>
    <td>'.$row['RENT_OR_SALE'].'</td>
    </tr>
    <tr>
    <td>COUNTRY</td>
    <td>'.$row['COUNTRY'].'</td>
    <td>STATUS</td>
    <td>'.$row['STATUS'].'</td>
    </tr>
    <tr>
    <td style="height:30px" >DESCRIPTION</td>
    <td>'.$row['DESCRIPTION'].'</td>
    <td>STATE</td>
    <td>'.$row['STATE'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td>CITY</td>
    <td>'.$row['CITY'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td>ADDRESS</td>
    <td>'.$row['ADDRESS'].'</td>
    </tr>
    <tr>
    <td>RENT PER DAY </td>
    <td>'.$row['RENTPRICE'].'</td>
    <td>PINCODE</td>
    <td>'.$row['PINCODE'].'</td>
    </tr>
    <tr>
    <td><a class="button" href="tenent_registration(rent).php">Rent</a></td>
    <td></td>
    <td>LANDMARK</td>
    <td>'.$row['LANDMARK'].'</td>
    </table> </center>';
    }
    else{
     
      echo '<center><table style="width:75%" > 
      <tr>
      <th colspan="2">OWNER DETAILS</th>
      <th colspan="2">ROOM DETAILS</th>
      </tr>
    
      <tr>
      <td> FULL NAME </td> 
      <td>'.$row['FULL_NAME'].'</td>
      <td>HOUSE NO</td>
      <td>'.$row['HOUSE_NO'].'</td>
      </tr>
      <tr>
      <td>EMAIL</td>
      <td>'.$row['EMAIL'].'</td> 
      <td>ROOM TYPE</td>
      <td>'.$row['ROOM_TYPE'].'</td>
      </tr>
      <tr>
      <td>PHONE NUMBER</td>
      <td>'.$row['PHONE_NUMBER'].'</td> 
      <td>AC/NOT</td>
      <td>'.$row['AC_OR_NOT'].'</td>
      </tr>
      <tr>
      <td>USERNAME</td>
      <td>'.$row['USER_NAME'].'</td>
      <td>RENT/SALE</td>
      <td>'.$row['RENT_OR_SALE'].'</td>
      </tr>
      <tr>
      <td>COUNTRY</td>
      <td>'.$row['COUNTRY'].'</td>
      <td>STATUS</td>
      <td>'.$row['STATUS'].'</td>
      </tr>
      <tr>
      <td style="height:30px" >DESCRIPTION</td>
      <td>'.$row['DESCRIPTION'].'</td>
      <td>STATE</td>
      <td>'.$row['STATE'].'</td>
      </tr>
      <tr>
      <td></td>
      <td></td>
      <td>CITY</td>
      <td>'.$row['CITY'].'</td>
      </tr>
      <tr>
      <td></td>
      <td></td>
      <td>ADDRESS</td>
      <td>'.$row['ADDRESS'].'</td>
      </tr>
      <tr>
      <td>SELLING PRICE</td>
      <td>'.$row['SELLINGPRICE'].'</td>
      <td>PINCODE</td>
      <td>'.$row['PINCODE'].'</td>
      </tr>
      <tr>
      <td><a class="button" href="tenent_registration(buy).php">buy</a></td>
      <td></td>
      <td>LANDMARK</td>
      <td>'.$row['LANDMARK'].'</td>
      </table> </center>';
  
    }
    echo '<br><br><br><br><br><br>';
  
  }
    
    
  }else{
     echo '<center><h1>Oops ! NO HOUSES FOUND </h1></center> ';
  }
  
}


  else if(isset($_POST['search_state']) && trim($_POST['search_state']) !== "" && isset($_POST['search_city'])&& trim($_POST['search_city']) !== ""){

  $qry = "SELECT  * FROM sellers WHERE STATE='$state' AND CITY='$filter_city'"; 

  /*Execute query*/ 
  $result = mysqli_query($link, $qry);
  
  if(mysqli_num_rows($result)>0){
    echo '<center><h1>The Houses are - </h1></center>';
    while ($row = mysqli_fetch_assoc($result))
    {
  
    if($row['RENT_OR_SALE']=='Rent'){
  
    echo '<center><table style="width:75%" > 
    <tr>
    <th colspan="2">OWNER DETAILS</th>
    <th colspan="2">ROOM DETAILS</th>
    </tr>
  
    <tr>
    <td> FULL NAME </td> 
    <td>'.$row['FULL_NAME'].'</td>
    <td>HOUSE NO</td>
    <td>'.$row['HOUSE_NO'].'</td>
    </tr>
    <tr>
    <td>EMAIL</td>
    <td>'.$row['EMAIL'].'</td> 
    <td>ROOM TYPE</td>
    <td>'.$row['ROOM_TYPE'].'</td>
    </tr>
    <tr>
    <td>PHONE NUMBER</td>
    <td>'.$row['PHONE_NUMBER'].'</td> 
    <td>AC/NOT</td>
    <td>'.$row['AC_OR_NOT'].'</td>
    </tr>
    <tr>
    <td>USERNAME</td>
    <td>'.$row['USER_NAME'].'</td>
    <td>RENT/SALE</td>
    <td>'.$row['RENT_OR_SALE'].'</td>
    </tr>
    <tr>
    <td>COUNTRY</td>
    <td>'.$row['COUNTRY'].'</td>
    <td>STATUS</td>
    <td>'.$row['STATUS'].'</td>
    </tr>
    <tr>
    <td style="height:30px" >DESCRIPTION</td>
    <td>'.$row['DESCRIPTION'].'</td>
    <td>STATE</td>
    <td>'.$row['STATE'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td>CITY</td>
    <td>'.$row['CITY'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td>ADDRESS</td>
    <td>'.$row['ADDRESS'].'</td>
    </tr>
    <tr>
    <td>RENT PER DAY </td>
    <td>'.$row['RENTPRICE'].'</td>
    <td>PINCODE</td>
    <td>'.$row['PINCODE'].'</td>
    </tr>
    <tr>
    <td><a class="button" href="tenent_registration(rent).php">Rent</a></td>
    <td></td>
    <td>LANDMARK</td>
    <td>'.$row['LANDMARK'].'</td>
    </table> </center>';
    }
    else{
     
      echo '<center><table style="width:75%" > 
      <tr>
      <th colspan="2">OWNER DETAILS</th>
      <th colspan="2">ROOM DETAILS</th>
      </tr>
    
      <tr>
      <td> FULL NAME </td> 
      <td>'.$row['FULL_NAME'].'</td>
      <td>HOUSE NO</td>
      <td>'.$row['HOUSE_NO'].'</td>
      </tr>
      <tr>
      <td>EMAIL</td>
      <td>'.$row['EMAIL'].'</td> 
      <td>ROOM TYPE</td>
      <td>'.$row['ROOM_TYPE'].'</td>
      </tr>
      <tr>
      <td>PHONE NUMBER</td>
      <td>'.$row['PHONE_NUMBER'].'</td> 
      <td>AC/NOT</td>
      <td>'.$row['AC_OR_NOT'].'</td>
      </tr>
      <tr>
      <td>USERNAME</td>
      <td>'.$row['USER_NAME'].'</td>
      <td>RENT/SALE</td>
      <td>'.$row['RENT_OR_SALE'].'</td>
      </tr>
      <tr>
      <td>COUNTRY</td>
      <td>'.$row['COUNTRY'].'</td>
      <td>STATUS</td>
      <td>'.$row['STATUS'].'</td>
      </tr>
      <tr>
      <td style="height:30px" >DESCRIPTION</td>
      <td>'.$row['DESCRIPTION'].'</td>
      <td>STATE</td>
      <td>'.$row['STATE'].'</td>
      </tr>
      <tr>
      <td></td>
      <td></td>
      <td>CITY</td>
      <td>'.$row['CITY'].'</td>
      </tr>
      <tr>
      <td></td>
      <td></td>
      <td>ADDRESS</td>
      <td>'.$row['ADDRESS'].'</td>
      </tr>
      <tr>
      <td>SELLING PRICE</td>
      <td>'.$row['SELLINGPRICE'].'</td>
      <td>PINCODE</td>
      <td>'.$row['PINCODE'].'</td>
      </tr>
      <tr>
      <td><a class="button" href="tenent_registration(buy).php">buy</a></td>
      <td></td>
      <td>LANDMARK</td>
      <td>'.$row['LANDMARK'].'</td>
      </table> </center>';
  
    }
    echo '<br><br><br><br><br><br>';
  
  }
  }else{
     echo '<center><h1>Oops ! NO HOUSES FOUND </h1></center> ';
  }
}



 else if(isset($_POST['search_state']) && trim($_POST['search_state']) !== "" &&  isset($_POST['ac']) && trim($_POST['ac']) !== ""){
  /*Create query*/ 
  //echo empty($_POST['ac']);
  $qry = "SELECT  * FROM sellers WHERE STATE='$state' AND AC_OR_NOT= '$conditioner' "; 
  
  $result = mysqli_query($link, $qry);
  
  if(mysqli_num_rows($result)>0){
    echo '<center><h1>The Houses are - </h1></center>';
    while ($row = mysqli_fetch_assoc($result))
    {
  
    if($row['RENT_OR_SALE']=='Rent'){
  
    echo '<center><table style="width:75%" > 
    <tr>
    <th colspan="2">OWNER DETAILS</th>
    <th colspan="2">ROOM DETAILS</th>
    </tr>
  
    <tr>
    <td> FULL NAME </td> 
    <td>'.$row['FULL_NAME'].'</td>
    <td>HOUSE NO</td>
    <td>'.$row['HOUSE_NO'].'</td>
    </tr>
    <tr>
    <td>EMAIL</td>
    <td>'.$row['EMAIL'].'</td> 
    <td>ROOM TYPE</td>
    <td>'.$row['ROOM_TYPE'].'</td>
    </tr>
    <tr>
    <td>PHONE NUMBER</td>
    <td>'.$row['PHONE_NUMBER'].'</td> 
    <td>AC/NOT</td>
    <td>'.$row['AC_OR_NOT'].'</td>
    </tr>
    <tr>
    <td>USERNAME</td>
    <td>'.$row['USER_NAME'].'</td>
    <td>RENT/SALE</td>
    <td>'.$row['RENT_OR_SALE'].'</td>
    </tr>
    <tr>
    <td>COUNTRY</td>
    <td>'.$row['COUNTRY'].'</td>
    <td>STATUS</td>
    <td>'.$row['STATUS'].'</td>
    </tr>
    <tr>
    <td style="height:30px" >DESCRIPTION</td>
    <td>'.$row['DESCRIPTION'].'</td>
    <td>STATE</td>
    <td>'.$row['STATE'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td>CITY</td>
    <td>'.$row['CITY'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td>ADDRESS</td>
    <td>'.$row['ADDRESS'].'</td>
    </tr>
    <tr>
    <td>RENT PER DAY </td>
    <td>'.$row['RENTPRICE'].'</td>
    <td>PINCODE</td>
    <td>'.$row['PINCODE'].'</td>
    </tr>
    <tr>
    <td><a class="button" href="tenent_registration(rent).php">Rent</a></td>
    <td></td>
    <td>LANDMARK</td>
    <td>'.$row['LANDMARK'].'</td>
    </table> </center>';
    }
    else{
     
      echo '<center><table style="width:75%" > 
      <tr>
      <th colspan="2">OWNER DETAILS</th>
      <th colspan="2">ROOM DETAILS</th>
      </tr>
    
      <tr>
      <td> FULL NAME </td> 
      <td>'.$row['FULL_NAME'].'</td>
      <td>HOUSE NO</td>
      <td>'.$row['HOUSE_NO'].'</td>
      </tr>
      <tr>
      <td>EMAIL</td>
      <td>'.$row['EMAIL'].'</td> 
      <td>ROOM TYPE</td>
      <td>'.$row['ROOM_TYPE'].'</td>
      </tr>
      <tr>
      <td>PHONE NUMBER</td>
      <td>'.$row['PHONE_NUMBER'].'</td> 
      <td>AC/NOT</td>
      <td>'.$row['AC_OR_NOT'].'</td>
      </tr>
      <tr>
      <td>USERNAME</td>
      <td>'.$row['USER_NAME'].'</td>
      <td>RENT/SALE</td>
      <td>'.$row['RENT_OR_SALE'].'</td>
      </tr>
      <tr>
      <td>COUNTRY</td>
      <td>'.$row['COUNTRY'].'</td>
      <td>STATUS</td>
      <td>'.$row['STATUS'].'</td>
      </tr>
      <tr>
      <td style="height:30px" >DESCRIPTION</td>
      <td>'.$row['DESCRIPTION'].'</td>
      <td>STATE</td>
      <td>'.$row['STATE'].'</td>
      </tr>
      <tr>
      <td></td>
      <td></td>
      <td>CITY</td>
      <td>'.$row['CITY'].'</td>
      </tr>
      <tr>
      <td></td>
      <td></td>
      <td>ADDRESS</td>
      <td>'.$row['ADDRESS'].'</td>
      </tr>
      <tr>
      <td>SELLING PRICE</td>
      <td>'.$row['SELLINGPRICE'].'</td>
      <td>PINCODE</td>
      <td>'.$row['PINCODE'].'</td>
      </tr>
      <tr>
      <td><a class="button" href="tenent_registration(buy).php">Sale</a></td>
      <td></td>
      <td>LANDMARK</td>
      <td>'.$row['LANDMARK'].'</td>
      </table> </center>';
  
    }
    echo '<br><br><br><br><br><br>';
  
  }
  
  }else{
     echo '<center><h1>Oops ! NO HOUSES FOUND </h1></center> ';
  }
  
  
  
  }


 else if(isset($_POST['search_state']) && trim($_POST['search_state']) !== "" && isset($_POST['room_status'])&& trim($_POST['room_status']) !== ""){
    /*Create query*/ 
    //echo empty($_POST['ac']);
    $qry = "SELECT  * FROM sellers WHERE RENT_OR_SALE='$status' AND STATE='$state' "; 
    
    $result = mysqli_query($link, $qry);
    
    if(mysqli_num_rows($result)>0){
      echo '<center><h1>The Houses are - </h1></center>';
      while ($row = mysqli_fetch_assoc($result))
      {
    
      if($row['RENT_OR_SALE']=='Rent'){
    
      echo '<center><table style="width:75%" > 
      <tr>
      <th colspan="2">OWNER DETAILS</th>
      <th colspan="2">ROOM DETAILS</th>
      </tr>
    
      <tr>
      <td> FULL NAME </td> 
      <td>'.$row['FULL_NAME'].'</td>
      <td>HOUSE NO</td>
      <td>'.$row['HOUSE_NO'].'</td>
      </tr>
      <tr>
      <td>EMAIL</td>
      <td>'.$row['EMAIL'].'</td> 
      <td>ROOM TYPE</td>
      <td>'.$row['ROOM_TYPE'].'</td>
      </tr>
      <tr>
      <td>PHONE NUMBER</td>
      <td>'.$row['PHONE_NUMBER'].'</td> 
      <td>AC/NOT</td>
      <td>'.$row['AC_OR_NOT'].'</td>
      </tr>
      <tr>
      <td>USERNAME</td>
      <td>'.$row['USER_NAME'].'</td>
      <td>RENT/SALE</td>
      <td>'.$row['RENT_OR_SALE'].'</td>
      </tr>
      <tr>
      <td>COUNTRY</td>
      <td>'.$row['COUNTRY'].'</td>
      <td>STATUS</td>
      <td>'.$row['STATUS'].'</td>
      </tr>
      <tr>
      <td style="height:30px" >DESCRIPTION</td>
      <td>'.$row['DESCRIPTION'].'</td>
      <td>STATE</td>
      <td>'.$row['STATE'].'</td>
      </tr>
      <tr>
      <td></td>
      <td></td>
      <td>CITY</td>
      <td>'.$row['CITY'].'</td>
      </tr>
      <tr>
      <td></td>
      <td></td>
      <td>ADDRESS</td>
      <td>'.$row['ADDRESS'].'</td>
      </tr>
      <tr>
      <td>RENT PER DAY </td>
      <td>'.$row['RENTPRICE'].'</td>
      <td>PINCODE</td>
      <td>'.$row['PINCODE'].'</td>
      </tr>
      <tr>
      <td><a class="button" href="tenent_registration(rent).php">Rent</a></td>
      <td></td>
      <td>LANDMARK</td>
      <td>'.$row['LANDMARK'].'</td>
      </table> </center>';
      }
      else{
       
        echo '<center><table style="width:75%" > 
        <tr>
        <th colspan="2">OWNER DETAILS</th>
        <th colspan="2">ROOM DETAILS</th>
        </tr>
      
        <tr>
        <td> FULL NAME </td> 
        <td>'.$row['FULL_NAME'].'</td>
        <td>HOUSE NO</td>
        <td>'.$row['HOUSE_NO'].'</td>
        </tr>
        <tr>
        <td>EMAIL</td>
        <td>'.$row['EMAIL'].'</td> 
        <td>ROOM TYPE</td>
        <td>'.$row['ROOM_TYPE'].'</td>
        </tr>
        <tr>
        <td>PHONE NUMBER</td>
        <td>'.$row['PHONE_NUMBER'].'</td> 
        <td>AC/NOT</td>
        <td>'.$row['AC_OR_NOT'].'</td>
        </tr>
        <tr>
        <td>USERNAME</td>
        <td>'.$row['USER_NAME'].'</td>
        <td>RENT/SALE</td>
        <td>'.$row['RENT_OR_SALE'].'</td>
        </tr>
        <tr>
        <td>COUNTRY</td>
        <td>'.$row['COUNTRY'].'</td>
        <td>STATUS</td>
        <td>'.$row['STATUS'].'</td>
        </tr>
        <tr>
        <td style="height:30px" >DESCRIPTION</td>
        <td>'.$row['DESCRIPTION'].'</td>
        <td>STATE</td>
        <td>'.$row['STATE'].'</td>
        </tr>
        <tr>
        <td></td>
        <td></td>
        <td>CITY</td>
        <td>'.$row['CITY'].'</td>
        </tr>
        <tr>
        <td></td>
        <td></td>
        <td>ADDRESS</td>
        <td>'.$row['ADDRESS'].'</td>
        </tr>
        <tr>
        <td>SELLING PRICE</td>
        <td>'.$row['SELLINGPRICE'].'</td>
        <td>PINCODE</td>
        <td>'.$row['PINCODE'].'</td>
        </tr>
        <tr>
        <td><a class="button" href="tenent_registration(buy).php">Sale</a></td>
        <td></td>
        <td>LANDMARK</td>
        <td>'.$row['LANDMARK'].'</td>
        </table> </center>';
    
      }
      echo '<br><br><br><br><br><br>';
    
    }
    
    }else{
       echo '<center><h1>Oops ! NO HOUSES FOUND </h1></center> ';
    }
    
    
    
    }



else if(isset($_POST['search_state']) && trim($_POST['search_state']) !== "" && isset($_POST['select_room'])&& trim($_POST['select_room']) !== ""){
/*Create query*/ 
//echo empty($_POST['ac']);
$qry = "SELECT  * FROM sellers WHERE  ROOM_TYPE='$room_type'AND STATE='$state' "; 

$result = mysqli_query($link, $qry);

if(mysqli_num_rows($result)>0){
  echo '<center><h1>The Houses are - </h1></center>';
  while ($row = mysqli_fetch_assoc($result))
  {

  if($row['RENT_OR_SALE']=='Rent'){

  echo '<center><table style="width:75%" > 
  <tr>
  <th colspan="2">OWNER DETAILS</th>
  <th colspan="2">ROOM DETAILS</th>
  </tr>

  <tr>
  <td> FULL NAME </td> 
  <td>'.$row['FULL_NAME'].'</td>
  <td>HOUSE NO</td>
  <td>'.$row['HOUSE_NO'].'</td>
  </tr>
  <tr>
  <td>EMAIL</td>
  <td>'.$row['EMAIL'].'</td> 
  <td>ROOM TYPE</td>
  <td>'.$row['ROOM_TYPE'].'</td>
  </tr>
  <tr>
  <td>PHONE NUMBER</td>
  <td>'.$row['PHONE_NUMBER'].'</td> 
  <td>AC/NOT</td>
  <td>'.$row['AC_OR_NOT'].'</td>
  </tr>
  <tr>
  <td>USERNAME</td>
  <td>'.$row['USER_NAME'].'</td>
  <td>RENT/SALE</td>
  <td>'.$row['RENT_OR_SALE'].'</td>
  </tr>
  <tr>
  <td>COUNTRY</td>
  <td>'.$row['COUNTRY'].'</td>
  <td>STATUS</td>
  <td>'.$row['STATUS'].'</td>
  </tr>
  <tr>
  <td style="height:30px" >DESCRIPTION</td>
  <td>'.$row['DESCRIPTION'].'</td>
  <td>STATE</td>
  <td>'.$row['STATE'].'</td>
  </tr>
  <tr>
  <td></td>
  <td></td>
  <td>CITY</td>
  <td>'.$row['CITY'].'</td>
  </tr>
  <tr>
  <td></td>
  <td></td>
  <td>ADDRESS</td>
  <td>'.$row['ADDRESS'].'</td>
  </tr>
  <tr>
  <td>RENT PER DAY </td>
  <td>'.$row['RENTPRICE'].'</td>
  <td>PINCODE</td>
  <td>'.$row['PINCODE'].'</td>
  </tr>
  <tr>
  <td><a class="button" href="tenent_registration(rent).php">Rent</a></td>
  <td></td>
  <td>LANDMARK</td>
  <td>'.$row['LANDMARK'].'</td>
  </table> </center>';
  }
  else{
   
    echo '<center><table style="width:75%" > 
    <tr>
    <th colspan="2">OWNER DETAILS</th>
    <th colspan="2">ROOM DETAILS</th>
    </tr>
  
    <tr>
    <td> FULL NAME </td> 
    <td>'.$row['FULL_NAME'].'</td>
    <td>HOUSE NO</td>
    <td>'.$row['HOUSE_NO'].'</td>
    </tr>
    <tr>
    <td>EMAIL</td>
    <td>'.$row['EMAIL'].'</td> 
    <td>ROOM TYPE</td>
    <td>'.$row['ROOM_TYPE'].'</td>
    </tr>
    <tr>
    <td>PHONE NUMBER</td>
    <td>'.$row['PHONE_NUMBER'].'</td> 
    <td>AC/NOT</td>
    <td>'.$row['AC_OR_NOT'].'</td>
    </tr>
    <tr>
    <td>USERNAME</td>
    <td>'.$row['USER_NAME'].'</td>
    <td>RENT/SALE</td>
    <td>'.$row['RENT_OR_SALE'].'</td>
    </tr>
    <tr>
    <td>COUNTRY</td>
    <td>'.$row['COUNTRY'].'</td>
    <td>STATUS</td>
    <td>'.$row['STATUS'].'</td>
    </tr>
    <tr>
    <td style="height:30px" >DESCRIPTION</td>
    <td>'.$row['DESCRIPTION'].'</td>
    <td>STATE</td>
    <td>'.$row['STATE'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td>CITY</td>
    <td>'.$row['CITY'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td>ADDRESS</td>
    <td>'.$row['ADDRESS'].'</td>
    </tr>
    <tr>
    <td>SELLING PRICE</td>
    <td>'.$row['SELLINGPRICE'].'</td>
    <td>PINCODE</td>
    <td>'.$row['PINCODE'].'</td>
    </tr>
    <tr>
    <td><a class="button" href="tenent_registration(buy).php">Sale</a></td>
    <td></td>
    <td>LANDMARK</td>
    <td>'.$row['LANDMARK'].'</td>
    </table> </center>';

  }
  echo '<br><br><br><br><br><br>';

}

}else{
   echo '<center><h1>Oops ! NO HOUSES FOUND </h1></center> ';
}



}

else if(isset($_POST['search_state']) && trim($_POST['search_state']) !== ""){

  $qry = "SELECT  * FROM sellers WHERE  STATE='$state'"; 

  /*Execute query*/ 
  $result = mysqli_query($link, $qry);
  
  if(mysqli_num_rows($result)>0){
    echo '<center><h1>The Houses are - </h1></center>';
  
    
    while ($row = mysqli_fetch_assoc($result))
    {
  
    if($row['RENT_OR_SALE']=='Rent'){
  
    echo '<center><table style="width:75%" > 
    <tr>
    <th colspan="2">OWNER DETAILS</th>
    <th colspan="2">ROOM DETAILS</th>
    </tr>
  
    <tr>
    <td> FULL NAME </td> 
    <td>'.$row['FULL_NAME'].'</td>
    <td>HOUSE NO</td>
    <td>'.$row['HOUSE_NO'].'</td>
    </tr>
    <tr>
    <td>EMAIL</td>
    <td>'.$row['EMAIL'].'</td> 
    <td>ROOM TYPE</td>
    <td>'.$row['ROOM_TYPE'].'</td>
    </tr>
    <tr>
    <td>PHONE NUMBER</td>
    <td>'.$row['PHONE_NUMBER'].'</td> 
    <td>AC/NOT</td>
    <td>'.$row['AC_OR_NOT'].'</td>
    </tr>
    <tr>
    <td>USERNAME</td>
    <td>'.$row['USER_NAME'].'</td>
    <td>RENT/SALE</td>
    <td>'.$row['RENT_OR_SALE'].'</td>
    </tr>
    <tr>
    <td>COUNTRY</td>
    <td>'.$row['COUNTRY'].'</td>
    <td>STATUS</td>
    <td>'.$row['STATUS'].'</td>
    </tr>
    <tr>
    <td style="height:30px" >DESCRIPTION</td>
    <td>'.$row['DESCRIPTION'].'</td>
    <td>STATE</td>
    <td>'.$row['STATE'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td>CITY</td>
    <td>'.$row['CITY'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td>ADDRESS</td>
    <td>'.$row['ADDRESS'].'</td>
    </tr>
    <tr>
    <td>RENT PER DAY </td>
    <td>'.$row['RENTPRICE'].'</td>
    <td>PINCODE</td>
    <td>'.$row['PINCODE'].'</td>
    </tr>
    <tr>
    <td><a class="button" href="tenent_registration(rent).php">Rent</a></td>
    <td></td>
    <td>LANDMARK</td>
    <td>'.$row['LANDMARK'].'</td>
    </table> </center>';
    }
    else{
     
      echo '<center><table style="width:75%" > 
      <tr>
      <th colspan="2">OWNER DETAILS</th>
      <th colspan="2">ROOM DETAILS</th>
      </tr>
    
      <tr>
      <td> FULL NAME </td> 
      <td>'.$row['FULL_NAME'].'</td>
      <td>HOUSE NO</td>
      <td>'.$row['HOUSE_NO'].'</td>
      </tr>
      <tr>
      <td>EMAIL</td>
      <td>'.$row['EMAIL'].'</td> 
      <td>ROOM TYPE</td>
      <td>'.$row['ROOM_TYPE'].'</td>
      </tr>
      <tr>
      <td>PHONE NUMBER</td>
      <td>'.$row['PHONE_NUMBER'].'</td> 
      <td>AC/NOT</td>
      <td>'.$row['AC_OR_NOT'].'</td>
      </tr>
      <tr>
      <td>USERNAME</td>
      <td>'.$row['USER_NAME'].'</td>
      <td>RENT/SALE</td>
      <td>'.$row['RENT_OR_SALE'].'</td>
      </tr>
      <tr>
      <td>COUNTRY</td>
      <td>'.$row['COUNTRY'].'</td>
      <td>STATUS</td>
      <td>'.$row['STATUS'].'</td>
      </tr>
      <tr>
      <td style="height:30px" >DESCRIPTION</td>
      <td>'.$row['DESCRIPTION'].'</td>
      <td>STATE</td>
      <td>'.$row['STATE'].'</td>
      </tr>
      <tr>
      <td></td>
      <td></td>
      <td>CITY</td>
      <td>'.$row['CITY'].'</td>
      </tr>
      <tr>
      <td></td>
      <td></td>
      <td>ADDRESS</td>
      <td>'.$row['ADDRESS'].'</td>
      </tr>
      <tr>
      <td>SELLING PRICE</td>
      <td>'.$row['SELLINGPRICE'].'</td>
      <td>PINCODE</td>
      <td>'.$row['PINCODE'].'</td>
      </tr>
      <tr>
      <td><a class="button" href="tenent_registration(buy).php">buy</a></td>
      <td></td>
      <td>LANDMARK</td>
      <td>'.$row['LANDMARK'].'</td>
      </table> </center>';
  
    }
    echo '<br><br><br><br><br><br>';
  
  }
    
    
  }else{
     echo '<center><h1>Oops ! NO HOUSES FOUND </h1></center> ';
   }

 } 


















































 else if(isset($_POST['search_city'])&& trim($_POST['search_city']) !== ""){


  $qry = "SELECT  * FROM sellers WHERE  CITY='$filter_city' AND STATE='$state'"; 

  /*Execute query*/ 
  $result = mysqli_query($link, $qry);
  
  if(mysqli_num_rows($result)>0){
    echo '<center><h1>The Houses are - </h1></center>';
    while ($row = mysqli_fetch_assoc($result))
    {
  
    if($row['RENT_OR_SALE']=='Rent'){
  
    echo '<center><table style="width:75%" > 
    <tr>
    <th colspan="2">OWNER DETAILS</th>
    <th colspan="2">ROOM DETAILS</th>
    </tr>
  
    <tr>
    <td> FULL NAME </td> 
    <td>'.$row['FULL_NAME'].'</td>
    <td>HOUSE NO</td>
    <td>'.$row['HOUSE_NO'].'</td>
    </tr>
    <tr>
    <td>EMAIL</td>
    <td>'.$row['EMAIL'].'</td> 
    <td>ROOM TYPE</td>
    <td>'.$row['ROOM_TYPE'].'</td>
    </tr>
    <tr>
    <td>PHONE NUMBER</td>
    <td>'.$row['PHONE_NUMBER'].'</td> 
    <td>AC/NOT</td>
    <td>'.$row['AC_OR_NOT'].'</td>
    </tr>
    <tr>
    <td>USERNAME</td>
    <td>'.$row['USER_NAME'].'</td>
    <td>RENT/SALE</td>
    <td>'.$row['RENT_OR_SALE'].'</td>
    </tr>
    <tr>
    <td>COUNTRY</td>
    <td>'.$row['COUNTRY'].'</td>
    <td>STATUS</td>
    <td>'.$row['STATUS'].'</td>
    </tr>
    <tr>
    <td style="height:30px" >DESCRIPTION</td>
    <td>'.$row['DESCRIPTION'].'</td>
    <td>STATE</td>
    <td>'.$row['STATE'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td>CITY</td>
    <td>'.$row['CITY'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td>ADDRESS</td>
    <td>'.$row['ADDRESS'].'</td>
    </tr>
    <tr>
    <td>RENT PER DAY </td>
    <td>'.$row['RENTPRICE'].'</td>
    <td>PINCODE</td>
    <td>'.$row['PINCODE'].'</td>
    </tr>
    <tr>
    <td><a class="button" href="tenent_registration(rent).php">Rent</a></td>
    <td></td>
    <td>LANDMARK</td>
    <td>'.$row['LANDMARK'].'</td>
    </table> </center>';
    }
    else{
     
      echo '<center><table style="width:75%" > 
      <tr>
      <th colspan="2">OWNER DETAILS</th>
      <th colspan="2">ROOM DETAILS</th>
      </tr>
    
      <tr>
      <td> FULL NAME </td> 
      <td>'.$row['FULL_NAME'].'</td>
      <td>HOUSE NO</td>
      <td>'.$row['HOUSE_NO'].'</td>
      </tr>
      <tr>
      <td>EMAIL</td>
      <td>'.$row['EMAIL'].'</td> 
      <td>ROOM TYPE</td>
      <td>'.$row['ROOM_TYPE'].'</td>
      </tr>
      <tr>
      <td>PHONE NUMBER</td>
      <td>'.$row['PHONE_NUMBER'].'</td> 
      <td>AC/NOT</td>
      <td>'.$row['AC_OR_NOT'].'</td>
      </tr>
      <tr>
      <td>USERNAME</td>
      <td>'.$row['USER_NAME'].'</td>
      <td>RENT/SALE</td>
      <td>'.$row['RENT_OR_SALE'].'</td>
      </tr>
      <tr>
      <td>COUNTRY</td>
      <td>'.$row['COUNTRY'].'</td>
      <td>STATUS</td>
      <td>'.$row['STATUS'].'</td>
      </tr>
      <tr>
      <td style="height:30px" >DESCRIPTION</td>
      <td>'.$row['DESCRIPTION'].'</td>
      <td>STATE</td>
      <td>'.$row['STATE'].'</td>
      </tr>
      <tr>
      <td></td>
      <td></td>
      <td>CITY</td>
      <td>'.$row['CITY'].'</td>
      </tr>
      <tr>
      <td></td>
      <td></td>
      <td>ADDRESS</td>
      <td>'.$row['ADDRESS'].'</td>
      </tr>
      <tr>
      <td>SELLING PRICE</td>
      <td>'.$row['SELLINGPRICE'].'</td>
      <td>PINCODE</td>
      <td>'.$row['PINCODE'].'</td>
      </tr>
      <tr>
      <td><a class="button" href="tenent_registration(buy).php">buy</a></td>
      <td></td>
      <td>LANDMARK</td>
      <td>'.$row['LANDMARK'].'</td>
      </table> </center>';
  
    }
    echo '<br><br><br><br><br><br>';
  
  }
  }else{
     echo '<center><h1>Oops ! NO HOUSES FOUND </h1></center> ';
   }
   
 } 

 else if(isset($_POST['ac'])&& trim($_POST['ac']) !== ""){


  $qry = "SELECT  * FROM sellers WHERE  AC_OR_NOT='$conditioner' AND STATE='$state'"; 

  /*Execute query*/ 
  $result = mysqli_query($link, $qry);
  
  if(mysqli_num_rows($result)>0){
    echo '<center><h1>The Houses are - </h1></center>';


    while ($row = mysqli_fetch_assoc($result))
    {
  
    if($row['RENT_OR_SALE']=='Rent'){
  
    echo '<center><table style="width:75%" > 
    <tr>
    <th colspan="2">OWNER DETAILS</th>
    <th colspan="2">ROOM DETAILS</th>
    </tr>
  
    <tr>
    <td> FULL NAME </td> 
    <td>'.$row['FULL_NAME'].'</td>
    <td>HOUSE NO</td>
    <td>'.$row['HOUSE_NO'].'</td>
    </tr>
    <tr>
    <td>EMAIL</td>
    <td>'.$row['EMAIL'].'</td> 
    <td>ROOM TYPE</td>
    <td>'.$row['ROOM_TYPE'].'</td>
    </tr>
    <tr>
    <td>PHONE NUMBER</td>
    <td>'.$row['PHONE_NUMBER'].'</td> 
    <td>AC/NOT</td>
    <td>'.$row['AC_OR_NOT'].'</td>
    </tr>
    <tr>
    <td>USERNAME</td>
    <td>'.$row['USER_NAME'].'</td>
    <td>RENT/SALE</td>
    <td>'.$row['RENT_OR_SALE'].'</td>
    </tr>
    <tr>
    <td>COUNTRY</td>
    <td>'.$row['COUNTRY'].'</td>
    <td>STATUS</td>
    <td>'.$row['STATUS'].'</td>
    </tr>
    <tr>
    <td style="height:30px" >DESCRIPTION</td>
    <td>'.$row['DESCRIPTION'].'</td>
    <td>STATE</td>
    <td>'.$row['STATE'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td>CITY</td>
    <td>'.$row['CITY'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td>ADDRESS</td>
    <td>'.$row['ADDRESS'].'</td>
    </tr>
    <tr>
    <td>RENT PER DAY </td>
    <td>'.$row['RENTPRICE'].'</td>
    <td>PINCODE</td>
    <td>'.$row['PINCODE'].'</td>
    </tr>
    <tr>
    <td><a class="button" href="tenent_registration(rent).php">Rent</a></td>
    <td></td>
    <td>LANDMARK</td>
    <td>'.$row['LANDMARK'].'</td>
    </table> </center>';
    }
    else{
     
      echo '<center><table style="width:75%" > 
      <tr>
      <th colspan="2">OWNER DETAILS</th>
      <th colspan="2">ROOM DETAILS</th>
      </tr>
    
      <tr>
      <td> FULL NAME </td> 
      <td>'.$row['FULL_NAME'].'</td>
      <td>HOUSE NO</td>
      <td>'.$row['HOUSE_NO'].'</td>
      </tr>
      <tr>
      <td>EMAIL</td>
      <td>'.$row['EMAIL'].'</td> 
      <td>ROOM TYPE</td>
      <td>'.$row['ROOM_TYPE'].'</td>
      </tr>
      <tr>
      <td>PHONE NUMBER</td>
      <td>'.$row['PHONE_NUMBER'].'</td> 
      <td>AC/NOT</td>
      <td>'.$row['AC_OR_NOT'].'</td>
      </tr>
      <tr>
      <td>USERNAME</td>
      <td>'.$row['USER_NAME'].'</td>
      <td>RENT/SALE</td>
      <td>'.$row['RENT_OR_SALE'].'</td>
      </tr>
      <tr>
      <td>COUNTRY</td>
      <td>'.$row['COUNTRY'].'</td>
      <td>STATUS</td>
      <td>'.$row['STATUS'].'</td>
      </tr>
      <tr>
      <td style="height:30px" >DESCRIPTION</td>
      <td>'.$row['DESCRIPTION'].'</td>
      <td>STATE</td>
      <td>'.$row['STATE'].'</td>
      </tr>
      <tr>
      <td></td>
      <td></td>
      <td>CITY</td>
      <td>'.$row['CITY'].'</td>
      </tr>
      <tr>
      <td></td>
      <td></td>
      <td>ADDRESS</td>
      <td>'.$row['ADDRESS'].'</td>
      </tr>
      <tr>
      <td>SELLING PRICE</td>
      <td>'.$row['SELLINGPRICE'].'</td>
      <td>PINCODE</td>
      <td>'.$row['PINCODE'].'</td>
      </tr>
      <tr>
      <td><a class="button" href="tenent_registration(buy).php">buy</a></td>
      <td></td>
      <td>LANDMARK</td>
      <td>'.$row['LANDMARK'].'</td>
      </table> </center>';
  
    }
    echo '<br><br><br><br><br><br>';
  
  }

    
  }else{
     echo '<center><h1>Oops ! NO HOUSES FOUND </h1></center> ';
   }
   
 } 

 else if(isset($_POST['room_status'])&& trim($_POST['room_status']) !== ""){


  $qry = "SELECT  * FROM sellers WHERE  RENT_OR_SALE='$status' AND STATE='$state'"; 

  /*Execute query*/ 
  $result = mysqli_query($link, $qry);
  
  if(mysqli_num_rows($result)>0){
    echo '<center><h1>The Houses are - </h1></center>';

    while ($row = mysqli_fetch_assoc($result))
    {
  
    if($row['RENT_OR_SALE']=='Rent'){
  
    echo '<center><table style="width:75%" > 
    <tr>
    <th colspan="2">OWNER DETAILS</th>
    <th colspan="2">ROOM DETAILS</th>
    </tr>
  
    <tr>
    <td> FULL NAME </td> 
    <td>'.$row['FULL_NAME'].'</td>
    <td>HOUSE NO</td>
    <td>'.$row['HOUSE_NO'].'</td>
    </tr>
    <tr>
    <td>EMAIL</td>
    <td>'.$row['EMAIL'].'</td> 
    <td>ROOM TYPE</td>
    <td>'.$row['ROOM_TYPE'].'</td>
    </tr>
    <tr>
    <td>PHONE NUMBER</td>
    <td>'.$row['PHONE_NUMBER'].'</td> 
    <td>AC/NOT</td>
    <td>'.$row['AC_OR_NOT'].'</td>
    </tr>
    <tr>
    <td>USERNAME</td>
    <td>'.$row['USER_NAME'].'</td>
    <td>RENT/SALE</td>
    <td>'.$row['RENT_OR_SALE'].'</td>
    </tr>
    <tr>
    <td>COUNTRY</td>
    <td>'.$row['COUNTRY'].'</td>
    <td>STATUS</td>
    <td>'.$row['STATUS'].'</td>
    </tr>
    <tr>
    <td style="height:30px" >DESCRIPTION</td>
    <td>'.$row['DESCRIPTION'].'</td>
    <td>STATE</td>
    <td>'.$row['STATE'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td>CITY</td>
    <td>'.$row['CITY'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td>ADDRESS</td>
    <td>'.$row['ADDRESS'].'</td>
    </tr>
    <tr>
    <td>RENT PER DAY </td>
    <td>'.$row['RENTPRICE'].'</td>
    <td>PINCODE</td>
    <td>'.$row['PINCODE'].'</td>
    </tr>
    <tr>
    <td><a class="button" href="tenent_registration(rent).php">Rent</a></td>
    <td></td>
    <td>LANDMARK</td>
    <td>'.$row['LANDMARK'].'</td>
    </table> </center>';
    }
    else{
     
      echo '<center><table style="width:75%" > 
      <tr>
      <th colspan="2">OWNER DETAILS</th>
      <th colspan="2">ROOM DETAILS</th>
      </tr>
    
      <tr>
      <td> FULL NAME </td> 
      <td>'.$row['FULL_NAME'].'</td>
      <td>HOUSE NO</td>
      <td>'.$row['HOUSE_NO'].'</td>
      </tr>
      <tr>
      <td>EMAIL</td>
      <td>'.$row['EMAIL'].'</td> 
      <td>ROOM TYPE</td>
      <td>'.$row['ROOM_TYPE'].'</td>
      </tr>
      <tr>
      <td>PHONE NUMBER</td>
      <td>'.$row['PHONE_NUMBER'].'</td> 
      <td>AC/NOT</td>
      <td>'.$row['AC_OR_NOT'].'</td>
      </tr>
      <tr>
      <td>USERNAME</td>
      <td>'.$row['USER_NAME'].'</td>
      <td>RENT/SALE</td>
      <td>'.$row['RENT_OR_SALE'].'</td>
      </tr>
      <tr>
      <td>COUNTRY</td>
      <td>'.$row['COUNTRY'].'</td>
      <td>STATUS</td>
      <td>'.$row['STATUS'].'</td>
      </tr>
      <tr>
      <td style="height:30px" >DESCRIPTION</td>
      <td>'.$row['DESCRIPTION'].'</td>
      <td>STATE</td>
      <td>'.$row['STATE'].'</td>
      </tr>
      <tr>
      <td></td>
      <td></td>
      <td>CITY</td>
      <td>'.$row['CITY'].'</td>
      </tr>
      <tr>
      <td></td>
      <td></td>
      <td>ADDRESS</td>
      <td>'.$row['ADDRESS'].'</td>
      </tr>
      <tr>
      <td>SELLING PRICE</td>
      <td>'.$row['SELLINGPRICE'].'</td>
      <td>PINCODE</td>
      <td>'.$row['PINCODE'].'</td>
      </tr>
      <tr>
      <td><a class="button" href="tenent_registration(buy).php">buy</a></td>
      <td></td>
      <td>LANDMARK</td>
      <td>'.$row['LANDMARK'].'</td>
      </table> </center>';
  
    }
    echo '<br><br><br><br><br><br>';
  
  }


    
  }else{
     echo '<center><h1>Oops ! NO HOUSES FOUND </h1></center> ';
   }
   
 } 

 else if(isset($_POST['select_room'])&& trim($_POST['select_room']) !== ""){


  $qry = "SELECT  * FROM sellers WHERE   ROOM_TYPE='$room_type' AND STATE='$state'"; 

  /*Execute query*/ 
  $result = mysqli_query($link, $qry);
  
  if(mysqli_num_rows($result)>0){
    echo '<center><h1>The Houses are - </h1></center>';
    
    while ($row = mysqli_fetch_assoc($result))
  {

  if($row['RENT_OR_SALE']=='Rent'){

  echo '<center><table style="width:75%" > 
  <tr>
  <th colspan="2">OWNER DETAILS</th>
  <th colspan="2">ROOM DETAILS</th>
  </tr>

  <tr>
  <td> FULL NAME </td> 
  <td>'.$row['FULL_NAME'].'</td>
  <td>HOUSE NO</td>
  <td>'.$row['HOUSE_NO'].'</td>
  </tr>
  <tr>
  <td>EMAIL</td>
  <td>'.$row['EMAIL'].'</td> 
  <td>ROOM TYPE</td>
  <td>'.$row['ROOM_TYPE'].'</td>
  </tr>
  <tr>
  <td>PHONE NUMBER</td>
  <td>'.$row['PHONE_NUMBER'].'</td> 
  <td>AC/NOT</td>
  <td>'.$row['AC_OR_NOT'].'</td>
  </tr>
  <tr>
  <td>USERNAME</td>
  <td>'.$row['USER_NAME'].'</td>
  <td>RENT/SALE</td>
  <td>'.$row['RENT_OR_SALE'].'</td>
  </tr>
  <tr>
  <td>COUNTRY</td>
  <td>'.$row['COUNTRY'].'</td>
  <td>STATUS</td>
  <td>'.$row['STATUS'].'</td>
  </tr>
  <tr>
  <td style="height:30px" >DESCRIPTION</td>
  <td>'.$row['DESCRIPTION'].'</td>
  <td>STATE</td>
  <td>'.$row['STATE'].'</td>
  </tr>
  <tr>
  <td></td>
  <td></td>
  <td>CITY</td>
  <td>'.$row['CITY'].'</td>
  </tr>
  <tr>
  <td></td>
  <td></td>
  <td>ADDRESS</td>
  <td>'.$row['ADDRESS'].'</td>
  </tr>
  <tr>
  <td>RENT PER DAY </td>
  <td>'.$row['RENTPRICE'].'</td>
  <td>PINCODE</td>
  <td>'.$row['PINCODE'].'</td>
  </tr>
  <tr>
  <td><a class="button" href="tenent_registration(rent).php">Rent</a></td>
  <td></td>
  <td>LANDMARK</td>
  <td>'.$row['LANDMARK'].'</td>
  </table> </center>';
  }
  else{
   
    echo '<center><table style="width:75%" > 
    <tr>
    <th colspan="2">OWNER DETAILS</th>
    <th colspan="2">ROOM DETAILS</th>
    </tr>
  
    <tr>
    <td> FULL NAME </td> 
    <td>'.$row['FULL_NAME'].'</td>
    <td>HOUSE NO</td>
    <td>'.$row['HOUSE_NO'].'</td>
    </tr>
    <tr>
    <td>EMAIL</td>
    <td>'.$row['EMAIL'].'</td> 
    <td>ROOM TYPE</td>
    <td>'.$row['ROOM_TYPE'].'</td>
    </tr>
    <tr>
    <td>PHONE NUMBER</td>
    <td>'.$row['PHONE_NUMBER'].'</td> 
    <td>AC/NOT</td>
    <td>'.$row['AC_OR_NOT'].'</td>
    </tr>
    <tr>
    <td>USERNAME</td>
    <td>'.$row['USER_NAME'].'</td>
    <td>RENT/SALE</td>
    <td>'.$row['RENT_OR_SALE'].'</td>
    </tr>
    <tr>
    <td>COUNTRY</td>
    <td>'.$row['COUNTRY'].'</td>
    <td>STATUS</td>
    <td>'.$row['STATUS'].'</td>
    </tr>
    <tr>
    <td style="height:30px" >DESCRIPTION</td>
    <td>'.$row['DESCRIPTION'].'</td>
    <td>STATE</td>
    <td>'.$row['STATE'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td>CITY</td>
    <td>'.$row['CITY'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td>ADDRESS</td>
    <td>'.$row['ADDRESS'].'</td>
    </tr>
    <tr>
    <td>SELLING PRICE</td>
    <td>'.$row['SELLINGPRICE'].'</td>
    <td>PINCODE</td>
    <td>'.$row['PINCODE'].'</td>
    </tr>
    <tr>
    <td><a class="button" href="tenent_registration(buy).php">buy</a></td>
    <td></td>
    <td>LANDMARK</td>
    <td>'.$row['LANDMARK'].'</td>
    </table> </center>';

  }
  echo '<br><br><br><br><br><br>';

}


  }else{
     echo '<center><h1>Oops ! NO HOUSES FOUND </h1></center> ';
   }
   
 } 





}






else if($_POST['all']=='search_all_houses'){

  if(isset($_POST['search_state'])&& trim($_POST['search_state']) !== ""){
    $state=$_POST['search_state'];
   }

  $link = mysqli_connect('localhost', 'root', '', 'house_rent');  
  if(!$link)
  { 
  die('Failed to connect to server: ');
  } 
  $qry = "SELECT  * FROM sellers WHERE 1 AND STATE='$state' ";

  
  $result=mysqli_query($link,$qry);
 

  if(mysqli_num_rows($result)>0){
   
  echo '<center><h1>HOUSES ARE  - </h1></center>';
 
  while ($row = mysqli_fetch_assoc($result))
  {

  if($row['RENT_OR_SALE']=='Rent'){

  echo '<center><table style="width:75%" > 
  <tr>
  <th colspan="2">OWNER DETAILS</th>
  <th colspan="2">ROOM DETAILS</th>
  </tr>

  <tr>
  <td> FULL NAME </td> 
  <td>'.$row['FULL_NAME'].'</td>
  <td>HOUSE NO</td>
  <td>'.$row['HOUSE_NO'].'</td>
  </tr>
  <tr>
  <td>EMAIL</td>
  <td>'.$row['EMAIL'].'</td> 
  <td>ROOM TYPE</td>
  <td>'.$row['ROOM_TYPE'].'</td>
  </tr>
  <tr>
  <td>PHONE NUMBER</td>
  <td>'.$row['PHONE_NUMBER'].'</td> 
  <td>AC/NOT</td>
  <td>'.$row['AC_OR_NOT'].'</td>
  </tr>
  <tr>
  <td>USERNAME</td>
  <td>'.$row['USER_NAME'].'</td>
  <td>RENT/SALE</td>
  <td>'.$row['RENT_OR_SALE'].'</td>
  </tr>
  <tr>
  <td>COUNTRY</td>
  <td>'.$row['COUNTRY'].'</td>
  <td>STATUS</td>
  <td>'.$row['STATUS'].'</td>
  </tr>
  <tr>
  <td style="height:30px" >DESCRIPTION</td>
  <td>'.$row['DESCRIPTION'].'</td>
  <td>STATE</td>
  <td>'.$row['STATE'].'</td>
  </tr>
  <tr>
  <td></td>
  <td></td>
  <td>CITY</td>
  <td>'.$row['CITY'].'</td>
  </tr>
  <tr>
  <td></td>
  <td></td>
  <td>ADDRESS</td>
  <td>'.$row['ADDRESS'].'</td>
  </tr>
  <tr>
  <td>RENT PER DAY </td>
  <td>'.$row['RENTPRICE'].'</td>
  <td>PINCODE</td>
  <td>'.$row['PINCODE'].'</td>
  </tr>
  <tr>
  <td><a class="button" href="tenent_registration(rent).php">Rent</a></td>
  <td></td>
  <td>LANDMARK</td>
  <td>'.$row['LANDMARK'].'</td>
  </table> </center>';
  }
  else{
   
    echo '<center><table style="width:75%" > 
    <tr>
    <th colspan="2">OWNER DETAILS</th>
    <th colspan="2">ROOM DETAILS</th>
    </tr>
  
    <tr>
    <td> FULL NAME </td> 
    <td>'.$row['FULL_NAME'].'</td>
    <td>HOUSE NO</td>
    <td>'.$row['HOUSE_NO'].'</td>
    </tr>
    <tr>
    <td>EMAIL</td>
    <td>'.$row['EMAIL'].'</td> 
    <td>ROOM TYPE</td>
    <td>'.$row['ROOM_TYPE'].'</td>
    </tr>
    <tr>
    <td>PHONE NUMBER</td>
    <td>'.$row['PHONE_NUMBER'].'</td> 
    <td>AC/NOT</td>
    <td>'.$row['AC_OR_NOT'].'</td>
    </tr>
    <tr>
    <td>USERNAME</td>
    <td>'.$row['USER_NAME'].'</td>
    <td>RENT/SALE</td>
    <td>'.$row['RENT_OR_SALE'].'</td>
    </tr>
    <tr>
    <td>COUNTRY</td>
    <td>'.$row['COUNTRY'].'</td>
    <td>STATUS</td>
    <td>'.$row['STATUS'].'</td>
    </tr>
    <tr>
    <td style="height:30px" >DESCRIPTION</td>
    <td>'.$row['DESCRIPTION'].'</td>
    <td>STATE</td>
    <td>'.$row['STATE'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td>CITY</td>
    <td>'.$row['CITY'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td>ADDRESS</td>
    <td>'.$row['ADDRESS'].'</td>
    </tr>
    <tr>
    <td>SELLING PRICE</td>
    <td>'.$row['SELLINGPRICE'].'</td>
    <td>PINCODE</td>
    <td>'.$row['PINCODE'].'</td>
    </tr>
    <tr>
    <td><a class="button" href="tenent_registration(buy).php">buy</a></td>
    <td></td>
    <td>LANDMARK</td>
    <td>'.$row['LANDMARK'].'</td>
    </table> </center>';

  }
  echo '<br><br><br><br><br><br>';

}

   
}else{
  echo '<center><h1>Oops ! NO HOUSES FOUND </h1></center> ';
}
}
    

?>

</body>
</html>