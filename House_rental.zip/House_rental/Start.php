<?php
session_start();
session_unset();
session_destroy();
?> 
<!DOCTYPE>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NOBROKER</title>
    <style>

        form
        {
            padding-bottom:100px;
            position:relative;
            top:60px;
        }
        nav
        {
            margin-top: 0px;
            padding-top: 5px;
            padding-left: 10px;
            background-color:#00A170;
        }
        button
        {
            position: relative;
            left:1000px;
            top:-12px;
            border-radius: 15px;
            font-size: 20px;
            padding: 9px;
            text-decoration: none;
            color: black;
        }
        .A
        {
            position: relative;
            top: 4px;
            left: 5px;
            
        }
        .xy
        {
            position: relative;
            top: 4px;
            left: 5px;
            height:40px;
        }
        .B:hover,.B:active,.B:visited,.B:link
        {
            text-decoration: none;
            color: black;
        }
        .B:hover
        {
            color:hotpink;
        }
        .B:active
        {
            color:red;
        }
        h1
        {
            text-align: center;
            color: grey;
            font-size: 36px;
            padding-top: 20px;
            font-weight: 190;
        }
        .C>.B
        {
            position: relative;
            top:-110px;
            left:650px;
            font-size: 20px;
            padding:8px;
            color:black;
            background-color: brown;
            border-radius: 0px;
        }
        .C>.B1
        {
            position: relative;
            left:654px;
            font-size: 20px;
            padding:8px;
            color:black;
            background-color:brown;
            border-radius: 0px;
        }
        div.C
        {
            display: flex;
        }
        .D
        {
            display: flex;
        }
        .ef
        {
            position:relative;
            left:700px;
            font-size: 20px;
            padding: 8px;
            padding-bottom: 0px;
        }
        .E,.F
        {
            position: relative;
            left: 400px;
            font-size: 20px;
            padding: 8px;
            padding-bottom: 0px;
        }
        .F
        {
            font-size: 14px;
            width: 500px;
        }
        .G
        {
            display: flex;
        }
        .H,.I
        {
            position: relative;
            left: 400px;
            font-size: 20px;
            padding: 8px;
            padding-top: 0px;
           
        }
        .J
        {
            padding-top: 4px;
            font-size: 21px;
        }
        .K
        {
            font-size: 21px;
        }
        body
        {
            background-image: url('data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBUSFRgSEhUYGBgYGRIYGhgYGBgYGBgYGRwaGRgYGBgcIS4lHB4rIRgYJjgmKy8xNTU1GiQ7QDs0Py40NTEBDAwMEA8QGRESGDEhGiExMTE0MTE0MTExNDQ0NDU0PzQ0NDQxNDQxMTQ0NDExND80PzE0NDUxMTExNDExNDExMf/AABEIALcBFAMBIgACEQEDEQH/xAAcAAACAgMBAQAAAAAAAAAAAAAAAQIGAwQFBwj/xABHEAABAwEEBQYKCAQFBQAAAAABAAIRAwQSITEFBkFRYRMicYGR0RYyQlJygpKhscEHFCNUorLh8DNiwtIVJENTwzRjk9Pj/8QAFgEBAQEAAAAAAAAAAAAAAAAAAAEC/8QAGxEBAQEAAwEBAAAAAAAAAAAAABEBAiExEkH/2gAMAwEAAhEDEQA/ALS17qZD2YEZcd4VlsFsbVbIwI8Zu49yrpbKjSe6m4PYcR7xtBG5aFuTla9itbarbwwIzbtB7lmOOCyMgTSapBAwEJhJA0JJoGhCCUAhRkptKCaEIQCEBCAQhCAQhCAQDsScUmZygyIQmgEIQgEIQgAmkkTuQSQoXjtCT3gCSQBxQTQuBb9a7NQfybqjZgHPehWaOKx4ITcyVo06hGBW2yoYnZvWhmoOdTdfbn+8COxdyw25tTmnB0YtO3fB2riAg7P3tA7FC4QZGBGIO1QW4Jrk2DSgPMqGDsdsPTuK6oWRIISTQCaSaBqKko5IJEJORATQSQhCACEBCAQhCASc5DnQo/FAoWRrUNbCaBoSQgaEIQNCSECcURsWtbrYyk29UeGjiQJVC1k13eRcsrcCD9pJ/DGcbujNXMot2m9P0rK0hxvOjBox6ZXmesOtte0zTpyxsukDF0bAXDBu2QO1a9pY/wA4ve4i88mcfl1ZLJZtHRJu75joWszMRXBYScS4TxJn4IVtdY34XYiBsQrR2mPDlmY0jxT++C6mkdX2ul9CGu8w+Kejzfh0LihzqbrlRpa4bD8VBtsdsWwFrMeDkVMsJ2lRWRzNy39GaRLIY8y3Ydrf0WgziVJzQcs0FsCFw9H6RNPmVMW7Du/RdxjgRIMg7QshoSTQCaSaBAKaipIBCEIBEoQgEJApoIubKbWwmhA0JJoBC17TbGUhNRzW9JxPQMyuRX1rs7Zu33ngwifahB30Ko1db3eRS9p3cFzbXrXanYMaxnUSe0lWaL3Xrtpi89waOJVP09ru2nLbM0vMGXkQ0cQdqq1d9WuTyzy7biTCdOytAutEifjvVziOZa7XXtTg6q9zh5uQ6gPiupYLFDcBBmTP6zBWxZ6LGw2IhbtMDICehWo1aVhAER0xhitpouCCJ4psYNnH9ym5vYgx3+B6skKHYkg9ACwWqysqi7UaDuO0dB2LLKFlVbtmh6lLnU5ezd5Y6vK6uxa9C0g4HA8VbgVq2rR1Ori9vO84YO7dvWrRwmgHaszWKVp0NUp403Xx5uTu53uWjZ7VJjIjZkg3ieCxMqPZixxbOwHDrGSytqBScO35d6CbNMVgMQw9IPvghSZp95MFjcMzJWqaYKgbOOpIOh4QO2Ux7RPyUqGnXHxqYPEEj3GVzDTjAYBSGG1IO/Q0ux3jSz0su0LMdIUvPb2qthhOIKkQ4DIFILF/iFLLlGdq2WuBEgyN4xVRBveQsjX3MrzeifkpBbEKrt0nUBEPkbnQfiJW9S0w4eM1p4h134ykHaQFpW/SVOgxtR5MOgNAxLiRMDqC4VfWon+G1o4uN49giO0pBalhr2tlPx3tb6TgOwKlWnTtSpgasDczmDtGPvXJqaSY0iSJKsFxtusgaYosL97ncxvvEnsWjX07aHiBcZPmyXdp7lXX6dpMwvAncMT2LSZpqpUJFOi+JgOc0sHa4BIjsuozJOJOJJMkneSc1jBZTxdtwjaeAG0rBZqdZxvVHtaIHNGJ44nuXRs1FgMgFz4zdiQOG7qVGuQSLxbdGyc+vcsRYHLrPs4dIJwWJ1CBHvRWgaMx+8lnp0CNy2MG7llp0y8ExgPig0eQkrYp0YxXfsOhebL8J2DP9F0aejaTfInpx/RSinlmyMdwWSno+rUwawjPPD4q6NoNbk0DoAWUKUUtmrlaNiFdUJRzYTQhAwmEgmgkCtDSOiadbE81/ntzPpDat5NBTrTSfZ33KmXku8lw7+Cmy04SVa61JtQXXtDhuIlc1+gKJ8W+zodI7HSrRzqdUHasweIU6mrx8ip2t+YPyWD/AAO0bH0/aeP6EGYXSi43euDrO+vYGMqODHte8MF15BvFrnYgtyhhVOt2s9pqCKcMwwPjEbNwHbKuZR6c9jYwSpsJHjH3FeTN0tbjh9ZfmfIp7vRWSjpi3MGFcnAHnMYc+gJ86j1Rwe2bsGNkR71ytJaeFAXq1J7WzF+4XMG6XNkDrVQs2sduaYJY7EjFhBwE4w6FtVLZaLS2KzgG3Q641sNvTgTJMnduSK7PhbZpzdOWDHZ7ojNc+ppR9V/KMlrLousIEOg5uaQZJ48FiZY2g5eUdn8qnyfN9VEYNOWitXN8vJcCYJywHmjAdULkvtFojJuWd53whWBzMfWd+VYKlHDqCorjxXky/MnLgOIXMttnfElzifSIz6ArfWpgT0v+C6uqmrv1h/LVB9m2IHnOGzoSjo6s2GkyzMDAAbovE4OLoxLicSelbFag0kgZSPfmAo62aFqU2Oq2NwYc3NuyzDyruwb92eUrzs6dtuIc8AiZ5mIIMb1Myq9EY0Cd3HctavpqzUzcNVgd5t5s48F59VFesftKr3YgEeK2IyutwWOjo0CBGEHYN+ZV+UejN0m13iuHaFmp1S7oXH1C0ax9ocyoC9nJuIaSQA4FsHA7p7V6VR0RQZ4tMdZJ+JWd6VV7Lo99Q81pjfkO1WKw6KDILzMZNGQO87yumBGAQpQJoQoBMIQgaEIQc5NATVAE1HrTQSQhCBJoQgFIKKkFBUPpG51Oiz+d7vZYR/WqKyy9P+mO0q8a/ul1EbmV3dppgfAqsMbj6zB2YreeI1qdl6c3n5LKyy4bcqY7Vt0GTHRUPvy6VsvaAI3GmBt2yQQMncUo0qdAAz/M/wCCyNZh6tP3qY/9h98Jf/Me9A9vrO/Koxh6rVIZ9b/gls6qaAIx9Z35VhecPVCz7fWd+Vaduc4M5rS4wMBG0cUG5onRTrZUu5Ma6Xu+Q44FYPpQf9XNFlKq6iAyOYL0iXmM88JldjRuswoMbSp2RwAJBPKMlzgJLjhtULbp9lb7SrYQ4hvNvVRJE4jBsYEnHin6qqan2xztJMpmu94zuOGA5oM3rxns2q0a06timTWpjmEEFo8gnZ6O7dluUbPpinTeHMsDGua7Bwq4gxmOZxXRq62kth1lvNc0/wCq2CJgtILPcndFSbR6c2qLaOWeTvitq/ee6GOY280iXB2BMgSIJ27NiUZet8VUdvUcRahxpvHz+S9HXm2qLotdPi14/A4r0lZ31QhCFkNCSaByosdKi525SpoJoSQg54QkmqJscEh7lGVKUDamkhA0kFKUDTBUZRKCk68vmsxu6kPxPcP6VwqWLp2B5k5xDVf9JaDo2h/KVL96GNwdAhpJGze4rk2bQFIm80ujBwxHlTIOG6Fc0cBr7og+Lc28Ydd3TxQXS4z549wC6Os9npWOk2q5r3gvbTuh4bAuucIJafNjrVYdrLSzFmqZzPLNzy8xXEdInD1Xn8SZdj61Ncz/AB1hbIoeS7mmsCYzOAZwlX2nq7ScA6X43XZjOOhN6FUa7/k+KYPwprZ1wfQ0a2m9zHvD+UyeARBZ/KZkv9yqx10s12/yFSLwb47ZlokYXOKCwg4+s/4LGcvVaupqgyjpGia4Y9gD3NALwZwEnxRvWrpK2WShVfQcyu4shpLbkHAER2oNY5+ufyrI0gP52Qa/oGOC0rTpWnUeynZab77n48oC7MQLracuJ6jwC3alnri6H0heeSwTStTQZBd5TBJ5pwEk9qDZtTQ8gNguvN6htlar2BguzJN7oGM9qyOdVpuZRFHn1A94PJWqIZGy5eJxGQMbYWlaNIiz1m0rRQOLb5utrMddLi3miqGyZ4RxQTJ/4ysTzBHS/wCC3jpiwx/Ar+7Zl5S71l0TZq1NlZjXBr4Ik44mDOKeDjasPi1UTxcO1pHzXpxK4mjtAWZtysxha4AOBvOOPRMLtLO6qSUpoUAoOMpOd1Qm0IG0SppJoGhJCDnoUQpKhpqMpygYTlRlEoJSolEpFASiUpSlBMLnaPyj+Sn/AFLeBWjYBifQp/1oKp9J9dwpUqdw3XPLy/YHNBaGdJD3H1F5DZ3n6w4SYh2EmMhsXs30msmyMO6tT97Xgryqno9oeamMmduGOHyW+PiLfpFr/qOjy5lNt6z1Yc1xLnjkRJfzBDoxzOM4r1KzHmM9BnwC8QtOkKpo06T3lzKLHMpgtZzGltwiQ0F2EDGV7dYjNNnoU/yhTfBQPpiA5Ci5wJAdUEAwcbhzjgvJy+nyXiOi+cL+26MZur6A1g1ZpW4t5Z9S60QGNLLkzJcQ5pxy7AuOPo0sUXZqRMx9nE5T4iZuZisP0PuBsb7ogcq7Amdg2qv61f8AW152Pb2XGcF6Hq9q5SsIc2i9910cxxZdB84BrRivO9bT/na/pj8jOKZ6jU0Peda6HJXQ8PZcvTcvXsLwbBjoXpGlRb71nvuss8uLl1tWL9yp40uxbF7LGYXkta0Ppfa03XXMF5rgcWkYyMc1jGuVtqSX2h5LA57JPiuAgOHGHHtV3KPV7e23fXbNeNmv3LXcIbVuARTv3wTM5RB3qpa/srfXKZtRpl4oC6aV4NuGpk4OkzM4yqeNc7a8mq60PL6beY4xLQ9zWvA6R8FGy6btFsq3rQ/lHNY0BzvGDb4MA7pJTMHcrRByyOwdy9M1cP8Ak6Hot/MV5jUOB6Dt/Venauj/ACdD0WfmU5eCxaOP2TPRC2Vq6O/hM9ELZlYU01GU0AWpoQgcolJSQCEIQc2U5UE1RKU5UJRKCcolQQgnKRcoJEFBMlRvKBaVie1yDYvqtHXGyU6j6bnulhumGPi80uDhlsUtP6dZYw01HEX7wbDSfFiZjpC8oqVOUq1KgMhz3OnLNxO0TtV48aLrrxrPZrVZxSouc519jzLS3mtDhOPFzR1qoN/fvWCowwNp6txQah809re9bzIiVp8Q9HcvVLHrpYm02B1RwLWMBFx+YaJ2LyVzyRl23fmVJoMDo4bk3KPXvDWw/wC6f/G/+1Ia7WHH7U4fyP8A7V5GWE7enLuUiwnLPZiMenDP99MmD1vw3sP+6fYf/atd+t+jnElxvHeaJJPWRK8rFM5dP7yTDHb/AHjuSYV6Fa9JaIqvNRzXBxibjXsBjCYaQJyxWEWjQ+6p21v7lRLh/cdykGnf8O5IL4LToj/udtb+5SFo0Pvf21+9URrT1dWee5EFIPTWaf0WwBrQwAAAfYnLIY3cVOprdYQ0BtWALsAMeAACMhdXl5B/ZWN4MyTGQmeP6pMHv9htDKlNj6Z5jmtLcIwIkYbFnlUnU/T7KgZZmklzWN2GOY0A4kK3ArG4rZlOVrgp31BnBTlYA9TD0GSU5UA5OUEkKKEGrcRyazQmAgw8mjk1mhEIMPJo5NZ4RCDByaVxbEIhBg5NK4tm6i4g4+k9B0LVdFek192S2ZwmJiDwHYtJmp9iblZmD2u9Wa4i4rRXPBOx/dqf4u9HgpZPu7Pxd6scIuJdFb8FLJ93Z+LvT8FLH92Z7+9WO4iEorngrY/u1PsPel4KWP7szsPerJcRcSitnVWx/dmdh70/BeyfdqfYe9WO4i4lFc8GLJ92p+yjwZsn3an7KsdxFxKK54M2T7tT9lMas2T7tT9lWK4i4lFe8G7J92pewEnasWM52al7AViuIuJRxbDoSzUHX6VFjHQRea2DBzErowti4i4lGuhbFxK6gwhAKzXUXVBjDlK+pXUrqAvoRdQgE1jlMFBNJx3ZqJcoz+/3tQZWlOVEIlBKUSkhBKUSooQSlEqKRKCYKJWOEZIMqUqMoQSlOVGUSglKJSlEoHKEpRKBpBxnh71FzkMKCaEpRKBoUZRKCSSUolA0SkSo5oJykowgFBJCSEGEFMlCFQkwhCgleReQhUEpgoQoHKEIQCjvQhBMu2RmouCEIGmEIQCEIQCEIQCiShCBNCmhCAQhCAQhCAQhCCL1IGEIQKZxSCEIGhCEH//Z');
            background-size:1700px;
            background-repeat: no-repeat;
        }
        .cc{
        margin-top:50px;
        }

.gg{
      width:30%;
      padding: 10px 3px;
      border:2px solid black;
      border-radius:10px;
      font-weight:bold;
      background-color:#DD4124;
      border-collapse: collapse;
      position: relative;
      left:300px;
}
 input {
     margin:5px 5px;
     text-align: center;
     padding:6px 6px;
     font-weight: bold;
     border-collapse: collapse;
     background-color: cornsilk;
     border:1px slod black; 
}
form
{
  padding-left:300px;
}
.cen{
    margin-left:200px;
}
.center{
  margin-left:300px;
}
.cent{
  margin-left:450px;
}
table,th{
        border:2px solid black;
        border-collapse: collapse;
       
      }
    th,td{
      padding:20px;
    }
   tr:nth-child(even){ 
  background-color:#eee;
  }
  tr:nth-child(odd){
  background-color:#fff;
  }
      th{
        background-color: rgb(209, 186, 214);
     }
     
    .perfect{
      margin:50px 60px;
      float:left;
    }

        </style>
</head>
<body>
    <nav>
        <img class="xy" src="http://localhost/House_rental/Images/0.svg">
        <button type="submit"><img class="A" src="http://localhost/House_rental/Images/1.png" position:relative top:20px height=20px>&nbsp; &nbsp;<a class="B" href="http://localhost/House_rental/Sign_up.php">Sign Up </a></button>
        <button type="submit"><img class="A" src="http://localhost/House_rental/Images/2.jfif" position:relative top:20px height=20px>&nbsp; &nbsp;<a class="B" href="http://localhost/House_rental/Login.php">Login</a></button>   
    </nav>
    <h1>World's Largest NoBrokerage Property Site</h1>


<div class="cc">

<form method="post" action="Search_Start.php">
        
        
              
<div class="gg"><center>FOR BUY/RENT SEARCH HERE</center></div>
  <br>
  <div class="cen">
    <input list="search_stat" placeholder="state" name="search_state" required>
    <datalist id="search_stat">
    <?php
     
     $link = mysqli_connect('localhost', 'root', '', 'house_rent');  

/*Check link to the mysql server*/ 
if(!$link)
{ 
die('Failed to connect to server: ');
 } 

 /*Create query*/ 
$qry = "SELECT DISTINCT STATE FROM sellers "; 

/*Execute query*/ 
$result = mysqli_query($link, $qry);
while ($row = mysqli_fetch_assoc($result))
{
     echo '<option value='.$row['STATE'].'>'.$row['STATE'].'</option>';
}
       
    ?>
    </datalist>


    <input list="search_city" placeholder="City" name="search_city">

    <datalist id="search_city">
<?php
    $link = mysqli_connect('localhost', 'root', '', 'house_rent');  

/*Check link to the mysql server*/ 
if(!$link)
{ 
die('Failed to connect to server: ');
 } 

 /*Create query*/ 
$qry = "SELECT DISTINCT CITY FROM sellers "; 

/*Execute query*/ 
$result = mysqli_query($link, $qry);
while ($row = mysqli_fetch_assoc($result))
{
     echo '<option value='.$row['CITY'].'>'.$row['CITY'].'</option>';
}
?>
    </datalist>
    <input list="select_room" placeholder="Room type " name="select_room">
    <datalist id="select_room">
        <option value="1BHK"></option>
        <option value="2BHK"></option>
        <option value="3BHK"></option>
        <option value="4BHK"></option>
    </datalist>
    <br><br>
</div>

<div class="center">

    <input list="room_statu" placeholder="Status" name="room_status">
    <datalist id="room_statu">
        <option value="Rent"></option>
        <option value="buy"></option>
    </datalist>


    <input list="a" placeholder="AC/NON AC" name="ac">
    <datalist id="a">
        <option value="AC"></option>
        <option value="NON AC"></option>
   </datalist>
</div>

<br><br>
    <div class="cent">
    <input type="submit" name="filter" value="search">
    </div>
    <br>
</form>


</div>

        

</body>
</html>
&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;






































<!DOCTYPE html>
<html>
<head>
<style>
 .firsttable{
 width:40%;
 }
 .secondtable{
 background-color:orange;
 text-align:center;
 padding:10px;
 border:1px solid black;
 }
 table,td,tr{       
	    margin-left:auto;
		margin-right:auto;
	   }
 #c1{
   color:blue;
   text-align:center;
   }
   .about-section {
  padding:50px;
  text-align: center;
  background-color:  #0072B5;
  color: white;
  }
  div.ex1 {
  width: 100%;
  background-color: yellow;
  text-align:center;
}

div.ex2 {
  width: 400px;
  padding: 25px;
  box-sizing: border-box;
  background-color: lightblue;
  
}
.v
{
    position:relative;
    left:200px;
    float:left;
}
.U
{
    position:absolute;
    left:700px;
} 
.X
{
    position:absolute;
    left:700px;
    bottom:-1400px;
}
.Z
{
    position:absolute;
    left:700px;
    font-size:20px;
    bottom:-1440px;
} 
.Y
{
    position:absolute;
    left:700px;
    bottom:-1500px;
    size:10px;
} 
img.k
{
    position:absolute;
    left:910px;
    bottom:-1520px;
    width:160px;
    height:80px;
}
.O
{
    position:relative;
    left:-100px;
    top:440px;
    text-decoration:none;
    color:black;
    font-size:23px;
}
hr
{
    position:relative;
    left:-100px;
    top:460px;
}
a
{
    text-decoration:none;
    color:black;
    padding-right:40px;
}
.l
{
    position:relative;
    left:220px;
    top:470px;
}
.m
{
    position:relative;
    left:250px;
    top:485px;
    height:80px;
    width:160px;
}
img.n
{
    position:relative;
    left:-80px;
    top:525px;
    height:40px;
    width:32px;
}
img.s
{
    position:relative;
    left:-50px;
    top:525px;
    height:40px;
    width:32px;
}

img.q
{
    position:relative;
    left:-20px;
    top:525px;
    height:40px;
    width:32px;
}
img.r
{
    position:relative;
    left:10px;
    top:525px;
    height:40px;
    width:32px;
}
p.p
{
    position:absolute;
    left:600px;
    top:2725px;
}
</head>
</style>


<body>

<div class="about-section">
<h1><strong>ABOUT THIS PAGE</strong></h1>
<p>This page is created for the needy who suffers for buying a house or for selling a house or some students who need to stay in a hostel they need to travel the hole city or sme places.but with this website they will easily get the information and they can also book a hosel,and easily get a rental house and they can easily buy a house or sell a house.</p>
</div>


<table class="firsttable">
 <tr>
   <td style="padding-right: 80px;"><img src="https://image.shutterstock.com/image-vector/family-moving-countryside-area-realtor-260nw-1559004740.jpg" alt="APK file" </td>
   <td style="padding-right: 80px;"><img src="https://image.shutterstock.com/image-photo/classic-house-model-on-sale-260nw-1590287107.jpg" alt="APK file" </td>
   <td style="padding-right: 80px;"><img src="https://img.staticmb.com/mbimages/project/Photo_h310_w462/2021/02/10/Project-Photo-7-GP-Elegant-Castle-Chennai-5230041_600_800_310_462.jpg" alt="APK file" </td>
   </tr>
   </table>
   
 <h3 id="c1">VIDEO REVIEW FOR NEW USERS</h3>
  <center> <iframe width="560" height="315" src="https://www.youtube.com/embed/u4Ad6OfXuz4" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></center>
  <h3 id="c1"  >OUR SERVICES TO USERS </h3>
  <table class="secondtable">
  <tr>
  <th>BUY</th>
  <th>RENT</th>
  </tr>
  <tr>
  <td>Buy a home</td>
  <td>Rent a home</td>
  </tr>
  <tr>
  <td>Buy an appartment</td>
  <td>Rent an appartment</td>
  </tr>
  <tr>
  <td>Hostels for students</td>
  <td>Commercial appartments</td>
  </tr>
  </table>
  <br>
  <br>
  <br>
<br>
<img class="v" src="https://assets.nobroker.in/nb-new/public/Home/homeAppPromotion.png">
<h1 class="U">Find A New Home On The Go</h1>
<br>
<br>
<h2 class="X">Download our app</h2>
<p class="Z">Where convenience is at your fingertip</p>
<img class="Y" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKUAAAAwCAMAAABHXkoYAAAC+lBMVEUAAAAAAAAAAAAFBQUJCQkaGhoqKio7OztAQEBmZmYSEhIMDAxSUlJVVVUCAgIAAAACAgIAAAAAAQACAAEAAwECAgIAAAIEBAQAAAUeHx8VFRUPDw8GBgb///8ICAgYGRghIiIMDAwAAAkREhIKCgocHBwmJyVAQUGYmZmVlZV1d3br6+vd3t43sLb39/fW1tbDxMShoqJYWVk8PT04ODguLy+rq6uoqKiPj4+JiYlfYGBEREQrLCsFAAD6+vrj5OTa2tq3t7eSkpJucG/8/Pzz8/Po6Ojg4eHQ0dDLzcxCvLuys7OLjIxjZGNLS0vT1NOur69xcnJISUgBBwXv8PBFw7+kpaWenp5naGhcXFxRUVExMjIMAQHl5uZHxsF7fXxOTk7t7u1PzslW3ce6u7o9tbc1r6mCg4N/gIA1NTVR2cvGyMdO18G+wL9Oy7mbnJv6rn/8o30gSUQBARA1qbMumKxKpKZ5enls79Rj2sVKycN0wcAyobE5naqp256GhoapSnVsbWwmTEkZP0QUM0AUAgdU5shL3sW8vb1Cua+h3q5Sr6QvpaR0s6E4gZu02JdpamrMNGbXPktm4M5W1c1nwrtEwrI+s6/I5614yaqnqam116dWoKWHjZ77v5HnsoPeoICpQnnwoXPLQmipeGBTVVQqVUo5ChsRIRKP18yIvMp6xMl8zcFTwL7N7ryr4q+M061Arqt+wqhMiqWe3aRtbpR+fJL0qY/1tomYRoPCTIHIP3qLQG/lb2B1KkxMMCNGISIGEB4bCwSR9ep69N1T9MtN8ctVzcGg375V175Fx7Q7hKkykaT8y6DJ5Z7/uIdsWoewooKDR392oHxMgXy6N3PHqHLRNXC3hm49cWDWPV8/UF1cL13XRVmkPVjDQ1VoeE0+YktNJUQVNCxZPCgfCiMVBRhT8snn9bbvxZ98cZjW0JRsjZLV05HNyomxXIDGUHh7lHO2Ymt/NVymX1WZa00aMT1jSzg0FTNtGzAvQStSMSIsHBQAEQxDTIhzAAAAEXRSTlOeAKCcl2taRDgKioMcE87Bui6/rG8AAAsFSURBVFjDzZkFWFtXFMeZu5yb3DziyeIJiycQARKc4TKcAYMVKFDZRukq6zrtunZr525d5+7u7u7u7i7ft3Pfe2mAhmzdMvkTnuW+d3/3f86593uQtRlq2y03z/q/auvtEBApd9oSCIFUIkD+e+26DaPcaWee5n9LSWBrpNwC2NFf9PLfGIcUdszahrHAX6KExIdgU7HxP+E/3SprSzqFkfUokUgEwtScCRYxT6QiJRApP96MU0rJFllZkJRMRrFXKpFJNiCT1L0m7E9kSzIc0slDy5C5OAMlO5Bl33Xwwb8BR5EyTczFUtMIDZKVJ7foeWvFa0m+v82ZNdnLbNn315z+7Dvkj3MTSMRaZRsGwWpjxAQoe3kULDrhlin2EpJJyqbsQ48++vTVz74jBUGSlP2wqLY7qnrGekCQtrIDKAFzRK93t00tRRE2c5REipTXIOZFV790oRSaMHQbSldMQBGSgKnyVCVwRkI66qsixurmSrueQKPdMNRXGVJi0BvrV7SpOO/y4pGQHiCDEScC5SOPHL3g0otWIydTIm4C3AZBb2GEmgMm2ugqLh6z9DhO9WoAelza4r6qGsTylc8d6m7grM48a3MYCGQy4iQbDl06Pj7+KGI+uPqtC4EwO2UoCcimehku7DTYcoIGa2Wvt7vYnNPISnsiptDltAGV0qJKI1grDHkVRmVddWYjLsveLfvQVePjS5Y+umDxpQ+ufOatJvZ0iSxbSM9k2JugscwLnaE6U667Z9DqD+T0sm/tLoM5pwbHpqqqAlgek+eNgXIkBFJ+YJmhRMj9djt01arxJUvGly444cqVV6x85ucmkFLC5nhZshsgFAwrKvyGGpeuOhbVG+hwWZueEqxxha58SEkJGSzrVMQH9J5KUNSFgGSQEhjlIVetWrX//kuWLF1wypXXHnj5aV9FiWig6CYBQcMjOQM5HqXc7W6Za1YOlA/qgdor5KpgX5ECiCleMVARkc51Y/mziGfWy+xDTpo1a38UYq5GzNMuP+1NMwEsI5EuMYVzUm14otYAYGpr8OlBV7yeAxK1cGAqDuuxlSK83Ayk0wecJQCZpzxy1qzdmfZfevrVK6848LSTLz/mTSwjjoBsEibB6mcSd8Ixf11ok2pdAJJ6HUvEaBPyUqRE7bPgqFNWHnjgMcec/OHz797dlU9kZPJaIkVQJsJ+xa2wEZolZi4xXfhNOhDWYpO8PEnAPOmqo065Fikf/+yss8/7pUsCiXEjotA57lFJVAEUpomIvzN4yWvTvJQdcuKsk/YRtQdiXnHy458/f+78G84+744uwaBEf0CbpECplBIeNSmSGiW1mfxVlZgnf3a+hH3nHHnkHkkddfXJn5x17vz5829AzjsPo5NWdXZMSeJMyIGUYrVk1slJahDxeZtEKdt3zokn7rlBlx21+qmz5s1DynPPnXfmWXeANBsABCAwdIQb7A3tnRrgQz+jl1JQrV9RZ6dkJi85rT7hJb9JTwnoJVI+PGcvpkV77bnHZYuLvr1t/hPzUE+cefZ3vyKlTCY8Udp+aqt9TXGRq9vTqxGCCantJKCRD6g7YIawAihaajY54g/PmbNo0SKe84ETzvj62GNvm3fjjWc+diYmJlIImBQ01YV2tsjQQFDdYqREcFiorEmeike0paARhCgkE0RoiHC6PiugWPWxrYArTUv5wJzR0b2ZFu09+7IzvnjjWMS88bGPXsTJqIuTitVKib0kDJQJAtVR4ITLINa72CdK8FjKnVpSC4k2GxW+vLwaEhJXuumaTnnA6Ojs2ccfj5jHn/DpQWtffvm119548akflABdXfm4oAvyl3oQkj2ValTA6KlCbjLyqQBEIZfrxTcgvVKjUSi5XPSSb6PA+Bs1HDbE+4z8LSAvzMMtZzBpVbjVAMVxckouDeXBB4z29yPm7NmzTzjjoLVr165bt+71O+/Oh3wElOTnS5CUApenbt9gBTBHFctDoaqqWgauWBOqrh/wckDB2FvcmmuzdQiUyuJqj7vHoLHUDAPQhpAvXtYXtwDhKX257li5R66sClEVEGgIyoGkopQJlA/19x9xxGj/cYvPOOiFF9au+/L1ny7oAsFEiSgwVJRGEELEREh5vFUHAbe6mANtfTAK5gF1j4Zq59r8axwlawxIWYtFYtMp7SUepTZiRutsBZXW9uK6Qr8Q8TVjPd5lzfUaa3MnAOjKcjU0jZci5QGLrz/nuVtuufmg2y84DJcdSRKRSAiY+hyWxFCRkpDcmB6po2XNEWh1yfFQm+NcTz05WoAaJ1ZXboEFQjETQEffmByYaF7JBO6GHUGOeYkGogadumEnItP2Ei/QdHnZ33/46BHHLb7+1ucExvwuSmWyyZxoncPZCDSZ8J3OIHOVVqtDutI4ZZcG1VZ5zG3EXChE7NwCv8FVpe+15a2XC6VGbY4AHuBI5KayIvYwo1LZ4/SrgnVa4OIjirTVc9zhqOMuuf7WcwTGfCrggSQpUNSpGyhPqTSbTSZjWB3kz7zqFm9BnANUh3ogUBeTAwcVLi3kllh0jrHacK1WGBajjGl5+xwBbXcRmupxV1S4HH5od3oxViGAdNWz8L777194ycc3nXPON3ceRohKI8OEFb1MCFRW9YiOMLCItb6iItJRMqJgfdeqW2ubBRv8JQPKVvUyFci7qynJLfBpXWV+DCsnJgotcpkSlIVFEMmpaKv1FTmHQRdrgbYyP1CSmhIx4fyFH9y38JLrnr7p1rcP46c/mUg51czaUnUDgAprRdfYXGDRlaIJhECj2m4s74uwHvzqZRCIFy7zBvP0wAULLNSjHkI4lhkCpaMT23HBmMnUnQct3VEAsKs7KQx1m+MrWFrMQAmMcuG9i6+76em335cAQcmIjIlKpghURWpHmIKKApjLm32Qp/ZoAC3OMcMydVDPSrgsAKDoKHLWGYEwSugoddZogBqMYvWoBymAr7QFazwEcRdGQFepDnDEl2Njr3gwaamfSimD8++95+Lrnnz1vWyQESaeUCaZKiBUay1w2qIaynGW0lILKD1Oj69zwl0LoLSWBi3RHncvH9xooaNGBYox9Vy/anlzSXxwKKwEJq7IGWsN40zkw2nHBg0lnvaJeB0OmKpa1TkmAkBm8lIK599z8ZOv/rjhzRb5KK9pnBT07e6S8njexLLWersWwIjlO9RuRn7Q1FptQ21mRuJbPlTpLA1plI3esI+qLLax+gYzFby0unrrCx1VmCmG+jZQTsS6XXZ/axRU0F5qBZLGSwqvXPzKexhshsinooympAQJK+9wsb3GojNwgjkKA79iErYSKtgDFB53TafWW1bSlhg0NRrZAQro3JhepZNr2LlSBYAZjoPVc3h/DaZHuohD9l137YfBzqaEICJOQ5KUlCgC6UWIpr5sGFARR72KJIomEUikZFN+UsnvjCNulhQzUyIfqgklRcr89JQUP5RO6yNpAqakW4PfE25FlUo0eVLnM1BqfL256g4Ams5LJirFHzbyyVAzGEbpjH+NB1Ndcy3Fk2ill12AyZRsJqpUwnRxYKgqddWI09WU6tkcklcQJwMSX2295d0tDd6G1rBo8hSnQRfFPJgmClwgYk7xPEaZaSVewgP23FxbWwB4TfMStXEgCOH4htOFlFvhTZkVIxRY9AoDW0U28pLt6Qw5xNGNH7dD1na74G2Zp2SfFEUlCDZBrPm2WZttI7xtZJJyGkuKvPyz3RH22Z79t3RroP+Il5ARLxFyO0a52Y5bbZH1v9UO2yLh7wpF4VDrUXxCAAAAAElFTkSuQmCC">
<br>
<img class="k" src="https://assets.nobroker.in/nb-new/public/Common/IOS_download.svg">
<div class="O">
<a href="https://www.nobroker.in/about/about-us">About Us</a>
<a href="https://www.nobroker.in/careers">Careers</a>
<a href="https://www.nobroker.in/terms-and-condition">Terms&Conditions</a>
<a href="https://www.nobroker.in/privacy">Privacy Policy</a>
<a href="https://www.nobroker.in/testimonials">Testimonials</a>
<a href="https://www.nobroker.in/sitemap">Sitemap</a>
<a href="https://www.nobroker.in/about/faq">FAQs</a>
</div>
<hr>
<br>
<br>
<img class="l" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKUAAAAwCAMAAABHXkoYAAAC+lBMVEUAAAAAAAAAAAAFBQUJCQkaGhoqKio7OztAQEBmZmYSEhIMDAxSUlJVVVUCAgIAAAACAgIAAAAAAQACAAEAAwECAgIAAAIEBAQAAAUeHx8VFRUPDw8GBgb///8ICAgYGRghIiIMDAwAAAkREhIKCgocHBwmJyVAQUGYmZmVlZV1d3br6+vd3t43sLb39/fW1tbDxMShoqJYWVk8PT04ODguLy+rq6uoqKiPj4+JiYlfYGBEREQrLCsFAAD6+vrj5OTa2tq3t7eSkpJucG/8/Pzz8/Po6Ojg4eHQ0dDLzcxCvLuys7OLjIxjZGNLS0vT1NOur69xcnJISUgBBwXv8PBFw7+kpaWenp5naGhcXFxRUVExMjIMAQHl5uZHxsF7fXxOTk7t7u1PzslW3ce6u7o9tbc1r6mCg4N/gIA1NTVR2cvGyMdO18G+wL9Oy7mbnJv6rn/8o30gSUQBARA1qbMumKxKpKZ5enls79Rj2sVKycN0wcAyobE5naqp256GhoapSnVsbWwmTEkZP0QUM0AUAgdU5shL3sW8vb1Cua+h3q5Sr6QvpaR0s6E4gZu02JdpamrMNGbXPktm4M5W1c1nwrtEwrI+s6/I5614yaqnqam116dWoKWHjZ77v5HnsoPeoICpQnnwoXPLQmipeGBTVVQqVUo5ChsRIRKP18yIvMp6xMl8zcFTwL7N7ryr4q+M061Arqt+wqhMiqWe3aRtbpR+fJL0qY/1tomYRoPCTIHIP3qLQG/lb2B1KkxMMCNGISIGEB4bCwSR9ep69N1T9MtN8ctVzcGg375V175Fx7Q7hKkykaT8y6DJ5Z7/uIdsWoewooKDR392oHxMgXy6N3PHqHLRNXC3hm49cWDWPV8/UF1cL13XRVmkPVjDQ1VoeE0+YktNJUQVNCxZPCgfCiMVBRhT8snn9bbvxZ98cZjW0JRsjZLV05HNyomxXIDGUHh7lHO2Ymt/NVymX1WZa00aMT1jSzg0FTNtGzAvQStSMSIsHBQAEQxDTIhzAAAAEXRSTlOeAKCcl2taRDgKioMcE87Bui6/rG8AAAsFSURBVFjDzZkFWFtXFMeZu5yb3DziyeIJiycQARKc4TKcAYMVKFDZRukq6zrtunZr525d5+7u7u7u7i7ft3Pfe2mAhmzdMvkTnuW+d3/3f86593uQtRlq2y03z/q/auvtEBApd9oSCIFUIkD+e+26DaPcaWee5n9LSWBrpNwC2NFf9PLfGIcUdszahrHAX6KExIdgU7HxP+E/3SprSzqFkfUokUgEwtScCRYxT6QiJRApP96MU0rJFllZkJRMRrFXKpFJNiCT1L0m7E9kSzIc0slDy5C5OAMlO5Bl33Xwwb8BR5EyTczFUtMIDZKVJ7foeWvFa0m+v82ZNdnLbNn315z+7Dvkj3MTSMRaZRsGwWpjxAQoe3kULDrhlin2EpJJyqbsQ48++vTVz74jBUGSlP2wqLY7qnrGekCQtrIDKAFzRK93t00tRRE2c5REipTXIOZFV790oRSaMHQbSldMQBGSgKnyVCVwRkI66qsixurmSrueQKPdMNRXGVJi0BvrV7SpOO/y4pGQHiCDEScC5SOPHL3g0otWIydTIm4C3AZBb2GEmgMm2ugqLh6z9DhO9WoAelza4r6qGsTylc8d6m7grM48a3MYCGQy4iQbDl06Pj7+KGI+uPqtC4EwO2UoCcimehku7DTYcoIGa2Wvt7vYnNPISnsiptDltAGV0qJKI1grDHkVRmVddWYjLsveLfvQVePjS5Y+umDxpQ+ufOatJvZ0iSxbSM9k2JugscwLnaE6U667Z9DqD+T0sm/tLoM5pwbHpqqqAlgek+eNgXIkBFJ+YJmhRMj9djt01arxJUvGly444cqVV6x85ucmkFLC5nhZshsgFAwrKvyGGpeuOhbVG+hwWZueEqxxha58SEkJGSzrVMQH9J5KUNSFgGSQEhjlIVetWrX//kuWLF1wypXXHnj5aV9FiWig6CYBQcMjOQM5HqXc7W6Za1YOlA/qgdor5KpgX5ECiCleMVARkc51Y/mziGfWy+xDTpo1a38UYq5GzNMuP+1NMwEsI5EuMYVzUm14otYAYGpr8OlBV7yeAxK1cGAqDuuxlSK83Ayk0wecJQCZpzxy1qzdmfZfevrVK6848LSTLz/mTSwjjoBsEibB6mcSd8Ixf11ok2pdAJJ6HUvEaBPyUqRE7bPgqFNWHnjgMcec/OHz797dlU9kZPJaIkVQJsJ+xa2wEZolZi4xXfhNOhDWYpO8PEnAPOmqo065Fikf/+yss8/7pUsCiXEjotA57lFJVAEUpomIvzN4yWvTvJQdcuKsk/YRtQdiXnHy458/f+78G84+744uwaBEf0CbpECplBIeNSmSGiW1mfxVlZgnf3a+hH3nHHnkHkkddfXJn5x17vz5829AzjsPo5NWdXZMSeJMyIGUYrVk1slJahDxeZtEKdt3zokn7rlBlx21+qmz5s1DynPPnXfmWXeANBsABCAwdIQb7A3tnRrgQz+jl1JQrV9RZ6dkJi85rT7hJb9JTwnoJVI+PGcvpkV77bnHZYuLvr1t/hPzUE+cefZ3vyKlTCY8Udp+aqt9TXGRq9vTqxGCCantJKCRD6g7YIawAihaajY54g/PmbNo0SKe84ETzvj62GNvm3fjjWc+diYmJlIImBQ01YV2tsjQQFDdYqREcFiorEmeike0paARhCgkE0RoiHC6PiugWPWxrYArTUv5wJzR0b2ZFu09+7IzvnjjWMS88bGPXsTJqIuTitVKib0kDJQJAtVR4ITLINa72CdK8FjKnVpSC4k2GxW+vLwaEhJXuumaTnnA6Ojs2ccfj5jHn/DpQWtffvm119548akflABdXfm4oAvyl3oQkj2ValTA6KlCbjLyqQBEIZfrxTcgvVKjUSi5XPSSb6PA+Bs1HDbE+4z8LSAvzMMtZzBpVbjVAMVxckouDeXBB4z29yPm7NmzTzjjoLVr165bt+71O+/Oh3wElOTnS5CUApenbt9gBTBHFctDoaqqWgauWBOqrh/wckDB2FvcmmuzdQiUyuJqj7vHoLHUDAPQhpAvXtYXtwDhKX257li5R66sClEVEGgIyoGkopQJlA/19x9xxGj/cYvPOOiFF9au+/L1ny7oAsFEiSgwVJRGEELEREh5vFUHAbe6mANtfTAK5gF1j4Zq59r8axwlawxIWYtFYtMp7SUepTZiRutsBZXW9uK6Qr8Q8TVjPd5lzfUaa3MnAOjKcjU0jZci5QGLrz/nuVtuufmg2y84DJcdSRKRSAiY+hyWxFCRkpDcmB6po2XNEWh1yfFQm+NcTz05WoAaJ1ZXboEFQjETQEffmByYaF7JBO6GHUGOeYkGogadumEnItP2Ei/QdHnZ33/46BHHLb7+1ucExvwuSmWyyZxoncPZCDSZ8J3OIHOVVqtDutI4ZZcG1VZ5zG3EXChE7NwCv8FVpe+15a2XC6VGbY4AHuBI5KayIvYwo1LZ4/SrgnVa4OIjirTVc9zhqOMuuf7WcwTGfCrggSQpUNSpGyhPqTSbTSZjWB3kz7zqFm9BnANUh3ogUBeTAwcVLi3kllh0jrHacK1WGBajjGl5+xwBbXcRmupxV1S4HH5od3oxViGAdNWz8L777194ycc3nXPON3ceRohKI8OEFb1MCFRW9YiOMLCItb6iItJRMqJgfdeqW2ubBRv8JQPKVvUyFci7qynJLfBpXWV+DCsnJgotcpkSlIVFEMmpaKv1FTmHQRdrgbYyP1CSmhIx4fyFH9y38JLrnr7p1rcP46c/mUg51czaUnUDgAprRdfYXGDRlaIJhECj2m4s74uwHvzqZRCIFy7zBvP0wAULLNSjHkI4lhkCpaMT23HBmMnUnQct3VEAsKs7KQx1m+MrWFrMQAmMcuG9i6+76em335cAQcmIjIlKpghURWpHmIKKApjLm32Qp/ZoAC3OMcMydVDPSrgsAKDoKHLWGYEwSugoddZogBqMYvWoBymAr7QFazwEcRdGQFepDnDEl2Njr3gwaamfSimD8++95+Lrnnz1vWyQESaeUCaZKiBUay1w2qIaynGW0lILKD1Oj69zwl0LoLSWBi3RHncvH9xooaNGBYox9Vy/anlzSXxwKKwEJq7IGWsN40zkw2nHBg0lnvaJeB0OmKpa1TkmAkBm8lIK599z8ZOv/rjhzRb5KK9pnBT07e6S8njexLLWersWwIjlO9RuRn7Q1FptQ21mRuJbPlTpLA1plI3esI+qLLax+gYzFby0unrrCx1VmCmG+jZQTsS6XXZ/axRU0F5qBZLGSwqvXPzKexhshsinooympAQJK+9wsb3GojNwgjkKA79iErYSKtgDFB53TafWW1bSlhg0NRrZAQro3JhepZNr2LlSBYAZjoPVc3h/DaZHuohD9l137YfBzqaEICJOQ5KUlCgC6UWIpr5sGFARR72KJIomEUikZFN+UsnvjCNulhQzUyIfqgklRcr89JQUP5RO6yNpAqakW4PfE25FlUo0eVLnM1BqfL256g4Ams5LJirFHzbyyVAzGEbpjH+NB1Ndcy3Fk2ill12AyZRsJqpUwnRxYKgqddWI09WU6tkcklcQJwMSX2295d0tDd6G1rBo8hSnQRfFPJgmClwgYk7xPEaZaSVewgP23FxbWwB4TfMStXEgCOH4htOFlFvhTZkVIxRY9AoDW0U28pLt6Qw5xNGNH7dD1na74G2Zp2SfFEUlCDZBrPm2WZttI7xtZJJyGkuKvPyz3RH22Z79t3RroP+Il5ARLxFyO0a52Y5bbZH1v9UO2yLh7wpF4VDrUXxCAAAAAElFTkSuQmCC">
<img class="m" src="https://assets.nobroker.in/nb-new/public/Common/IOS_download.svg">
<img class="n" src="https://assets.nobroker.in/nb-new/public/Common/social/facebook.svg">
<img class="s" src="https://assets.nobroker.in/nb-new/public/Common/social/twitter.svg">
<img class="q" src="https://assets.nobroker.in/nb-new/public/Common/social/linkedin.svg">
<img class="r" src="https://assets.nobroker.in/nb-new/public/Common/social/youtube.svg">
<br>
<p class="p">© 2013-21 NoBroker Technologies Solution Pvt. Ltd.</p>
<br>
<br>
</body>
</html>
