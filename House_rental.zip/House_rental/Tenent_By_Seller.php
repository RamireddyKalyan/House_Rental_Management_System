<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Seller view</title>
<style>
h1
        {
            text-align:center;
        }
        table.H
        {
           position: relative;
           left:500px;
           border-collapse:collapse;
        }
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color:rgb(119, 240, 220);
  border:1px solid black;
  border-collapse: collapse;
}

li {
  border:1px solid black;
   width:150px;
  text-align:center;
  font-weight: bold;
  float: left;
  border-collapse: collapse;
}

li a, .dropbtn {
  display: inline-block;
  color:rgb(17, 14, 14);
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}
li a:hover, .dropdown:hover .dropbtn {
  background-color: rgb(97, 185, 219);
  width:117px;
}

li.dropdown {
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #A0DAA9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {
  width:83%;
  background-color: #f1b4f1;}

.dropdown:hover .dropdown-content {
  display: block;
}

.start{
            border:1px solid black;
            background-color: #B55A30;

            display:block;
            text-align: center;
        }

        table,th{
        border:2px solid black;
        border-collapse: collapse;
      }
    th,td{
      border:1px solid black;
      padding:20px;
    }
   tr:nth-child(even){ 
  background-color:#eee;
  }
  tr:nth-child(odd){
  background-color:#fff;
  }
      th{
        background-color: rgb(209, 186, 214);
     }
     
</style>
</head>
<body>
  <div class="start"> <h2> RENTAL HOUSE MANAGEMENT SYSTEM </h2></div>
<ul>
  
    <li class="dropdown">
        <a href="#" class="dropbtn"><img src="http://localhost/House_rental/Images/House_image.png" style="width:25px; height:25px;">
House</a>
        <div class="dropdown-content">
          <a href="house_registrationform.php">Register House</a>
          <a href="Update_Delete_House.php">update/delete</a>
          <a href="Show_House_Seller.php">Show My Houses</a>
        </div></li>

  <li><a href="Contracts_By_Seller.php"><img src="http://localhost/House_rental/Images/contract.png" style="width:25px; height:25px;" >
Contracts</a></li>
  <li><a href="Tenent_By_Seller.php"><img src="http://localhost/House_rental/Images/group.png" style="width:25px; height:25px;" >
Tenents</a></li>
  <li class="dropdown">
        <a href="#" class="dropbtn"><img src="http://localhost/House_rental/Images/complaint.png" style="width:25px; height:25px;" >
Complaint</a>
        <div class="dropdown-content">
          <a href="Post_SComplaint.php">Post Complaint</a>
          <a href="View_SComplaint.php">View Complaints</a>
        </div></li>
  <li><a href="Payment_View_Seller.php"><img src="http://localhost/House_rental/Images/payment.png" style="width:25px; height:25px;" >

Payments</a></li>
  <li><a href="Requests_By_Seller.php"><img src="http://localhost/House_rental/Images/request.png" style="width:25px; height:25px;" >

Requests</a></li>
  <li class="dropdown" style="float:right;">
  <?php
  session_start();
  $Name=$_SESSION['Uname'];  
  echo '<a href="#" class="dropbtn"><img src="http://localhost/House_rental/Images/user.png" style="width:25px; height:25px;" >
 '.$Name.'</a>';

?>
  <div class="dropdown-content">
      <a href="Start.php">Sign out</a>
    </div>
  </li>
</ul>
<?php 

   
 /*Connect to mysql server*/ 
$link = mysqli_connect('localhost', 'root', '', 'house_rent');  

/*Check link to the mysql server*/ 
if(!$link)
{ 
die('Failed to connect to server: ');
 } 

 /*Create query*/ 
$qry = "SELECT  DISTINCT tenants.HOUSE_NO,tenants.USER_NAME,tenants.FULL_NAME,tenants.PHONE_NUMBER,tenants.EMAIL,tenants.CITY,tenants.STATE  FROM tenants,contracts WHERE contracts.USER_NAME_S='$Name' AND contracts.USER_NAME_T=tenants.USER_NAME AND tenants.HOUSE_NO=contracts.HOUSE_NO "; 

/*Execute query*/ 
$result = mysqli_query($link, $qry);

if(mysqli_num_rows($result)>0){

echo '<h1>The Tenants Details are - </h1>';

 /*Draw the table for Players*/ 
echo '<center><table > 
<th>HOUSE NO</th>
<th> USER NAME </th> 
<th>FULL NAME</th>
 <th>PHONE NUMBER</th>
 <th>CITY</th>
 <th>STATE</th>
 <th>EMAIL</th>
 
';

/*Show the rows in the fetched result set one by one*/ 
while ($row = mysqli_fetch_assoc($result))
{ 
echo '<tr> 
<td>'.$row['HOUSE_NO'].'</td>
<td>'.$row['USER_NAME'].'</td>
<td>'.$row['FULL_NAME'].'</td>
<td>'.$row['PHONE_NUMBER'].'</td> 
<td>'.$row['CITY'].'</td>
<td>'.$row['STATE'].'</td>
<td>'.$row['EMAIL'].'</td> 
</tr>';
}
echo '</table></center>';
}
else{
  echo '<center><h1> Currently  there are No Tenents </h1></center>';
}
?>




</body>
</html>


