<!DOCTYPE html>
<html lang="en">
<head>
    <style>
        h1
        {
            color:black;
            text-align:center;
            padding:100px;
        }
        a
        {
            text-align:center;
            text-decoration:none;
            font-size:25px;
            padding-left:650px;
        }
        </style>
</head>
<body>
    <h1>Please Enter Required Details....</h1>
    <a href="http://localhost/House_rental/tenent_registration(rent).php">Register Here</a>
</body>