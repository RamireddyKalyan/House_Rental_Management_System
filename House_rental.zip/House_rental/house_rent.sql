-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 13, 2021 at 10:34 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `house_rent`
--

-- --------------------------------------------------------

--
-- Table structure for table `complaint`
--

CREATE TABLE `complaint` (
  `USER_S` varchar(20) NOT NULL,
  `USER_T` varchar(20) NOT NULL,
  `COMPLAINT` varchar(1000) NOT NULL,
  `WHO` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `contracts`
--

CREATE TABLE `contracts` (
  `USER_NAME_S` varchar(30) NOT NULL,
  `USER_NAME_T` varchar(30) NOT NULL,
  `HOUSE_NO` int(20) NOT NULL,
  `RENT_OR_SALE` varchar(4) NOT NULL,
  `NO_OF_DAYS` int(10) NOT NULL,
  `AMOUNT_PAID` int(10) NOT NULL,
  `PHONE_PAY` int(10) DEFAULT NULL,
  `SEND` varchar(10) DEFAULT 'NO',
  `RECEIVE` varchar(10) DEFAULT 'NO'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `sellers`
--

CREATE TABLE `sellers` (
  `FULL_NAME` varchar(30) NOT NULL,
  `EMAIL` varchar(30) DEFAULT NULL,
  `PHONE_NUMBER` int(10) NOT NULL,
  `COUNTRY` varchar(20) NOT NULL,
  `STATE` varchar(20) NOT NULL,
  `CITY` varchar(20) NOT NULL,
  `ADDRESS` varchar(20) NOT NULL,
  `DESCRIPTION` varchar(100) DEFAULT NULL,
  `FACILITIES` varchar(100) DEFAULT NULL,
  `PINCODE` int(10) NOT NULL,
  `LANDMARK` varchar(30) NOT NULL,
  `AC_OR_NOT` varchar(10) NOT NULL,
  `ROOM_TYPE` varchar(10) NOT NULL,
  `STATUS` varchar(10) NOT NULL,
  `RENT_OR_SALE` varchar(10) NOT NULL,
  `USER_NAME` varchar(20) NOT NULL,
  `HOUSE_NO` varchar(60) NOT NULL,
  `IMAGE` blob NOT NULL,
  `SELLINGPRICE` int(10) DEFAULT 0,
  `RENTPRICE` int(10) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sellers`
--

INSERT INTO `sellers` (`FULL_NAME`, `EMAIL`, `PHONE_NUMBER`, `COUNTRY`, `STATE`, `CITY`, `ADDRESS`, `DESCRIPTION`, `FACILITIES`, `PINCODE`, `LANDMARK`, `AC_OR_NOT`, `ROOM_TYPE`, `STATUS`, `RENT_OR_SALE`, `USER_NAME`, `HOUSE_NO`, `IMAGE`, `SELLINGPRICE`, `RENTPRICE`) VALUES
('ramesh reddy', 'ramesh123@gmail.com', 2147483647, 'India', 'telangana', 'hydrabad', 'beside bustand', 'all are good', 'two fans with ac', 516132, 'beside bustand', 'AC', '2BHK', 'Vacant', 'Sale', 'ramesh', '1-12-132', 0x3262686b2e6a7067, 1500000, 0),
('ramesh reddy', 'ramesh123@gmail.com', 2147483647, 'India', 'andhrapradesh', 'kadapa', 'beside beside post o', 'all are good', 'two fans with ac', 516132, 'beside post office', 'AC', '2BHK', 'Vacant', 'Sale', 'ramesh', '13-14-143', 0x3262686b2e6a7067, 2000000, 0),
('ramesh reddy', 'ramesh123@gmail.com', 2147483647, 'India', 'telangana', 'hydrabad', 'beside bustand', 'all are good', 'two fans with ac', 516132, 'beside bustand', 'AC', '3BHK', 'Vacant', 'Sale', 'ramesh', '2-12-132', 0x3262686b2e6a7067, 2000000, 0),
('ramesh reddy', 'ramesh123@gmail.com', 2147483647, 'India', 'andhrapradesh', 'kadapa', 'beside beside post o', 'all are good', 'two fans with ac', 516154, 'beside post office', 'NON AC', '1BHK', 'Vacant', 'Rent', 'ramesh', '4-12-134', 0x3262686b2e6a7067, 0, 1000),
('ramesh reddy', 'ramesh123@gmail.com', 2147483647, 'India', 'Andhra Pradesh', 'chittor', 'near petrolbunk', 'all are good', 'two fans with ac', 516360, 'near petrolbunk', 'NON AC', '3BHK', 'Vacant', 'Rent', 'ramesh', '4-52-142', 0x3262686b2e6a7067, 0, 1500),
('suresh reddy', 'suresh123@gmail.com', 2147483647, 'india', 'maharashtra', 'mumbai', 'near taj hotel', 'all are good', 'ac room', 541341, 'near taj hotel', 'AC', '4BHK', 'Vacant', 'Sale', 'suresh', '1-22-167', 0x3262686b2e6a7067, 5000000, 0),
('suresh reddy', 'suresh123@gmail.com', 2147483647, 'India', 'maharashtra', 'mumbai', 'near taj hotel', 'all are good', 'healthy food ', 541341, 'near taj hotel', 'AC', '2BHK', 'Vacant', 'Rent', 'suresh', '12-19-154', 0x3262686b2e6a7067, 0, 10000),
('suresh reddy', 'suresh123@gmail.com', 2147483647, 'India', 'maharashtra', 'mumbai', 'near taj hotel', '', '', 541341, 'near taj hotel', 'AC', '2BHK', 'Vacant', 'Rent', 'suresh', '2-12-143', 0x3262686b2e6a7067, 0, 10000);

-- --------------------------------------------------------

--
-- Table structure for table `tenants`
--

CREATE TABLE `tenants` (
  `FULL_NAME` varchar(50) NOT NULL,
  `EMAIL` varchar(100) NOT NULL,
  `PHONE_NUMBER` int(10) NOT NULL,
  `USER_NAME` varchar(20) NOT NULL,
  `CITY` varchar(30) NOT NULL,
  `OCCUPATION` varchar(30) NOT NULL DEFAULT '',
  `ADHAR` int(20) NOT NULL,
  `STATE` varchar(20) NOT NULL,
  `PINCODE` int(10) NOT NULL,
  `HOUSE_NO` varchar(20) NOT NULL,
  `RENT_OR_BUY` varchar(5) NOT NULL,
  `NO_OF_DAYS` int(10) NOT NULL DEFAULT 0,
  `SELLER` varchar(40) NOT NULL,
  `STATUS` varchar(10) NOT NULL DEFAULT 'Requested'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `user_account`
--

CREATE TABLE `user_account` (
  `USER_NAME` varchar(30) NOT NULL,
  `PASSWORD` varchar(20) NOT NULL,
  `ROLE` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_account`
--

INSERT INTO `user_account` (`USER_NAME`, `PASSWORD`, `ROLE`) VALUES
('hello', 'hello@123', 'Buyer'),
('ramesh', 'ramesh@123', 'Seller'),
('suresh', 'suresh@123', 'Seller');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contracts`
--
ALTER TABLE `contracts`
  ADD PRIMARY KEY (`HOUSE_NO`);

--
-- Indexes for table `sellers`
--
ALTER TABLE `sellers`
  ADD PRIMARY KEY (`USER_NAME`,`HOUSE_NO`);

--
-- Indexes for table `tenants`
--
ALTER TABLE `tenants`
  ADD PRIMARY KEY (`USER_NAME`,`HOUSE_NO`),
  ADD KEY `tenants_ibfk_1` (`SELLER`);

--
-- Indexes for table `user_account`
--
ALTER TABLE `user_account`
  ADD PRIMARY KEY (`USER_NAME`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tenants`
--
ALTER TABLE `tenants`
  ADD CONSTRAINT `tenants_ibfk_1` FOREIGN KEY (`SELLER`) REFERENCES `user_account` (`USER_NAME`) ON DELETE CASCADE ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
