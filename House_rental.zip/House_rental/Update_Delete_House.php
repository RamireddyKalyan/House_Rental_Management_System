<?php 
session_start(); 
?>  
<!DOCTYPE html>   
<html>   
<head>  
<meta name="viewport" content="width=device-width, initial-scale=1">  
<title> house Registration Form</title>  
<style>   

Body {  
  font-family: Calibri, Helvetica, sans-serif;  
  background-color:skyblue;  
}  
  
  .label{
      font-weight: bold;
      font-size: 20px;
  }
  
   input{ 
        width: 80%;     
        margin: 8px 00px;  
        padding: 10px 00px;   
        display: inline-block;   
        border: 2px solid blue; 
        box-sizing: border-box;
        border-radius:15px;
        text-align: center;
    }  

    input[type="submit"]{     
        width: 10%;  
        background-color:skyblue;
        color: red;   
        padding: 10px;   
        font-size:17px;
        font-weight:bold;
        margin: 10px 0px;   
        border: 1px solid black;   
        cursor: pointer; 
        border-radius:10px;
         }   

    td,tr{
    size:15px;
    border-radius:15px;
    }

    form
    {
          background-color: rgb(232, 238, 234);
          padding-left: 50px;
          padding-right: 0px;
          padding-top: 50px;
          padding-bottom: 50px;
          width:75%;

    }

</style>   
</head>    
<body>

    <center> <h1> HOUSE REGISTRATION </h1> </center>
   <center> <form method="post" action="Save_Update_Delete_House.php">  
          
    <table>
         <tr>  

            <td><label class ="label" for="a">Full Name</label> <br>    
                <input type="text" id="a" placeholder="Full name of the owner " size="50px" name="full_name" ></td>  
    
            <td><label  class="label" for="b">Email</label><br>
                <input type="email" id="b" placeholder="E mail" name="email" size="50px" ></td>

                <td><label  class="label" >Phone number</label><br>
                    <input type="number" placeholder="10 digits phone number " name="phone_number" size="50px" ></td>      
         </tr>
           
         <tr>
            <td><label class ="label" for="a" >House No/Plot No </label> <br>    
                <input type="number" id="a" placeholder="enter house no" size="50px" name="house_no" ></td>  
    
            <td><label  class="label" for="b">Country</label><br>
                <input type="text" id="b" placeholder="enter country of the house" size="50px"  name="country" ></td>

            <td><label  class="label" >State</label><br>
                <input type="text" placeholder="enter state of the house "size="50px" name="state"  ></td>
            
                
         </tr>
            
        <tr>
            <td><label  class="label" >City</label><br>
                <input type="text" placeholder="enter city of the house " size="50px" name="city" ></td>
                <td><label  class="label">Address</label><br>
                    <input type="text" placeholder="house address" size="50px" name="home_address"  ></td>
                    <td><label  class="label" >Description</label><br>
                        <input type="text" placeholder="description" size="50px" name="discriptions"  ></td>
        </tr>

        <tr>
            <td><label  class="label" >Facilities</label><br>
                <input type="text" placeholder="enter house facilities" size="50px" name="facilities"  ></td>
                <td><label  class="label" >Pincode</label><br>
                    <input type="number" placeholder="enter house pincode"size="50px" name="pincode"  ></td>
                    <td><label  class="label" >Landmark</label><br>
                        <input type="text" placeholder="enter landmark "size="50px" name="landmark"  ></td>
        </tr>
        
        <tr>

            <td> 
                <label class="label" for="ac">Ac/Non Ac</label><br>
                <input list="choose_conditioner" placeholder="select Ac/non Ac" name="ac/nonac" size="50px" id="ac">
                <datalist id="choose_conditioner">
                  <option value="AC">
                  <option value="NON AC">
                </datalist>
             </td>
              
              <td>
                  <label class="label" for="bedroom">Available room</label><br>
                  <input list="choose_room" placeholder="select room type" size="50px" name="room_type" id="bedroom">
                  <datalist id="choose_room">
                      <option value="1BHK"></option>
                      <option value="2BHK"></OPTION>
                        <option value="3BHK"></OPTION>
                            <option value="4BHK"></OPTION>
                  </datalist>
              </td>
              <td>
                  <label class="label" for="status">Status</label><br>
                  <input list="choose_status" name="room_status"size="50px" placeholder="choose status of the room" id="status">
                  <datalist id="choose_status">
                      <option value="Vacant"></option>
                      <option value="Occupaid"></option>
                  </datalist>
              </td>
          </tr>
    
          <tr>
                <td>
                    <label class="label" for="rent">Rent/Sale</label><br>
                    <input list="choose_option" size="50px" name="rent_sale" placeholder="choose rent or sale " id="rent">
                    <datalist id="choose_option">
                        <option value="Rent"></option>
                        <option value="Sale"></option>
                        </datalist>
                </td>

                
                <td><label class ="label" >User Name </label> <br>    
                <input type="text" id="a" placeholder="enter user name" size="50px" name="User_name" ></td>  
                <td>

<label class="label" for="myfile" >House image</label><br>
<input type="file" placeholder="choose image of the house" size="50px" name="file" id="myfile" >

</td>
          </tr>
        
         
         </table>

       <input  type="submit" name="To_Update" value="Update">  
       <input  type="submit" name="To_Update" value="Delete">  
    </form>     </center>
</body>     
</html>  