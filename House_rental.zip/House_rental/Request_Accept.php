<?php
 session_start();
 $SELLER=$_SESSION['Uname'];  
 $BUYER=$_SESSION['N'];
 $HOUSE=$_SESSION['H'];

if($_POST['Request']=='Accept')
{
        $link = mysqli_connect('localhost', 'root', '','house_rent'); 
         //Check link to the mysql server 
         if(!$link) { 
         die('Failed to connect to server: '); 
         } 
        //Create query (if you have a Logins table the you can select login id and password from there)
        $qry ="SELECT TENANTS.SELLER,TENANTS.USER_NAME,TENANTS.HOUSE_NO,TENANTS.RENT_OR_BUY,TENANTS.NO_OF_DAYS,SELLERS.RENTPRICE,SELLERS.SELLINGPRICE,SELLERS.PHONE_NUMBER FROM TENANTS,SELLERS WHERE TENANTS.HOUSE_NO='$HOUSE' AND TENANTS.USER_NAME='$BUYER' AND SELLERS.USER_NAME='$SELLER' AND SELLERS.HOUSE_NO='$HOUSE' ";
        $result=mysqli_query($link, $qry); 

        $row = mysqli_fetch_assoc($result);
        $a=$row['SELLER'];
        $b=$row['USER_NAME'];
        $c=$row['HOUSE_NO'];
        $d=$row['RENT_OR_BUY'];
        $e=$row['NO_OF_DAYS'];
        $k=$row['PHONE_NUMBER'];
        $x='Rent';
        $y='Sale';
        if(strcmp($x,$d)==0)
        {
           $f=$e*$row['RENTPRICE'];
           
        }
        else 
        {
                $f=1*$row['SELLINGPRICE'];

        }
        $qry="INSERT INTO contracts(USER_NAME_S,USER_NAME_T,HOUSE_NO,RENT_OR_SALE,NO_OF_DAYS,AMOUNT_PAID,PHONE_PAY)  VALUES('$a','$b','$c','$d','$e','$f','$k')";        
                $result=mysqli_query($link, $qry); 
           if($result){
               
          }

        $g='Occupied';

        $qry="UPDATE sellers SET STATUS='$g' WHERE HOUSE_NO='$HOUSE'";

        $result=mysqli_query($link, $qry); 
        
        $qry="UPDATE tenants SET STATUS='Accepted' WHERE HOUSE_NO='$HOUSE' AND USER_NAME='$BUYER'";

        $result=mysqli_query($link, $qry); 

        if($result){
                echo '<script>
                window.alert("Request accepted");
                </script>';
                include 'Seller_View.php';
        }
        else{
                echo '<script>
                window.alert("error! try again ");
                </script>';
                include 'Seller_View.php';
        }
}

elseif($_POST['Request']=='Decline'){

    $link = mysqli_connect('localhost', 'root', '','house_rent'); 
    //Check link to the mysql server 
    if(!$link) { 
    die('Failed to connect to server: '); 
    } 
    $qry="UPDATE tenants SET STATUS='Declined' WHERE HOUSE_NO='$HOUSE' AND USER_NAME='$BUYER'";
    $result=mysqli_query($link, $qry); 
    if($result){
        echo '<script>
        window.alert("Request Denied");
        </script>';
        include 'Seller_View.php';
}else{
        echo '<script>
        window.alert("error! try again ");
        </script>';
        include 'Seller_View.php';
}
}
?>