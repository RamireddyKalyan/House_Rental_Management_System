<?php
session_start();
if($_POST['log']=='Sign up')
{

if(isset($_POST['Uname']) && trim($_POST['Uname']) !== ""&&isset($_POST['Pass1']) && trim($_POST['Pass1']) !== ""&&isset($_POST['Pass2']) && trim($_POST['Pass2']) !== ""&& isset($_POST['Role']) && trim($_POST['Role']) !== "")
{
    $Name=$_POST['Uname'];
    $Password1=$_POST['Pass1'];
    $Password2=$_POST['Pass2'];
    $Role=$_POST['Role'];
if($Role=='Admin'){
    echo '<script> 
    window.alert("You cannnot register as Admin ");
    window.location.assign("Sign_up.php");
    </script> ';
    exit();
   }

if($Password1!=$Password2)
{
    echo '<script> 
    window.alert("Enter same password both times");
    </script> ';
    session_destroy();
    include'Sign_up.php';
}

else
{
    //Connect to mysql server 
    $link = mysqli_connect('localhost', 'root', '','house_rent'); 
    //Check link to the mysql server 
    if(!$link) { 
    die('Failed to connect to server: '); 
    } 
    //Create query (if you have a Logins table the you can select login id and password from there)
    $qry="INSERT INTO user_account(USER_NAME,PASSWORD,ROLE) VALUES('$Name','$Password1','$Role')"; 
    //Execute query 
    $result=mysqli_query($link, $qry); 
    if($result)
    {
    $_SESSION['Uname']=$Name;
    $_SESSION['IS_AUTHENTICATED']=1;
    if($Role=='Buyer')
    {
        include('Tenent_View.php');
    }
    if($Role=='Seller')
    {
        include('Seller_View.php');
    }
    }
    else
    {

    echo '<script>
    window.alert("User name already exists! try another");
    </script>'; 
    session_destroy();
    include('Sign_up.php'); 

    }
}

}
else{

    echo '<center><h1>Fill all the details</h1></center>'; 
    session_destroy();
    include("Sign_up.php"); 
} 

} 

else{

    echo '<h1>error</h1>';
    session_destroy();
    include("Sign_up.php"); 

}
?>