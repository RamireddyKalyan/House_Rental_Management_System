<?php
session_start();
if($_POST['To_Sell']=='Post House')
{
    $Full_Name=$_POST['full_name'];
    $Email=$_POST['email'];
    $Pnumber=$_POST['phone_number'];
    $House_No=$_POST['house_no'];
    $State=$_POST['state'];
    $Country=$_POST['country'];
    $City=$_POST['city'];
    $Address=$_POST['home_address'];
    $Pincode=$_POST['pincode'];
    $Description=$_POST['discriptions'];
    $Facilities=$_POST['facilities'];
    $User_Name=$_POST['User_name'];
    $Ac=$_POST['ac/nonac'];
    $Landmark=$_POST['landmark'];
    $Status=$_POST['room_status'];
    $Rooms=$_POST['room_type'];
    $Why=$_POST['rent_sale'];
    $Image = $_POST['file'];
    $SPrice=$_POST['selling_price'];
    $RPrice=$_POST['rent_price'];

		


    if($Full_Name && $Pnumber && $House_No && $Country && $Address && $User_Name  && $State && $City && $Pincode && $Ac && $Image && $Landmark && $Status  && $Why && $Rooms )
    {
         //Connect to mysql server 
         $link = mysqli_connect('localhost', 'root', '','house_rent'); 
         //Check link to the mysql server 
         if(!$link) { 
         die('Failed to connect to server: '); 
         } 
        //Create query (if you have a Logins table the you can select login id and password from there)
        $qry="INSERT INTO sellers VALUES('$Full_Name','$Email','$Pnumber','$Country','$State','$City','$Address','$Description','$Facilities','$Pincode','$Landmark','$Ac','$Rooms','$Status','$Why','$User_Name','$House_No','$Image','$SPrice','$RPrice')";     
        //Execute query 
        $result=mysqli_query($link, $qry); 
        if($result)
        {

             echo '<script>

             window.alert("House added Sucessfully");
             window.location.assign("Show_House_Seller.php");
            </script>';

           

        }
        else
        {
            include('HouseNo_crct_Seller.php');
        }
    }
    else
    {
        include('Not_Entered_Seller.php');
    }
}
else
{
    exit();
}



?>
