<!DOCTYPE html>
<html lang="en">
<head>
    <style>
        
        h1
        {
            color:black;
            text-align:center;
            padding:100px;
        }
        a
        {
            text-align:center;
            text-decoration:none;
            font-size:25px;
            padding-left:650px;
        }

        </style>
</head>
<body>
    <h1>This UserName Already Exists....</h1>
    <a href="http://localhost/House_rental/Sign_up.php">Sign Up Here</a>
</body>