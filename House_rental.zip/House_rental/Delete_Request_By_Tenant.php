<?php
 session_start();
  $HOUSE=$_SESSION['H'];
if($_POST['Del']=='Delete')

{
        $link = mysqli_connect('localhost', 'root', '','house_rent'); 
         //Check link to the mysql server 
         if(!$link) { 
         die('Failed to connect to server: '); 
         } 
        //Create query (if you have a Logins table the you can select login id and password from there)
        $qry="DELETE FROM tenants WHERE HOUSE_NO='$HOUSE' ";
        $result=mysqli_query($link, $qry); 
        if($result){
                echo '<script><h1>
                window.alert("Request cancelled");
                </h1></script>';
                include 'Tenent_View.php';
        }else{
                echo '<script><h1>
                window.alert(" error! try again!");
                </h1></script>';
                include 'Tenent_View.php';
        }
}

?>