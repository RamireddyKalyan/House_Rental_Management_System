<?php

if($_POST['To_Buy']=='Request Owner')
{
    $Full_Name=$_POST['full_name'];
    $Email=$_POST['email'];
    $Pnumber=$_POST['phone_number'];
    $Seller=$_POST['user_seller'];
    $Adhar=$_POST['aadhar_number'];
    $User_Name=$_POST['user_name'];
    $Occupation=$_POST['occupation'];
    $House_No=$_POST['house_no'];
    $State=$_POST['state'];
    $City=$_POST['city'];
    $Pincode=$_POST['pincode'];
    if($Full_Name && $Pnumber && $Adhar && $User_Name && $House_No && $State && $City && $Pincode  && $Seller)
    {
         //Connect to mysql server 
         $link = mysqli_connect('localhost', 'root', '','house_rent'); 
         //Check link to the mysql server 
         if(!$link) { 
         die('Failed to connect to server: '); 
         } 
        //Create query (if you have a Logins table the you can select login id and password from there)
        $qry="INSERT INTO tenants(FULL_NAME,EMAIL,PHONE_NUMBER,USER_NAME,CITY,OCCUPATION,ADHAR,STATE,PINCODE,HOUSE_NO,RENT_OR_BUY,SELLER) VALUES('$Full_Name','$Email','$Pnumber','$User_Name','$City','$Occupation','$Adhar','$State','$Pincode','$House_No','Buy','$Seller') "; 
        $result=mysqli_query($link, $qry); 
        if($result)
        {
              echo '<script>
              window.alert("Request sent");
              </script>';
              include 'Requests_By_Tenant.php';
        }
 /*       else
        {
            echo '<script>
            window.alert("error! try again ");
            </script>';
            include 'tenent_registration(buy).php';
        }*/
        else
        {
           echo '<center><h1>Please Enter House Number OR User Name Correctly....</h1></center>';
            include('tenent_registration(buy).php');
         
        }
    }
    else
    {
        echo '<center><h1>Please Enter All the Required details ....</h1></center>';
        include('tenent_registration(buy).php');
       
    }
}

?>