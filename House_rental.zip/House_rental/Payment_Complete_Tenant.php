<?php
session_start();
$House=$_SESSION['U'];
if($_POST['Send']=='Sended')
{
    $link = mysqli_connect('localhost', 'root', '','house_rent'); 
    //Check link to the mysql server 
    if(!$link) { 
    die('Failed to connect to server: '); 
    } 
   //Create query (if you have a Logins table the you can select login id and password from there)
   $qry ="UPDATE CONTRACTS SET SEND='YES' WHERE HOUSE_NO='$House'";
   $result=mysqli_query($link, $qry); 
   
   if($result){
    echo '<script>
    window.alert("Money sended uccessfully");
    </script>';
    include 'Tenent_View.php';
    }
    else{
     echo '<script>
     window.alert("error! try again ");
     </script>';
     include 'Tenent_View.php';      
    }
}
?>