<!DOCTYPE html>   
<html>   
<head>  
<meta name="viewport" content="width=device-width, initial-scale=1">  
<title> house Registration Form</title>  
<style>   

body {  
  font-family: Calibri, Helvetica, sans-serif;  
  background-color:skyblue;  
}  
  
  .label{
      font-weight: bold;
      font-size: 20px;
  }
  
   input{ 
        width: 80%;     
        margin: 8px 00px;  
        padding: 10px 00px;   
        display: inline-block;   
        border: 2px solid blue; 
        box-sizing: border-box;
        border-radius:15px;
        text-align: center;
    }  

    input[type="submit"]{     
        width: 10%;  
        background-color:skyblue;
        color: red;   
        padding: 10px;   
        font-size:17px;
        font-weight:bold;
        margin: 10px 0px;   
        border: 1px solid black;   
        cursor: pointer; 
        border-radius:10px;
         }   

    td,tr{
    size:15px;
    border-radius:15px;
    }

    form
    {
          background-color: rgb(232, 238, 234);
          padding-left: 50px;
          padding-right: 0px;
          padding-top: 50px;
          padding-bottom: 50px;
          width:75%;

    }

</style>   
</head>    



<?php
  session_start();
  if(isset($_POST['Del']) && trim($_POST['Del']) !== "")
  {
    
    $link = mysqli_connect('localhost', 'root', '','house_rent'); 
    //Check link to the mysql server 
    if(!$link) { 
    die('Failed to connect to server: '); 
    } 
    $qry="SELECT HOUSE_NO FROM SELLERS";
    $result=mysqli_query($link, $qry);
    while($row = mysqli_fetch_assoc($result)){
    
      if($_POST['Del']==" Delete  House    No:".$row['HOUSE_NO']){
          $House=$row['HOUSE_NO'];
          $qry="DELETE FROM sellers WHERE HOUSE_NO='$House' ";
        $result=mysqli_query($link, $qry);
        
      if($result){
        echo '<script>
        window.alert("Sucessfully deleted");
        </script> ';
        include 'Seller_View.php';
      }else{
        echo '<script>
        window.alert("error! try again");
        </script> ';
        include 'Seller_View.php';
      }
          break;
      }
      
    }

}

else if(isset($_POST['Upd']) && trim($_POST['Upd']) !==""){   

  $link = mysqli_connect('localhost', 'root', '','house_rent'); 
  //Check link to the mysql server 
  if(!$link) { 
  die('Failed to connect to server: '); 
  } 
  $qry="SELECT HOUSE_NO FROM SELLERS";

  $result=mysqli_query($link, $qry);

  while($row = mysqli_fetch_assoc($result)){

    if($_POST['Upd']==" Update  House    No:".$row['HOUSE_NO']){
        $House=$row['HOUSE_NO'];
        $qry=" SELECT * FROM sellers WHERE HOUSE_NO='$House'";
  $result = mysqli_query($link, $qry);
  $row=mysqli_fetch_assoc($result);
  
  echo '<body>
  
  <center> <h1> HOUSE REGISTRATION </h1> </center>
  <center> <form method="post" action="Save_Update_Delete_House.php">  
        
  <table>
       <tr>  
  
          <td><label class ="label" for="a">Full Name</label> <br>    
              <input type="text" id="a" size="50px" name="full_name" value=" '.$row['FULL_NAME'] .'"></td>  
  
          <td><label  class="label" for="b">Email</label><br>
              <input type="email" id="b" placeholder="E mail" name="email" size="50px" value=" '.$row['EMAIL'].'"></td>
  
              <td><label  class="label" >Phone number</label><br>
                  <input type="number" placeholder="10 digits phone number " name="phone_number" size="50px" value='.$row['PHONE_NUMBER'].'></td>      
       </tr>
         
       <tr>
          <td><label class ="label" for="a" >House No/Plot No </label> <br>    
              <input type="text" id="a" placeholder="enter house no" size="50px" name="house_no" value=" '.$row['HOUSE_NO'].'"></td>  
  
          <td><label  class="label" for="b">Country</label><br>
              <input type="text" id="b" placeholder="enter country of the house" size="50px"  name="country" value=" '.$row['COUNTRY'].'"></td>
  
          <td><label  class="label" >State</label><br>
              <input type="text" placeholder="enter state of the house "size="50px" name="state" value=" '.$row['STATE'].'" ></td>
          
              
       </tr>
          
      <tr>
          <td><label  class="label" >City</label><br>
              <input type="text" placeholder="enter city of the house " size="50px" name="city" value=" '.$row['CITY'].'" ></td>
              <td><label  class="label">Address</label><br>
                  <input type="text" placeholder="house address" size="50px" name="home_address"  value=" '.$row['ADDRESS'].'"></td>
                  <td><label  class="label" >Description</label><br>
                      <input type="text" placeholder="description" size="50px" name="discriptions" value=" '.$row['DESCRIPTION'].'" ></td>
      </tr>
  
      <tr>
          <td><label  class="label" >Facilities</label><br>
              <input type="text" placeholder="enter house facilities" size="50px" name="facilities" value=" '.$row['FACILITIES'].'" ></td>
              <td><label  class="label" >Pincode</label><br>
                  <input type="number" placeholder="enter house pincode"size="50px" name="pincode" value='.$row['PINCODE'].'></td>
                  <td><label  class="label" >Landmark</label><br>
                      <input type="text" placeholder="enter landmark "size="50px" name="landmark"  value=" '.$row['LANDMARK'].'"></td>
      </tr>
      
      <tr>
  
          <td> 
              <label class="label" for="ac">Ac/Non Ac</label><br>
              <input list="choose_conditioner" placeholder="select Ac/non Ac" name="ac/nonac" size="50px" value=" '.$row['AC_OR_NOT'].'" id="ac">
              <datalist id="choose_conditioner">
                <option value="AC">
                <option value="NON AC">
              </datalist>
           </td>
            
            <td>
                <label class="label" for="bedroom">Available room</label><br>
                <input list="choose_room" placeholder="select room type" size="50px" name="room_type" value=" '.$row['ROOM_TYPE'].'" id="bedroom">
                <datalist id="choose_room">
                    <option value="1BHK"></option>
                    <option value="2BHK"></OPTION>
                      <option value="3BHK"></OPTION>
                          <option value="4BHK"></OPTION>
                </datalist>
            </td>
            <td>
                <label class="label" for="status">Status</label><br>
                <input list="choose_status" name="room_status"size="50px" placeholder="choose status of the room" value=" '.$row['STATUS'].'" id="status">
                <datalist id="choose_status">
                    <option value="Vacant"></option>
                    <option value="Occupaid"></option>
                </datalist>
            </td>
        </tr>
  
        <tr>
              <td>
                  <label class="label" for="rent">Rent/Sale</label><br>
                  <input list="choose_option" size="50px" name="rent_sale" placeholder="choose rent or sale " value=" '.$row['RENT_OR_SALE'].'"  id="rent">
                  <datalist id="choose_option">
                      <option value="Rent"></option>
                      <option value="Sale"></option>
                      </datalist>
              </td>
  
              
              <td><label class ="label" >User Name </label> <br>    
              <input type="text" id="a" placeholder="enter user name" size="50px" name="User_name" value=" '.$row['USER_NAME'].'"></td>  
              <td><label class ="label" for="a" >Selling Price</label> <br>    
              <input type=number id="a" placeholder="enter price if u are selling" size="50px" name="selling_price" value='.$row['SELLINGPRICE'].'></td> 
        </tr>
  
        <tr>
                        <td><label class ="label" for="a" >Cost for 1 Day </label> <br>    
                        <input type="text" id="a" placeholder="enter cost for 1 day if u rent" size="50px" name="rent_price" value='.$row['RENTPRICE'].'></td>   
        </tr>
       
       </table>
  
     <input  type="submit" name="To_Update" value="Update">  
  </form>     </center>
  </body>     
  </html>';

    }
  }
  

}
?>