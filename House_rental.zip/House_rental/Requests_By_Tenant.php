<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tenent view</title>
<style>
h1
        {
            text-align:center;
        }
        table.H
        {
           position: relative;
           left:200px;
           border-collapse:collapse;
        }

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color:rgb(119, 240, 220);
  border:1px solid black;
  border-collapse: collapse;
}

li {
  border:1px solid black;
   width:150px;
  text-align:center;
  font-weight: bold;
  float: left;
  border-collapse: collapse;
}

li a, .dropbtn {
  display: inline-block;
  color:rgb(17, 14, 14);
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}
li a:hover, .dropdown:hover .dropbtn {
  background-color: rgb(97, 185, 219);
  width:117px;
}

li.dropdown {
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #A0DAA9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {
  width:83%;
  background-color: #f1b4f1;}

.dropdown:hover .dropdown-content {
  display: block;
}

.start{
            border:1px solid black;
            background-color: #B55A30;
            display:block;
            text-align: center;
        }
  table,th{
        border-color:blue;
        border:2px solid black;
        border-collapse: collapse;
      }
    th,td{
      padding:20px;
    }
   tr:nth-child(even){ 
  background-color:#eee;
  }
  tr:nth-child(odd){
  background-color:#fff;
  }
      th{
        background-color: rgb(209, 186, 214);
     }
  
  

</style>
</head>
<body>
  <div class="start"> <h2> RENTAL HOUSE MANAGEMENT SYSTEM </h2></div>
<ul>
 
  <li class="dropdown">
    <a href="#" class="dropbtn"><img src="http://localhost/House_rental/Images/House_image.png" style="width:25px; height:25px;">
House</a>
    <div class="dropdown-content">
      <a href="Search_Tenant.php">Search House</a>
      <a href="tenent_registration(buy).php">Buy House</a>
      <a href="tenent_registration(rent).php">Rent House</a>
    </div></li>

  <li><a href="Contracts_By_Tenant.php"><img src="http://localhost/House_rental/Images/contract.png" style="width:25px; height:25px;">

Contract</a></li>
  <li><a href="Requests_By_Tenant.php"><img src="http://localhost/House_rental/Images/request.png" style="width:25px; height:25px;" >

Requests</a></li>
  <li><a href="Payment_View_Tenant.php"><img src="http://localhost/House_rental/Images/payment.png" style="width:25px; height:25px;" >
Payments</a></li>
  <li class="dropdown">

          <a href="#" class="dropbtn"><img src="http://localhost/House_rental/Images/complaint.png" style="width:25px; height:25px;" >
Complaint</a>
          <div class="dropdown-content">
          <a href="Post_TComplaint.php">Post Complaint</a>
          <a href="View_TComplaint.php">View Complaints</a>

        </div></li>
  <li class="dropdown" style="float:right;">
  
<form method="post" action="Delete_Request_By_Tenant.php">

  <?php

  session_start();

  $Name=$_SESSION['Uname'];
  
  echo '<a class="dropdown"><img src="http://localhost/House_rental/Images/user.png" style="width:25px; height:25px;" >

  '.$Name.'</a>';

?>
  <div class="dropdown-content">
      <a href="Start.php">Sign out</a>
    </div>
  </li>
</ul>

<?php 

  
 /*Connect to mysql server*/ 
$link = mysqli_connect('localhost', 'root', '', 'house_rent');  

/*Check link to the mysql server*/ 
if(!$link)
{ 
die('Failed to connect to server: ');
} 

 /*Create query*/ 
$qry= "SELECT sellers.USER_NAME,sellers.FULL_NAME,sellers.PHONE_NUMBER,tenants.HOUSE_NO,tenants.RENT_OR_BUY,tenants.NO_OF_DAYS FROM tenants,sellers WHERE tenants.USER_NAME='$Name' AND sellers.HOUSE_NO=tenants.HOUSE_NO  AND tenants.STATUS='ACCEPTED'";
/*Execute query*/ 
$result = mysqli_query($link, $qry);

if(mysqli_num_rows($result)>0)
{

echo '<h1>The Requests That are Accepted are - </h1>';

 /*Draw the table for Players*/ 
echo '<table class="H" border="5"> 
<th> SELLER USER NAME </th> 
<th> SELLER FULL NAME </th> 
 <th>PHONE NUMBER</th>
 <th>HOUSE NO</th>
 <th>RENT/SALE</th>
 <th>DAYS FOR RENT</th>
';

/*Show the rows in the fetched result set one by one*/ 
while ($row = mysqli_fetch_assoc($result))
{ 

echo '<tr> 
<td>'.$row['USER_NAME'].'</td>
<td>'.$row['FULL_NAME'].'</td>
<td>'.$row['PHONE_NUMBER'].'</td>
<td>'.$row['HOUSE_NO'].'</td>
<td>'.$row['RENT_OR_BUY'].'</td>
<td>'.$row['NO_OF_DAYS'].'</td>
</tr>';

}

echo '</table>';
}
else{  

   echo '<center><h1>NO Request has been Accepted till now</h1></center> ';

}

$qry= "SELECT sellers.USER_NAME,sellers.FULL_NAME,sellers.PHONE_NUMBER,tenants.HOUSE_NO,tenants.RENT_OR_BUY,tenants.NO_OF_DAYS FROM tenants,sellers WHERE tenants.USER_NAME='$Name' AND sellers.HOUSE_NO=tenants.HOUSE_NO AND TENANTS.STATUS='Declined' ";
/*Execute query*/ 
$result = mysqli_query($link, $qry);

if(mysqli_num_rows($result)>0)
{

echo '<h1>The Requests That are Declined are - </h1>';

 /*Draw the table for Players*/ 
echo '<table class="H" border="5"> 
<th> SELLER USER NAME </th> 
<th> SELLER FULL NAME </th> 
 <th>PHONE NUMBER</th>
 <th>HOUSE NO</th>
 <th>RENT/SALE</th>
 <th>DAYS FOR RENT</th>
';

/*Show the rows in the fetched result set one by one*/ 
while ($row = mysqli_fetch_assoc($result))
{ 

echo '<tr> 
<td>'.$row['USER_NAME'].'</td>
<td>'.$row['FULL_NAME'].'</td>
<td>'.$row['PHONE_NUMBER'].'</td>
<td>'.$row['HOUSE_NO'].'</td>
<td>'.$row['RENT_OR_BUY'].'</td>
<td>'.$row['NO_OF_DAYS'].'</td>
</tr>';

}

echo '</table>';
}else{
  
   echo '<center><h1>NO Request has been Declined till now</h1></center> ';
}


$qry= "SELECT sellers.USER_NAME,sellers.FULL_NAME,sellers.PHONE_NUMBER,tenants.HOUSE_NO,tenants.RENT_OR_BUY,tenants.NO_OF_DAYS FROM tenants,sellers WHERE tenants.USER_NAME='$Name' AND sellers.HOUSE_NO=tenants.HOUSE_NO AND TENANTS.STATUS='Requested' ";
/*Execute query*/ 
$result = mysqli_query($link, $qry);

if(mysqli_num_rows($result)>0)
{

echo '<h1>The Requests That are made are - </h1>';

 /*Draw the table for Players*/ 
echo '<table class="H" border="5"> 
<th> SELLER USER NAME </th> 
<th> SELLER FULL NAME </th> 
 <th>PHONE NUMBER</th>
 <th>HOUSE NO</th>
 <th>RENT/SALE</th>
 <th>DAYS FOR RENT</th>

 <th>DELETE</th>  
';

/*Show the rows in the fetched result set one by one*/ 
while ($row = mysqli_fetch_assoc($result))
{ 

echo '<tr> 
<td>'.$row['USER_NAME'].'</td>
<td>'.$row['FULL_NAME'].'</td>
<td>'.$row['PHONE_NUMBER'].'</td>
<td>'.$row['HOUSE_NO'].'</td>
<td>'.$row['RENT_OR_BUY'].'</td>
<td>'.$row['NO_OF_DAYS'].'</td>
<td>'.'<input type="submit" name="Del" value="Delete">'.'</td>
</tr>';

$_SESSION['H']=$row['HOUSE_NO'];


}

echo '</table>';
}else{
  
   echo '<center><h1>NO Request has been made till now</h1></center> ';
}


   ?>
</form>

</body>
</html>


