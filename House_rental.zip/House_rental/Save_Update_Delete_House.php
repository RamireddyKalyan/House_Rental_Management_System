
<?php
if($_POST['To_Update']=='Update')
{
    $Full_Name=$_POST['full_name'];
    $Email=$_POST['email'];
    $Pnumber=$_POST['phone_number'];
    $House_No=$_POST['house_no'];
    $State=$_POST['state'];
    $Country=$_POST['country'];
    $City=$_POST['city'];
    $Address=$_POST['home_address'];
    $Pincode=$_POST['pincode'];
    $Description=$_POST['discriptions'];
    $Facilities=$_POST['facilities'];
    $User_Name=$_POST['User_name'];
    $Ac=$_POST['ac/nonac'];
    $Landmark=$_POST['landmark'];
    $Status=$_POST['room_status'];
    $Rooms=$_POST['room_type'];
    $Why=$_POST['rent_sale'];
    $rentprice=$_POST['rent_price'];
    $sellprice=$_POST['selling_price'];

         //Connect to mysql server 
         $link = mysqli_connect('localhost', 'root', '','house_rent'); 
         //Check link to the mysql server 
         if(!$link) { 
         die('Failed to connect to server: '); 
         } 
        //Create query (if you have a Logins table the you can select login id and password from there)
    
        $qry="DELETE FROM SELLERS WHERE HOUSE_NO='$House_No' AND USER_NAME='User_Name'";

        $result=mysqli_query($link, $qry); 
        
        $qry="INSERT INTO SELLERS VALUES('$Full_Name','$Email','$Pnumber','$Country','$State','$City','$Address', '$Description','$Facilities','$Pincode','$Landmark','$Ac','$Rooms','$Status','$Why','$User_Name','$House_No','h1.jpeg','$sellprice','$rentprice')";

        $result=mysqli_query($link, $qry); 

        if($result)
        {
            echo '<script>window.alert("House Updated sucessfully") </script>';  
            session_start();
            include 'Seller_View.php';
        }

        else
        {
            echo '<script>window.alert("error! try again") 

            </script>';  
            session_start();
            include 'Seller_View.php';
        }
    
}


else if($_POST['To_Update']=='Delete')
{
    $Full_Name=$_POST['full_name'];
    $Email=$_POST['email'];
    $Pnumber=$_POST['phone_number'];
    $House_No=$_POST['house_no'];
    $State=$_POST['state'];
    $Country=$_POST['country'];
    $City=$_POST['city'];
    $Address=$_POST['home_address'];
    $Pincode=$_POST['pincode'];
    $Description=$_POST['discriptions'];
    $Facilities=$_POST['facilities'];
    $User_Name=$_POST['User_name'];
    $Ac=$_POST['ac/nonac'];
    $Landmark=$_POST['landmark'];
    $Status=$_POST['room_status'];
    $Rooms=$_POST['room_type'];
    $Why=$_POST['rent_sale'];
    if($Full_Name && $Pnumber && $House_No && $Country && $Address && $User_Name  && $State && $City && $Pincode && $Ac  && $Landmark && $Status  && $Why && $Rooms )
    {
         //Connect to mysql server 
         $link = mysqli_connect('localhost', 'root', '','house_rent'); 
         //Check link to the mysql server 
         if(!$link) { 
         die('Failed to connect to server: '); 
         } 
        //Create query (if you have a Logins table the you can select login id and password from there)
        $qry="DELETE FROM sellers WHERE HOUSE_NO='$House_No'";     
        //Execute query 
        $result=mysqli_query($link, $qry); 
        if($result)
        {
            echo '<script>window.alert("House Deleted sucessfully") </script>';  
            include 'Seller_View.php';
            
        }
        else
        {
            echo '<script>window.alert("error! try again") 
            window.location.assign("Delete_House_Seller.php")
            </script>';
        }
    }
    else
    {
        echo '<script>window.alert("Enter all details") 
            window.location.assign("Delete_House_Seller.php")
            </script>';
    }
}
else
{
    exit();
}



?>
