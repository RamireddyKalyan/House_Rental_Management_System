<?php
//session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tenent view</title>
<style>

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color:rgb(119, 240, 220);
  border:1px solid black;
  border-collapse: collapse;
}

li {
  border:1px solid black;
   width:150px;
  text-align:center;
  float: left;
  font-weight:bold;
  border-collapse: collapse;
}

li a, .dropbtn {
  display: inline-block;
  color:rgb(17, 14, 14);
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size:16px;
}

li a:hover, .dropdown:hover .dropbtn {
  background-color: rgb(97, 185, 219);
  width:117px;
}

li.dropdown {
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #A0DAA9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {
  width:83%;
  background-color: #f1b4f1;}

.dropdown:hover .dropdown-content {
  display: block;
}

.start{
            border:1px solid black;
            background-color: #B55A30;
            display:block;
            text-align: center;
        }
</style>
</head>
<body>
  <div class="start"> <h2> RENTAL HOUSE MANAGEMENT SYSTEM </h2></div>
<ul>
  <li class="dropdown">
    <a href="#" class="dropbtn"><span><img src="http://localhost/House_rental/Images/House_image.png" style="width:25px; height:25px;"></span>House</a>
    <div class="dropdown-content" >

      <a href="Search_Tenant.php">Search House</a>
      <a href="tenent_registration(buy).php">Buy House</a>
      <a href="tenent_registration(rent).php">Rent House</a>
    </div></li>

    <li><a href="#"><img src="http://localhost/House_rental/Images/contract.png" style="width:25px; height:25px;" >Contract</a></li>
  <li><a href="Requests_By_Tenant.php"><img src="http://localhost/House_rental/Images/request.png" style="width:25px; height:25px;" >Requests</a></li>
  <li><a href="Payment_View_Tenant.php"><img src="http://localhost/House_rental/Images/payment.png" style="width:25px; height:25px;" >Payments</a></li>

  <li class="dropdown">

          <a href="#" class="dropbtn"><img src="http://localhost/House_rental/Images/complaint.png" style="width:25px; height:25px;" >Complaint</a>
          <div class="dropdown-content">
          <a href="Post_TComplaint.php">Post Complaint</a>
          <a href="View_TComplaint.php">View Complaints</a>

        </div></li>
  <li class="dropdown" style="float:right;">
  <?php
  $Name=$_SESSION['Uname'];
  echo '<a href="#" class="dropbtn"><img src="http://localhost/House_rental/Images/user.png" style="width:25px; height:25px;" >'.$Name.'</a>';
  
?>
  <div class="dropdown-content">
      <a href="Start.php">Sign out</a>
    </div>
  </li>
</ul>

</body>
</html>


