<?php 
session_start(); 
session_unset(); 
session_destroy(); 
?>   
<!DOCTYPE html>    
<html> 
<body>
<style>
.login{  
        width: 382px;  
        overflow: hidden;  
        margin: auto;  
        margin: 20 0 0 450px;  
        padding: 80px;  
        background: #23463f;  
        border-radius: 15px ;  
       } 

       .label{
      font-weight: bold;
      font-size: 20px;
  }
  
   input{ 
        width: 80%;     
        margin: 8px 00px;  
        padding: 10px 00px;   
        display: inline-block;   
        border: 2px solid blue; 
        box-sizing: border-box;
        border-radius:15px;
        text-align: center;
    }  
    

h2{  
    text-align: center;  
    color: #277582;  
    padding: 20px;  
}  
label{  
    color: #08ffd1;  
    font-size: 17px;  
}  

span{  
    color: white;  
    font-size: 17px;  
}  
a{  
    float: right;  
    background-color: grey;  
} 
.one{     
        width: 30%;  
        color: red;   
        padding: 10px;   
        font-size:13px;
        font-weight:bold;
        margin: 10px 0px;   
        border: 1px solid black;   
        cursor: pointer; 
        border-radius:10px;
         }   
</style>
</body>
<head>    
    <title>Login Form</title>    
    
</head>    
<body>    
    <h2>Sign Up Page</h2><br>    
    <div class="login">    
    <form id="login" method="post" action="Save_account.php">    
        <label><b>User Name</b></label>    
        <input type="text" name="Uname" placeholder="enter Username" required>    
        <br>
        <label><b>Password</b></label><br>    
        <input type="Password" name="Pass1"  placeholder=" enter Password" required>    
        <br>   
        <label><b>Re Password</b></label><br>    
        <input type="Password" name="Pass2"  placeholder="re enter Password" required>    
        <br>   
        <label class="label" for="r">Role</label><br>
                <input list="choose" placeholder="choose role " name="Role" id="r" required>
                <datalist id="choose" >
                  <option value="Buyer">
                  <option value="Seller">
                </datalist>
        <br>
        <input class="one" type="submit" name="log"  value="Sign up">      
        <br>
    </form>     
</div>    
</body>    
</html>     


   
      