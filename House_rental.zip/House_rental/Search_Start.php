<!DOCTYPE>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NOBROKER</title>
    <style>
        form
        {
            padding-bottom:100px;
            position:relative;
            top:60px;
        }
        nav
        {
            margin-top: 0px;
            padding-top: 5px;
            padding-left: 10px;
            background-color:mediumturquoise;
        }
        button
        {
            position: relative;
            left:1000px;
            top:-12px;
            border-radius: 15px;
            font-size: 20px;
            padding: 9px;
            text-decoration: none;
            color: black;
        }
        .A
        {
            position: relative;
            top: 4px;
            left: 5px;
            
        }
        .xy
        {
            position: relative;
            top: 4px;
            left: 5px;
            height:40px;
        }
        .B:hover,.B:active,.B:visited,.B:link
        {
            text-decoration: none;
            color: black;
        }
        .B:hover
        {
            color:hotpink;
        }
        .B:active
        {
            color:red;
        }
        h1
        {
            text-align: center;
            color: grey;
            font-size: 36px;
            padding-top: 20px;
            font-weight: 190;
        }
        
        body
        {
            background-image: url('data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBUSFRgSEhUYGBgYGRIYGhgYGBgYGBgYGRwaGRgYGBgcIS4lHB4rIRgYJjgmKy8xNTU1GiQ7QDs0Py40NTEBDAwMEA8QGRESGDEhGiExMTE0MTE0MTExNDQ0NDU0PzQ0NDQxNDQxMTQ0NDExND80PzE0NDUxMTExNDExNDExMf/AABEIALcBFAMBIgACEQEDEQH/xAAcAAACAgMBAQAAAAAAAAAAAAAAAQIGAwQFBwj/xABHEAABAwEEBQYKCAQFBQAAAAABAAIRAwQSITEFBkFRYRMicYGR0RYyQlJygpKhscEHFCNUorLh8DNiwtIVJENTwzRjk9Pj/8QAFgEBAQEAAAAAAAAAAAAAAAAAAAEC/8QAGxEBAQEAAwEBAAAAAAAAAAAAABEBAiExEkH/2gAMAwEAAhEDEQA/ALS17qZD2YEZcd4VlsFsbVbIwI8Zu49yrpbKjSe6m4PYcR7xtBG5aFuTla9itbarbwwIzbtB7lmOOCyMgTSapBAwEJhJA0JJoGhCCUAhRkptKCaEIQCEBCAQhCAQhCAQDsScUmZygyIQmgEIQgEIQgAmkkTuQSQoXjtCT3gCSQBxQTQuBb9a7NQfybqjZgHPehWaOKx4ITcyVo06hGBW2yoYnZvWhmoOdTdfbn+8COxdyw25tTmnB0YtO3fB2riAg7P3tA7FC4QZGBGIO1QW4Jrk2DSgPMqGDsdsPTuK6oWRIISTQCaSaBqKko5IJEJORATQSQhCACEBCAQhCASc5DnQo/FAoWRrUNbCaBoSQgaEIQNCSECcURsWtbrYyk29UeGjiQJVC1k13eRcsrcCD9pJ/DGcbujNXMot2m9P0rK0hxvOjBox6ZXmesOtte0zTpyxsukDF0bAXDBu2QO1a9pY/wA4ve4i88mcfl1ZLJZtHRJu75joWszMRXBYScS4TxJn4IVtdY34XYiBsQrR2mPDlmY0jxT++C6mkdX2ul9CGu8w+Kejzfh0LihzqbrlRpa4bD8VBtsdsWwFrMeDkVMsJ2lRWRzNy39GaRLIY8y3Ydrf0WgziVJzQcs0FsCFw9H6RNPmVMW7Du/RdxjgRIMg7QshoSTQCaSaBAKaipIBCEIBEoQgEJApoIubKbWwmhA0JJoBC17TbGUhNRzW9JxPQMyuRX1rs7Zu33ngwifahB30Ko1db3eRS9p3cFzbXrXanYMaxnUSe0lWaL3Xrtpi89waOJVP09ru2nLbM0vMGXkQ0cQdqq1d9WuTyzy7biTCdOytAutEifjvVziOZa7XXtTg6q9zh5uQ6gPiupYLFDcBBmTP6zBWxZ6LGw2IhbtMDICehWo1aVhAER0xhitpouCCJ4psYNnH9ym5vYgx3+B6skKHYkg9ACwWqysqi7UaDuO0dB2LLKFlVbtmh6lLnU5ezd5Y6vK6uxa9C0g4HA8VbgVq2rR1Ori9vO84YO7dvWrRwmgHaszWKVp0NUp403Xx5uTu53uWjZ7VJjIjZkg3ieCxMqPZixxbOwHDrGSytqBScO35d6CbNMVgMQw9IPvghSZp95MFjcMzJWqaYKgbOOpIOh4QO2Ux7RPyUqGnXHxqYPEEj3GVzDTjAYBSGG1IO/Q0ux3jSz0su0LMdIUvPb2qthhOIKkQ4DIFILF/iFLLlGdq2WuBEgyN4xVRBveQsjX3MrzeifkpBbEKrt0nUBEPkbnQfiJW9S0w4eM1p4h134ykHaQFpW/SVOgxtR5MOgNAxLiRMDqC4VfWon+G1o4uN49giO0pBalhr2tlPx3tb6TgOwKlWnTtSpgasDczmDtGPvXJqaSY0iSJKsFxtusgaYosL97ncxvvEnsWjX07aHiBcZPmyXdp7lXX6dpMwvAncMT2LSZpqpUJFOi+JgOc0sHa4BIjsuozJOJOJJMkneSc1jBZTxdtwjaeAG0rBZqdZxvVHtaIHNGJ44nuXRs1FgMgFz4zdiQOG7qVGuQSLxbdGyc+vcsRYHLrPs4dIJwWJ1CBHvRWgaMx+8lnp0CNy2MG7llp0y8ExgPig0eQkrYp0YxXfsOhebL8J2DP9F0aejaTfInpx/RSinlmyMdwWSno+rUwawjPPD4q6NoNbk0DoAWUKUUtmrlaNiFdUJRzYTQhAwmEgmgkCtDSOiadbE81/ntzPpDat5NBTrTSfZ33KmXku8lw7+Cmy04SVa61JtQXXtDhuIlc1+gKJ8W+zodI7HSrRzqdUHasweIU6mrx8ip2t+YPyWD/AAO0bH0/aeP6EGYXSi43euDrO+vYGMqODHte8MF15BvFrnYgtyhhVOt2s9pqCKcMwwPjEbNwHbKuZR6c9jYwSpsJHjH3FeTN0tbjh9ZfmfIp7vRWSjpi3MGFcnAHnMYc+gJ86j1Rwe2bsGNkR71ytJaeFAXq1J7WzF+4XMG6XNkDrVQs2sduaYJY7EjFhBwE4w6FtVLZaLS2KzgG3Q641sNvTgTJMnduSK7PhbZpzdOWDHZ7ojNc+ppR9V/KMlrLousIEOg5uaQZJ48FiZY2g5eUdn8qnyfN9VEYNOWitXN8vJcCYJywHmjAdULkvtFojJuWd53whWBzMfWd+VYKlHDqCorjxXky/MnLgOIXMttnfElzifSIz6ArfWpgT0v+C6uqmrv1h/LVB9m2IHnOGzoSjo6s2GkyzMDAAbovE4OLoxLicSelbFag0kgZSPfmAo62aFqU2Oq2NwYc3NuyzDyruwb92eUrzs6dtuIc8AiZ5mIIMb1Myq9EY0Cd3HctavpqzUzcNVgd5t5s48F59VFesftKr3YgEeK2IyutwWOjo0CBGEHYN+ZV+UejN0m13iuHaFmp1S7oXH1C0ax9ocyoC9nJuIaSQA4FsHA7p7V6VR0RQZ4tMdZJ+JWd6VV7Lo99Q81pjfkO1WKw6KDILzMZNGQO87yumBGAQpQJoQoBMIQgaEIQc5NATVAE1HrTQSQhCBJoQgFIKKkFBUPpG51Oiz+d7vZYR/WqKyy9P+mO0q8a/ul1EbmV3dppgfAqsMbj6zB2YreeI1qdl6c3n5LKyy4bcqY7Vt0GTHRUPvy6VsvaAI3GmBt2yQQMncUo0qdAAz/M/wCCyNZh6tP3qY/9h98Jf/Me9A9vrO/Koxh6rVIZ9b/gls6qaAIx9Z35VhecPVCz7fWd+Vaduc4M5rS4wMBG0cUG5onRTrZUu5Ma6Xu+Q44FYPpQf9XNFlKq6iAyOYL0iXmM88JldjRuswoMbSp2RwAJBPKMlzgJLjhtULbp9lb7SrYQ4hvNvVRJE4jBsYEnHin6qqan2xztJMpmu94zuOGA5oM3rxns2q0a06timTWpjmEEFo8gnZ6O7dluUbPpinTeHMsDGua7Bwq4gxmOZxXRq62kth1lvNc0/wCq2CJgtILPcndFSbR6c2qLaOWeTvitq/ee6GOY280iXB2BMgSIJ27NiUZet8VUdvUcRahxpvHz+S9HXm2qLotdPi14/A4r0lZ31QhCFkNCSaByosdKi525SpoJoSQg54QkmqJscEh7lGVKUDamkhA0kFKUDTBUZRKCk68vmsxu6kPxPcP6VwqWLp2B5k5xDVf9JaDo2h/KVL96GNwdAhpJGze4rk2bQFIm80ujBwxHlTIOG6Fc0cBr7og+Lc28Ydd3TxQXS4z549wC6Os9npWOk2q5r3gvbTuh4bAuucIJafNjrVYdrLSzFmqZzPLNzy8xXEdInD1Xn8SZdj61Ncz/AB1hbIoeS7mmsCYzOAZwlX2nq7ScA6X43XZjOOhN6FUa7/k+KYPwprZ1wfQ0a2m9zHvD+UyeARBZ/KZkv9yqx10s12/yFSLwb47ZlokYXOKCwg4+s/4LGcvVaupqgyjpGia4Y9gD3NALwZwEnxRvWrpK2WShVfQcyu4shpLbkHAER2oNY5+ufyrI0gP52Qa/oGOC0rTpWnUeynZab77n48oC7MQLracuJ6jwC3alnri6H0heeSwTStTQZBd5TBJ5pwEk9qDZtTQ8gNguvN6htlar2BguzJN7oGM9qyOdVpuZRFHn1A94PJWqIZGy5eJxGQMbYWlaNIiz1m0rRQOLb5utrMddLi3miqGyZ4RxQTJ/4ysTzBHS/wCC3jpiwx/Ar+7Zl5S71l0TZq1NlZjXBr4Ik44mDOKeDjasPi1UTxcO1pHzXpxK4mjtAWZtysxha4AOBvOOPRMLtLO6qSUpoUAoOMpOd1Qm0IG0SppJoGhJCDnoUQpKhpqMpygYTlRlEoJSolEpFASiUpSlBMLnaPyj+Sn/AFLeBWjYBifQp/1oKp9J9dwpUqdw3XPLy/YHNBaGdJD3H1F5DZ3n6w4SYh2EmMhsXs30msmyMO6tT97Xgryqno9oeamMmduGOHyW+PiLfpFr/qOjy5lNt6z1Yc1xLnjkRJfzBDoxzOM4r1KzHmM9BnwC8QtOkKpo06T3lzKLHMpgtZzGltwiQ0F2EDGV7dYjNNnoU/yhTfBQPpiA5Ci5wJAdUEAwcbhzjgvJy+nyXiOi+cL+26MZur6A1g1ZpW4t5Z9S60QGNLLkzJcQ5pxy7AuOPo0sUXZqRMx9nE5T4iZuZisP0PuBsb7ogcq7Amdg2qv61f8AW152Pb2XGcF6Hq9q5SsIc2i9910cxxZdB84BrRivO9bT/na/pj8jOKZ6jU0Peda6HJXQ8PZcvTcvXsLwbBjoXpGlRb71nvuss8uLl1tWL9yp40uxbF7LGYXkta0Ppfa03XXMF5rgcWkYyMc1jGuVtqSX2h5LA57JPiuAgOHGHHtV3KPV7e23fXbNeNmv3LXcIbVuARTv3wTM5RB3qpa/srfXKZtRpl4oC6aV4NuGpk4OkzM4yqeNc7a8mq60PL6beY4xLQ9zWvA6R8FGy6btFsq3rQ/lHNY0BzvGDb4MA7pJTMHcrRByyOwdy9M1cP8Ak6Hot/MV5jUOB6Dt/Venauj/ACdD0WfmU5eCxaOP2TPRC2Vq6O/hM9ELZlYU01GU0AWpoQgcolJSQCEIQc2U5UE1RKU5UJRKCcolQQgnKRcoJEFBMlRvKBaVie1yDYvqtHXGyU6j6bnulhumGPi80uDhlsUtP6dZYw01HEX7wbDSfFiZjpC8oqVOUq1KgMhz3OnLNxO0TtV48aLrrxrPZrVZxSouc519jzLS3mtDhOPFzR1qoN/fvWCowwNp6txQah809re9bzIiVp8Q9HcvVLHrpYm02B1RwLWMBFx+YaJ2LyVzyRl23fmVJoMDo4bk3KPXvDWw/wC6f/G/+1Ia7WHH7U4fyP8A7V5GWE7enLuUiwnLPZiMenDP99MmD1vw3sP+6fYf/atd+t+jnElxvHeaJJPWRK8rFM5dP7yTDHb/AHjuSYV6Fa9JaIqvNRzXBxibjXsBjCYaQJyxWEWjQ+6p21v7lRLh/cdykGnf8O5IL4LToj/udtb+5SFo0Pvf21+9URrT1dWee5EFIPTWaf0WwBrQwAAAfYnLIY3cVOprdYQ0BtWALsAMeAACMhdXl5B/ZWN4MyTGQmeP6pMHv9htDKlNj6Z5jmtLcIwIkYbFnlUnU/T7KgZZmklzWN2GOY0A4kK3ArG4rZlOVrgp31BnBTlYA9TD0GSU5UA5OUEkKKEGrcRyazQmAgw8mjk1mhEIMPJo5NZ4RCDByaVxbEIhBg5NK4tm6i4g4+k9B0LVdFek192S2ZwmJiDwHYtJmp9iblZmD2u9Wa4i4rRXPBOx/dqf4u9HgpZPu7Pxd6scIuJdFb8FLJ93Z+LvT8FLH92Z7+9WO4iEorngrY/u1PsPel4KWP7szsPerJcRcSitnVWx/dmdh70/BeyfdqfYe9WO4i4lFc8GLJ92p+yjwZsn3an7KsdxFxKK54M2T7tT9lMas2T7tT9lWK4i4lFe8G7J92pewEnasWM52al7AViuIuJRxbDoSzUHX6VFjHQRea2DBzErowti4i4lGuhbFxK6gwhAKzXUXVBjDlK+pXUrqAvoRdQgE1jlMFBNJx3ZqJcoz+/3tQZWlOVEIlBKUSkhBKUSooQSlEqKRKCYKJWOEZIMqUqMoQSlOVGUSglKJSlEoHKEpRKBpBxnh71FzkMKCaEpRKBoUZRKCSSUolA0SkSo5oJykowgFBJCSEGEFMlCFQkwhCgleReQhUEpgoQoHKEIQCjvQhBMu2RmouCEIGmEIQCEIQCEIQCiShCBNCmhCAQhCAQhCAQhCCL1IGEIQKZxSCEIGhCEH//Z');
            background-size:2000px;
            background-repeat: repeat-y;
        }

  /* tr{
     border-bottom:3px solid grey;
   }*/
      table,th{
        border:2px solid black;
        border-collapse: collapse;
       
      }
    th,td{
      padding:20px;
    }
   tr:nth-child(even){ 
  background-color:#eee;
  }
  tr:nth-child(odd){
  background-color:#fff;
  }
      th{
        background-color: rgb(209, 186, 214);
     }

    .perfect{
      margin:10px 10px;
      float:left;
    }
    a
    {
      text-decoration:none;
    }
   </style>
</head>
<body>
    <nav>
        <img class="xy" src="http://localhost/House_rental/Images/0.svg">
        <button type="submit"> <a href="Start.php">Home</a></button>
        <button type="submit"> <img class="A" src="http://localhost/House_rental/Images/1.png" position:relative top:20px height=20px>&nbsp; &nbsp;<a class="B" href="http://localhost/House_rental/Sign_up.php">Sign Up </a></button>
        <button type="submit"> <img class="A" src="http://localhost/House_rental/Images/2.jfif" position:relative top:20px height=20px>&nbsp; &nbsp;<a class="B" href="http://localhost/House_rental/Login.php">Login</a></button>   
    </nav>
    <h1>World's Largest NoBrokerage Property Site</h1>


<?php
 



 if(isset($_POST['filter']) && $_POST['filter']=='search')
 {
     if(isset($_POST['search_state'])&& trim($_POST['search_state']) !== ""){
      $state=$_POST['search_state'];
     }
     if(isset($_POST['search_city'])&& trim($_POST['search_city']) !== ""){
     $filter_city=$_POST['search_city'];
     }
     if(isset($_POST['ac'])&& trim($_POST['ac']) !== "")
     $conditioner=$_POST['ac'];
     if(isset($_POST['room_status'])&& trim($_POST['room_status']) !== "")
     $status=$_POST['room_status'];
     if(isset($_POST['select_room'])&& trim($_POST['select_room']) !== "")
     $room_type=$_POST['select_room'];
     $link = mysqli_connect('localhost', 'root', '', 'house_rent');  
/*Check link to the mysql server*/ 
if(!$link)
{ 
die('Failed to connect to server: ');
} 
if(isset($_POST['search_state']) && trim($_POST['search_state']) !== "" && isset($_POST['search_city'])&& trim($_POST['search_city']) !== "" && isset($_POST['ac']) && trim($_POST['ac']) !== ""&& isset($_POST['room_status'])&& trim($_POST['room_status']) !== "" && isset($_POST['select_room'])&& trim($_POST['select_room']) !== ""){
/*Create query*/ 
//echo empty($_POST['ac']);
$qry = "SELECT  * FROM sellers WHERE RENT_OR_SALE='$status' AND ROOM_TYPE='$room_type'AND STATE='$state' AND CITY='$filter_city' AND AC_OR_NOT= '$conditioner' "; 

$result = mysqli_query($link, $qry);

if(mysqli_num_rows($result)>0){
  echo '<center><h1>The Houses are - </h1></center>';

  while ($row = mysqli_fetch_assoc($result))
    {

  echo'<div class="perfect" >
    <table style="width:50%" > 
    <tr>
    <th colspan="2">OWNER DETAILS</th>
    <th colspan="2">ROOM DETAILS</th>
    </tr>

    <tr>
    <td> <b>FULL NAME : </b> </td> 
    <td>'.$row['FULL_NAME'].'</td>
    <td><b>HOUSE NO : </b></td>
    <td>'.$row['HOUSE_NO'].'</td>
    </tr>
    <tr>
    <td><b>EMAIL :<b></td>
    <td>'.$row['EMAIL'].'</td> 
    <td><b>ROOM TYPE</b></td>
    <td>'.$row['ROOM_TYPE'].'</td>
    </tr>
    <tr>
    <td><b>PHONE NUMBER</b></td>
    <td>'.$row['PHONE_NUMBER'].'</td> 
    <td><b>AC/NOT</b></td>
    <td>'.$row['AC_OR_NOT'].'</td>
    </tr>
    <tr>
    <td><b>USERNAME</b></td>
    <td>'.$row['USER_NAME'].'</td>
    <td><b>RENT/SALE</b></td>
    <td>'.$row['RENT_OR_SALE'].'</td>
    </tr>
    <tr>
    <td><b>COUNTRY</b></td>
    <td>'.$row['COUNTRY'].'</td>
    <td><b>STATUS</b></td>
    <td>'.$row['STATUS'].'</td>
    </tr>
    <tr>
    <td style="height:30px" ><b>DESCRIPTION</b></td>
    <td>'.$row['DESCRIPTION'].'</td>
    <td><b>STATE</b></td>
    <td>'.$row['STATE'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td><b>CITY</b></td>
    <td>'.$row['CITY'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td><b>ADDRESS</b></td>
    <td>'.$row['ADDRESS'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td><b>PINCODE</b></td>
    <td>'.$row['PINCODE'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td><b>LANDMARK</b></td>
    <td>'.$row['LANDMARK'].'</td>
    </table>

     </div>';
    
}
echo '<br<br><br>';
}
else{
   echo '<center><h1>Oops ! NO HOUSES FOUND </h1></center> ';
}



}

else if(isset($_POST['search_state']) && trim($_POST['search_state']) !== "" && isset($_POST['search_city'])&& trim($_POST['search_city']) !== "" && isset($_POST['ac']) && trim($_POST['ac']) !== ""&& isset($_POST['room_status'])&& trim($_POST['room_status']) !== "" ){


    $qry = "SELECT * FROM sellers WHERE RENT_OR_SALE='$status' AND STATE='$state' AND CITY='$filter_city'  AND AC_OR_NOT= '$conditioner' "; 

  /*Execute query*/ 
  $result = mysqli_query($link, $qry);
  
  if(mysqli_num_rows($result)>0){
    echo '<center><h1>The Houses are - </h1></center>';
    while ($row = mysqli_fetch_assoc($result))
    {

  echo'<div class="perfect" >
    <table style="width:50%" > 
    <tr>
    <th colspan="2">OWNER DETAILS</th>
    <th colspan="2">ROOM DETAILS</th>
    </tr>

    <tr>
    <td> <b>FULL NAME : </b> </td> 
    <td>'.$row['FULL_NAME'].'</td>
    <td><b>HOUSE NO : </b></td>
    <td>'.$row['HOUSE_NO'].'</td>
    </tr>
    <tr>
    <td><b>EMAIL :<b></td>
    <td>'.$row['EMAIL'].'</td> 
    <td><b>ROOM TYPE</b></td>
    <td>'.$row['ROOM_TYPE'].'</td>
    </tr>
    <tr>
    <td><b>PHONE NUMBER</b></td>
    <td>'.$row['PHONE_NUMBER'].'</td> 
    <td><b>AC/NOT</b></td>
    <td>'.$row['AC_OR_NOT'].'</td>
    </tr>
    <tr>
    <td><b>USERNAME</b></td>
    <td>'.$row['USER_NAME'].'</td>
    <td><b>RENT/SALE</b></td>
    <td>'.$row['RENT_OR_SALE'].'</td>
    </tr>
    <tr>
    <td><b>COUNTRY</b></td>
    <td>'.$row['COUNTRY'].'</td>
    <td><b>STATUS</b></td>
    <td>'.$row['STATUS'].'</td>
    </tr>
    <tr>
    <td style="height:30px" ><b>DESCRIPTION</b></td>
    <td>'.$row['DESCRIPTION'].'</td>
    <td><b>STATE</b></td>
    <td>'.$row['STATE'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td><b>CITY</b></td>
    <td>'.$row['CITY'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td><b>ADDRESS</b></td>
    <td>'.$row['ADDRESS'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td><b>PINCODE</b></td>
    <td>'.$row['PINCODE'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td><b>LANDMARK</b></td>
    <td>'.$row['LANDMARK'].'</td>
    </table>

     </div>';
    
}
 echo '<br><br><br>';
    
  }else{
     echo '<center><h1>Oops ! NO HOUSES FOUND </h1></center> ';
  }
  
}


else if(isset($_POST['search_state']) && trim($_POST['search_state']) !== "" && isset($_POST['search_city'])&& trim($_POST['search_city']) !== "" && isset($_POST['ac']) && trim($_POST['ac']) !== ""&&  isset($_POST['select_room'])&& trim($_POST['select_room']) !== ""){
  /*Create query*/ 
  //echo empty($_POST['ac']);
  $qry = "SELECT  * FROM sellers WHERE  ROOM_TYPE='$room_type'AND STATE='$state' AND CITY='$filter_city' AND AC_OR_NOT= '$conditioner' "; 
  
  $result = mysqli_query($link, $qry);
  
  if(mysqli_num_rows($result)>0){
    echo '<center><h1>The Houses are - </h1></center>';
    while ($row = mysqli_fetch_assoc($result))
    {

  echo'<div class="perfect" >
    <table style="width:50%" > 
    <tr>
    <th colspan="2">OWNER DETAILS</th>
    <th colspan="2">ROOM DETAILS</th>
    </tr>

    <tr>
    <td> <b>FULL NAME : </b> </td> 
    <td>'.$row['FULL_NAME'].'</td>
    <td><b>HOUSE NO : </b></td>
    <td>'.$row['HOUSE_NO'].'</td>
    </tr>
    <tr>
    <td><b>EMAIL :<b></td>
    <td>'.$row['EMAIL'].'</td> 
    <td><b>ROOM TYPE</b></td>
    <td>'.$row['ROOM_TYPE'].'</td>
    </tr>
    <tr>
    <td><b>PHONE NUMBER</b></td>
    <td>'.$row['PHONE_NUMBER'].'</td> 
    <td><b>AC/NOT</b></td>
    <td>'.$row['AC_OR_NOT'].'</td>
    </tr>
    <tr>
    <td><b>USERNAME</b></td>
    <td>'.$row['USER_NAME'].'</td>
    <td><b>RENT/SALE</b></td>
    <td>'.$row['RENT_OR_SALE'].'</td>
    </tr>
    <tr>
    <td><b>COUNTRY</b></td>
    <td>'.$row['COUNTRY'].'</td>
    <td><b>STATUS</b></td>
    <td>'.$row['STATUS'].'</td>
    </tr>
    <tr>
    <td style="height:30px" ><b>DESCRIPTION</b></td>
    <td>'.$row['DESCRIPTION'].'</td>
    <td><b>STATE</b></td>
    <td>'.$row['STATE'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td><b>CITY</b></td>
    <td>'.$row['CITY'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td><b>ADDRESS</b></td>
    <td>'.$row['ADDRESS'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td><b>PINCODE</b></td>
    <td>'.$row['PINCODE'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td><b>LANDMARK</b></td>
    <td>'.$row['LANDMARK'].'</td>
    </table>

     </div>';
    
}
 echo '<br><br><br>';
  
  }else{
     echo '<center><h1>Oops ! NO HOUSES FOUND </h1></center> ';
  }
  
  
  
  }


  else if(isset($_POST['search_state']) && trim($_POST['search_state']) !== "" && isset($_POST['search_city'])&& trim($_POST['search_city']) !== "" && isset($_POST['ac'])&& trim($_POST['ac'])!=""){
    /*Create query*/ 
    //echo empty($_POST['ac']);
    $qry = "SELECT  * FROM sellers WHERE RENT_OR_SALE='$status' AND ROOM_TYPE='$room_type'AND STATE='$state' AND CITY='$filter_city' AND AC_OR_NOT='$conditioner' "; 
    
    $result = mysqli_query($link, $qry);
    
    if(mysqli_num_rows($result)>0){
      echo '<center><h1>The Houses are - </h1></center>';
      while ($row = mysqli_fetch_assoc($result))
    {

  echo'<div class="perfect" >
    <table style="width:50%" > 
    <tr>
    <th colspan="2">OWNER DETAILS</th>
    <th colspan="2">ROOM DETAILS</th>
    </tr>

    <tr>
    <td> <b>FULL NAME : </b> </td> 
    <td>'.$row['FULL_NAME'].'</td>
    <td><b>HOUSE NO : </b></td>
    <td>'.$row['HOUSE_NO'].'</td>
    </tr>
    <tr>
    <td><b>EMAIL :<b></td>
    <td>'.$row['EMAIL'].'</td> 
    <td><b>ROOM TYPE</b></td>
    <td>'.$row['ROOM_TYPE'].'</td>
    </tr>
    <tr>
    <td><b>PHONE NUMBER</b></td>
    <td>'.$row['PHONE_NUMBER'].'</td> 
    <td><b><AC/NOT</b></td>
    <td>'.$row['AC_OR_NOT'].'</td>
    </tr>
    <tr>
    <td><b>USERNAME</b></td>
    <td>'.$row['USER_NAME'].'</td>
    <td><b>RENT/SALE</b></td>
    <td>'.$row['RENT_OR_SALE'].'</td>
    </tr>
    <tr>
    <td><b>COUNTRY</b></td>
    <td>'.$row['COUNTRY'].'</td>
    <td><b>STATUS</b></td>
    <td>'.$row['STATUS'].'</td>
    </tr>
    <tr>
    <td style="height:30px" ><b>DESCRIPTION</b></td>
    <td>'.$row['DESCRIPTION'].'</td>
    <td><b>STATE</b></td>
    <td>'.$row['STATE'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td><b>CITY</b></td>
    <td>'.$row['CITY'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td><b>ADDRESS</b></td>
    <td>'.$row['ADDRESS'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td><b>PINCODE</b></td>
    <td>'.$row['PINCODE'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td><b>LANDMARK</b></td>
    <td>'.$row['LANDMARK'].'</td>
    </table>

     </div>';
    
}
 echo '<br><br><br>';
    
    }else{
       echo '<center><h1>Oops ! NO HOUSES FOUND </h1></center> ';
    }
    
    
    
    }





    else if(isset($_POST['search_state']) && trim($_POST['search_state']) !== "" && isset($_POST['search_city'])&& trim($_POST['search_city']) !== "" && isset($_POST['room_status'])&& trim($_POST['room_status']) !== "" ){
      /*Create query*/ 
      //echo empty($_POST['ac']);
      $qry = "SELECT  * FROM sellers WHERE RENT_OR_SALE='$status' AND STATE='$state' AND CITY='$filter_city'"; 
      
      $result = mysqli_query($link, $qry);
      
      if(mysqli_num_rows($result)>0){
        echo '<center><h1>The Houses are - </h1></center>';
        while ($row = mysqli_fetch_assoc($result))
    {

  echo'<div class="perfect" >
    <table style="width:50%" > 
    <tr>
    <th colspan="2">OWNER DETAILS</th>
    <th colspan="2">ROOM DETAILS</th>
    </tr>

    <tr>
    <td> <b>FULL NAME : </b> </td> 
    <td>'.$row['FULL_NAME'].'</td>
    <td><b>HOUSE NO : </b></td>
    <td>'.$row['HOUSE_NO'].'</td>
    </tr>
    <tr>
    <td><b>EMAIL :<b></td>
    <td>'.$row['EMAIL'].'</td> 
    <td><b>ROOM TYPE</b></td>
    <td>'.$row['ROOM_TYPE'].'</td>
    </tr>
    <tr>
    <td><b>PHONE NUMBER</b></td>
    <td>'.$row['PHONE_NUMBER'].'</td> 
    <td><b>AC/NOT</b></td>
    <td>'.$row['AC_OR_NOT'].'</td>
    </tr>
    <tr>
    <td><b>USERNAME</b></td>
    <td>'.$row['USER_NAME'].'</td>
    <td><b>RENT/SALE</b></td>
    <td>'.$row['RENT_OR_SALE'].'</td>
    </tr>
    <tr>
    <td><b>COUNTRY</b></td>
    <td>'.$row['COUNTRY'].'</td>
    <td><b>STATUS</b></td>
    <td>'.$row['STATUS'].'</td>
    </tr>
    <tr>
    <td style="height:30px" ><b>DESCRIPTION</b></td>
    <td>'.$row['DESCRIPTION'].'</td>
    <td><b>STATE</b></td>
    <td>'.$row['STATE'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td><b>CITY</b></td>
    <td>'.$row['CITY'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td><b>ADDRESS</b></td>
    <td>'.$row['ADDRESS'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td><b>PINCODE</b></td>
    <td>'.$row['PINCODE'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td><b>LANDMARK</b></td>
    <td>'.$row['LANDMARK'].'</td>
    </table>

     </div>';
    
}
 echo '<br><br><br>';
      
      
      }else{
         echo '<center><h1>Oops ! NO HOUSES FOUND </h1></center> ';
      }
      
      
      
      }




      else if(isset($_POST['search_state']) && trim($_POST['search_state']) !== "" && isset($_POST['search_city'])&& trim($_POST['search_city']) !== "" && isset($_POST['select_room'])&& trim($_POST['select_room']) !== "" ){
        /*Create query*/ 
        //echo empty($_POST['ac']);
        $qry = "SELECT  * FROM sellers WHERE STATE='$state' AND CITY='$filter_city' AND ROOM_TYPE='$room_type' "; 
        
        $result = mysqli_query($link, $qry);
        
        if(mysqli_num_rows($result)>0){
          echo '<center><h1>The Houses are - </h1></center>';
          while ($row = mysqli_fetch_assoc($result))
    {

  echo'<div class="perfect" >
    <table style="width:50%" > 
    <tr>
    <th colspan="2">OWNER DETAILS</th>
    <th colspan="2">ROOM DETAILS</th>
    </tr>

    <tr>
    <td> <b>FULL NAME : </b> </td> 
    <td>'.$row['FULL_NAME'].'</td>
    <td><b>HOUSE NO : </b></td>
    <td>'.$row['HOUSE_NO'].'</td>
    </tr>
    <tr>
    <td><b>EMAIL :<b></td>
    <td>'.$row['EMAIL'].'</td> 
    <td><b>ROOM TYPE</b></td>
    <td>'.$row['ROOM_TYPE'].'</td>
    </tr>
    <tr>
    <td><b>PHONE NUMBER</b></td>
    <td>'.$row['PHONE_NUMBER'].'</td> 
    <td><b>AC/NOT</b></td>
    <td>'.$row['AC_OR_NOT'].'</td>
    </tr>
    <tr>
    <td><b>USERNAME</b></td>
    <td>'.$row['USER_NAME'].'</td>
    <td><b>RENT/SALE</b></td>
    <td>'.$row['RENT_OR_SALE'].'</td>
    </tr>
    <tr>
    <td><b>COUNTRY</b></td>
    <td>'.$row['COUNTRY'].'</td>
    <td><b>STATUS</b></td>
    <td>'.$row['STATUS'].'</td>
    </tr>
    <tr>
    <td style="height:30px" ><b>DESCRIPTION</b></td>
    <td>'.$row['DESCRIPTION'].'</td>
    <td><b>STATE</b></td>
    <td>'.$row['STATE'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td><b>CITY</b></td>
    <td>'.$row['CITY'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td><b>ADDRESS</b></td>
    <td>'.$row['ADDRESS'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td><b>PINCODE</b></td>
    <td>'.$row['PINCODE'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td><b>LANDMARK</b></td>
    <td>'.$row['LANDMARK'].'</td>
    </table>

     </div>';
    
}
 echo '<br><br><br>';
        
        
        }else{
           echo '<center><h1>Oops ! NO HOUSES FOUND </h1></center> ';
        }
        
        
        
        }
  


       else if(isset($_POST['search_state']) && trim($_POST['search_state']) !== "" && isset($_POST['ac']) && trim($_POST['ac']) !== ""&& isset($_POST['room_status'])&& trim($_POST['room_status']) !== "" ){
          /*Create query*/ 
          //echo empty($_POST['ac']);
          $qry = "SELECT  * FROM sellers WHERE RENT_OR_SALE='$status' AND STATE='$state'  AND AC_OR_NOT= '$conditioner' "; 
          
          $result = mysqli_query($link, $qry);
          
          if(mysqli_num_rows($result)>0){
            echo '<center><h1>The Houses are - </h1></center>';
          
            while ($row = mysqli_fetch_assoc($result))
              {
          
            echo'<div class="perfect" >
              <table style="width:50%" > 
              <tr>
              <th colspan="2">OWNER DETAILS</th>
              <th colspan="2">ROOM DETAILS</th>
              </tr>
          
              <tr>
              <td> <b>FULL NAME : </b> </td> 
              <td>'.$row['FULL_NAME'].'</td>
              <td><b>HOUSE NO : </b></td>
              <td>'.$row['HOUSE_NO'].'</td>
              </tr>
              <tr>
              <td><b>EMAIL :<b></td>
              <td>'.$row['EMAIL'].'</td> 
              <td><b>ROOM TYPE</b></td>
              <td>'.$row['ROOM_TYPE'].'</td>
              </tr>
              <tr>
              <td><b>PHONE NUMBER</b></td>
              <td>'.$row['PHONE_NUMBER'].'</td> 
              <td><b>AC/NOT</b></td>
              <td>'.$row['AC_OR_NOT'].'</td>
              </tr>
              <tr>
              <td><b>USERNAME</b></td>
              <td>'.$row['USER_NAME'].'</td>
              <td><b>RENT/SALE</b></td>
              <td>'.$row['RENT_OR_SALE'].'</td>
              </tr>
              <tr>
              <td><b>COUNTRY</b></td>
              <td>'.$row['COUNTRY'].'</td>
              <td><b>STATUS</b></td>
              <td>'.$row['STATUS'].'</td>
              </tr>
              <tr>
              <td style="height:30px" ><b>DESCRIPTION</b></td>
              <td>'.$row['DESCRIPTION'].'</td>
              <td><b>STATE</b></td>
              <td>'.$row['STATE'].'</td>
              </tr>
              <tr>
              <td></td>
              <td></td>
              <td><b>CITY</b></td>
              <td>'.$row['CITY'].'</td>
              </tr>
              <tr>
              <td></td>
              <td></td>
              <td><b>ADDRESS</b></td>
              <td>'.$row['ADDRESS'].'</td>
              </tr>
              <tr>
              <td></td>
              <td></td>
              <td><b>PINCODE</b></td>
              <td>'.$row['PINCODE'].'</td>
              </tr>
              <tr>
              <td></td>
              <td></td>
              <td><b>LANDMARK</b></td>
              <td>'.$row['LANDMARK'].'</td>
              </table>
          
               </div>';
              
          }
          echo '<br<br><br>';
          }
          else{
             echo '<center><h1>Oops ! NO HOUSES FOUND </h1></center> ';
          }
          
          
          
          }


         else if(isset($_POST['search_state']) && trim($_POST['search_state']) !== "" && isset($_POST['ac']) && trim($_POST['ac']) !== "" && isset($_POST['select_room'])&& trim($_POST['select_room']) !== ""){
            /*Create query*/ 
            //echo empty($_POST['ac']);
            $qry = "SELECT  * FROM sellers WHERE  ROOM_TYPE='$room_type' AND STATE='$state' AND AR_OR_NOT='$conditioner' "; 
            
            $result = mysqli_query($link, $qry);
        

              if($result){

              echo '<center><h1>The Houses are - </h1></center>';
            
              while ($row = mysqli_fetch_assoc($result))
                {
            
              echo'<div class="perfect" >
                <table style="width:50%" > 
                <tr>
                <th colspan="2">OWNER DETAILS</th>
                <th colspan="2">ROOM DETAILS</th>
                </tr>
            
                <tr>
                <td> <b>FULL NAME : </b> </td> 
                <td>'.$row['FULL_NAME'].'</td>
                <td><b>HOUSE NO : </b></td>
                <td>'.$row['HOUSE_NO'].'</td>
                </tr>
                <tr>
                <td><b>EMAIL :<b></td>
                <td>'.$row['EMAIL'].'</td> 
                <td><b>ROOM TYPE</b></td>
                <td>'.$row['ROOM_TYPE'].'</td>
                </tr>
                <tr>
                <td><b>PHONE NUMBER</b></td>
                <td>'.$row['PHONE_NUMBER'].'</td> 
                <td><b>AC/NOT</b></td>
                <td>'.$row['AC_OR_NOT'].'</td>
                </tr>
                <tr>
                <td><b>USERNAME</b></td>
                <td>'.$row['USER_NAME'].'</td>
                <td><b>RENT/SALE</b></td>
                <td>'.$row['RENT_OR_SALE'].'</td>
                </tr>
                <tr>
                <td><b>COUNTRY</b></td>
                <td>'.$row['COUNTRY'].'</td>
                <td><b>STATUS</b></td>
                <td>'.$row['STATUS'].'</td>
                </tr>
                <tr>
                <td style="height:30px" ><b>DESCRIPTION</b></td>
                <td>'.$row['DESCRIPTION'].'</td>
                <td><b>STATE</b></td>
                <td>'.$row['STATE'].'</td>
                </tr>
                <tr>
                <td></td>
                <td></td>
                <td><b>CITY</b></td>
                <td>'.$row['CITY'].'</td>
                </tr>
                <tr>
                <td></td>
                <td></td>
                <td><b>ADDRESS</b></td>
                <td>'.$row['ADDRESS'].'</td>
                </tr>
                <tr>
                <td></td>
                <td></td>
                <td><b>PINCODE</b></td>
                <td>'.$row['PINCODE'].'</td>
                </tr>
                <tr>
                <td></td>
                <td></td>
                <td><b>LANDMARK</b></td>
                <td>'.$row['LANDMARK'].'</td>
                </table>
            
                 </div>';
                
            }
            echo '<br<br><br>';

            }else{
              echo '<center><h1>Oops ! NO HOUSES FOUND </h1></center> ';
           }
            
            
            
            }

            else if(isset($_POST['search_state']) && trim($_POST['search_state']) !== "" && isset($_POST['room_status'])&& trim($_POST['room_status']) !== "" && isset($_POST['select_room'])&& trim($_POST['select_room']) !== ""){
              /*Create query*/ 
              //echo empty($_POST['ac']);
              $qry = "SELECT  * FROM sellers WHERE RENT_OR_SALE='$status' AND ROOM_TYPE='$room_type'AND STATE='$state'"; 
              
              $result = mysqli_query($link, $qry);
              
              if(mysqli_num_rows($result)>0){

                echo '<center><h1>The Houses are - </h1></center>';
              
                while ($row = mysqli_fetch_assoc($result))
                  {
              
                echo'<div class="perfect" >
                  <table style="width:50%" > 
                  <tr>
                  <th colspan="2">OWNER DETAILS</th>
                  <th colspan="2">ROOM DETAILS</th>
                  </tr>
              
                  <tr>
                  <td> <b>FULL NAME : </b> </td> 
                  <td>'.$row['FULL_NAME'].'</td>
                  <td><b>HOUSE NO : </b></td>
                  <td>'.$row['HOUSE_NO'].'</td>
                  </tr>
                  <tr>
                  <td><b>EMAIL :<b></td>
                  <td>'.$row['EMAIL'].'</td> 
                  <td><b>ROOM TYPE</b></td>
                  <td>'.$row['ROOM_TYPE'].'</td>
                  </tr>
                  <tr>
                  <td><b>PHONE NUMBER</b></td>
                  <td>'.$row['PHONE_NUMBER'].'</td> 
                  <td><b>AC/NOT</b></td>
                  <td>'.$row['AC_OR_NOT'].'</td>
                  </tr>
                  <tr>
                  <td><b>USERNAME</b></td>
                  <td>'.$row['USER_NAME'].'</td>
                  <td><b>RENT/SALE</b></td>
                  <td>'.$row['RENT_OR_SALE'].'</td>
                  </tr>
                  <tr>
                  <td><b>COUNTRY</b></td>
                  <td>'.$row['COUNTRY'].'</td>
                  <td><b>STATUS</b></td>
                  <td>'.$row['STATUS'].'</td>
                  </tr>
                  <tr>
                  <td style="height:30px" ><b>DESCRIPTION</b></td>
                  <td>'.$row['DESCRIPTION'].'</td>
                  <td><b>STATE</b></td>
                  <td>'.$row['STATE'].'</td>
                  </tr>
                  <tr>
                  <td></td>
                  <td></td>
                  <td><b>CITY</b></td>
                  <td>'.$row['CITY'].'</td>
                  </tr>
                  <tr>
                  <td></td>
                  <td></td>
                  <td><b>ADDRESS</b></td>
                  <td>'.$row['ADDRESS'].'</td>
                  </tr>
                  <tr>
                  <td></td>
                  <td></td>
                  <td><b>PINCODE</b></td>
                  <td>'.$row['PINCODE'].'</td>
                  </tr>
                  <tr>
                  <td></td>
                  <td></td>
                  <td><b>LANDMARK</b></td>
                  <td>'.$row['LANDMARK'].'</td>
                  </table>
              
                   </div>';
                  
              }
              echo '<br<br><br>';
              }
              else{
                 echo '<center><h1>Oops ! NO HOUSES FOUND </h1></center> ';
              }
              
              
              
              }    

              else if(isset($_POST['search_state']) && trim($_POST['search_state']) !== "" && isset($_POST['search_city'])&& trim($_POST['search_city']) !== ""){
                /*Create query*/ 
                //echo empty($_POST['ac']);
                $qry = "SELECT  * FROM sellers WHERE  STATE='$state' AND CITY='$filter_city' "; 
                
                $result = mysqli_query($link, $qry);
                
                if(mysqli_num_rows($result)>0){
                  echo '<center><h1>The Houses are - </h1></center>';
                
                  while ($row = mysqli_fetch_assoc($result))
                    {
                
                  echo'<div class="perfect" >
                    <table style="width:50%" > 
                    <tr>
                    <th colspan="2">OWNER DETAILS</th>
                    <th colspan="2">ROOM DETAILS</th>
                    </tr>
                
                    <tr>
                    <td> <b>FULL NAME : </b> </td> 
                    <td>'.$row['FULL_NAME'].'</td>
                    <td><b>HOUSE NO : </b></td>
                    <td>'.$row['HOUSE_NO'].'</td>
                    </tr>
                    <tr>
                    <td><b>EMAIL :<b></td>
                    <td>'.$row['EMAIL'].'</td> 
                    <td><b>ROOM TYPE</b></td>
                    <td>'.$row['ROOM_TYPE'].'</td>
                    </tr>
                    <tr>
                    <td><b>PHONE NUMBER</b></td>
                    <td>'.$row['PHONE_NUMBER'].'</td> 
                    <td><b>AC/NOT</b></td>
                    <td>'.$row['AC_OR_NOT'].'</td>
                    </tr>
                    <tr>
                    <td><b>USERNAME</b></td>
                    <td>'.$row['USER_NAME'].'</td>
                    <td><b>RENT/SALE</b></td>
                    <td>'.$row['RENT_OR_SALE'].'</td>
                    </tr>
                    <tr>
                    <td><b>COUNTRY</b></td>
                    <td>'.$row['COUNTRY'].'</td>
                    <td><b>STATUS</b></td>
                    <td>'.$row['STATUS'].'</td>
                    </tr>
                    <tr>
                    <td style="height:30px" ><b>DESCRIPTION</b></td>
                    <td>'.$row['DESCRIPTION'].'</td>
                    <td><b>STATE</b></td>
                    <td>'.$row['STATE'].'</td>
                    </tr>
                    <tr>
                    <td></td>
                    <td></td>
                    <td><b>CITY</b></td>
                    <td>'.$row['CITY'].'</td>
                    </tr>
                    <tr>
                    <td></td>
                    <td></td>
                    <td><b>ADDRESS</b></td>
                    <td>'.$row['ADDRESS'].'</td>
                    </tr>
                    <tr>
                    <td></td>
                    <td></td>
                    <td><b>PINCODE</b></td>
                    <td>'.$row['PINCODE'].'</td>
                    </tr>
                    <tr>
                    <td></td>
                    <td></td>
                    <td><b>LANDMARK</b></td>
                    <td>'.$row['LANDMARK'].'</td>
                    </table>
                
                     </div>';
                    
                }
                echo '<br<br><br>';
                }
                else{
                   echo '<center><h1>Oops ! NO HOUSES FOUND </h1></center> ';
                }
                
                
                
                }


                else if(isset($_POST['search_state']) && trim($_POST['search_state']) !== "" &&  isset($_POST['ac']) && trim($_POST['ac']) !== ""){
                  /*Create query*/ 
                  //echo empty($_POST['ac']);
                  $qry = "SELECT  * FROM sellers WHERE  STATE='$state'  AND AC_OR_NOT= '$conditioner' "; 
                  
                  $result = mysqli_query($link, $qry);
                  
                  if(mysqli_num_rows($result)>0){
                    echo '<center><h1>The Houses are - </h1></center>';
                  
                    while ($row = mysqli_fetch_assoc($result))
                      {
                  
                    echo'<div class="perfect" >
                      <table style="width:50%" > 
                      <tr>
                      <th colspan="2">OWNER DETAILS</th>
                      <th colspan="2">ROOM DETAILS</th>
                      </tr>
                  
                      <tr>
                      <td> <b>FULL NAME : </b> </td> 
                      <td>'.$row['FULL_NAME'].'</td>
                      <td><b>HOUSE NO : </b></td>
                      <td>'.$row['HOUSE_NO'].'</td>
                      </tr>
                      <tr>
                      <td><b>EMAIL :<b></td>
                      <td>'.$row['EMAIL'].'</td> 
                      <td><b>ROOM TYPE</b></td>
                      <td>'.$row['ROOM_TYPE'].'</td>
                      </tr>
                      <tr>
                      <td><b>PHONE NUMBER</b></td>
                      <td>'.$row['PHONE_NUMBER'].'</td> 
                      <td><b>AC/NOT</b></td>
                      <td>'.$row['AC_OR_NOT'].'</td>
                      </tr>
                      <tr>
                      <td><b>USERNAME</b></td>
                      <td>'.$row['USER_NAME'].'</td>
                      <td><b>RENT/SALE</b></td>
                      <td>'.$row['RENT_OR_SALE'].'</td>
                      </tr>
                      <tr>
                      <td><b>COUNTRY</b></td>
                      <td>'.$row['COUNTRY'].'</td>
                      <td><b>STATUS</b></td>
                      <td>'.$row['STATUS'].'</td>
                      </tr>
                      <tr>
                      <td style="height:30px" ><b>DESCRIPTION</b></td>
                      <td>'.$row['DESCRIPTION'].'</td>
                      <td><b>STATE</b></td>
                      <td>'.$row['STATE'].'</td>
                      </tr>
                      <tr>
                      <td></td>
                      <td></td>
                      <td><b>CITY</b></td>
                      <td>'.$row['CITY'].'</td>
                      </tr>
                      <tr>
                      <td></td>
                      <td></td>
                      <td><b>ADDRESS</b></td>
                      <td>'.$row['ADDRESS'].'</td>
                      </tr>
                      <tr>
                      <td></td>
                      <td></td>
                      <td><b>PINCODE</b></td>
                      <td>'.$row['PINCODE'].'</td>
                      </tr>
                      <tr>
                      <td></td>
                      <td></td>
                      <td><b>LANDMARK</b></td>
                      <td>'.$row['LANDMARK'].'</td>
                      </table>
                  
                       </div>';
                      
                  }
                  echo '<br<br><br>';
                  }
                  else{
                     echo '<center><h1>Oops ! NO HOUSES FOUND </h1></center> ';
                  }
                  
                  
                  
                  }

                  else if(isset($_POST['search_state']) && trim($_POST['search_state']) !== "" && isset($_POST['room_status'])&& trim($_POST['room_status']) !== "" ){
                    /*Create query*/ 
                    //echo empty($_POST['ac']);
                    $qry = "SELECT  * FROM sellers WHERE RENT_OR_SALE='$status' AND STATE='$state'"; 
                    
                    $result = mysqli_query($link, $qry);
                    
                    if(mysqli_num_rows($result)>0){
                      echo '<center><h1>The Houses are - </h1></center>';
                    
                      while ($row = mysqli_fetch_assoc($result))
                        {
                    
                      echo'<div class="perfect" >
                        <table style="width:50%" > 
                        <tr>
                        <th colspan="2">OWNER DETAILS</th>
                        <th colspan="2">ROOM DETAILS</th>
                        </tr>
                    
                        <tr>
                        <td> <b>FULL NAME : </b> </td> 
                        <td>'.$row['FULL_NAME'].'</td>
                        <td><b>HOUSE NO : </b></td>
                        <td>'.$row['HOUSE_NO'].'</td>
                        </tr>
                        <tr>
                        <td><b>EMAIL :<b></td>
                        <td>'.$row['EMAIL'].'</td> 
                        <td><b>ROOM TYPE</b></td>
                        <td>'.$row['ROOM_TYPE'].'</td>
                        </tr>
                        <tr>
                        <td><b>PHONE NUMBER</b></td>
                        <td>'.$row['PHONE_NUMBER'].'</td> 
                        <td><b>AC/NOT</b></td>
                        <td>'.$row['AC_OR_NOT'].'</td>
                        </tr>
                        <tr>
                        <td><b>USERNAME</b></td>
                        <td>'.$row['USER_NAME'].'</td>
                        <td><b>RENT/SALE</b></td>
                        <td>'.$row['RENT_OR_SALE'].'</td>
                        </tr>
                        <tr>
                        <td><b>COUNTRY</b></td>
                        <td>'.$row['COUNTRY'].'</td>
                        <td><b>STATUS</b></td>
                        <td>'.$row['STATUS'].'</td>
                        </tr>
                        <tr>
                        <td style="height:30px" ><b>DESCRIPTION</b></td>
                        <td>'.$row['DESCRIPTION'].'</td>
                        <td><b>STATE</b></td>
                        <td>'.$row['STATE'].'</td>
                        </tr>
                        <tr>
                        <td></td>
                        <td></td>
                        <td><b>CITY</b></td>
                        <td>'.$row['CITY'].'</td>
                        </tr>
                        <tr>
                        <td></td>
                        <td></td>
                        <td><b>ADDRESS</b></td>
                        <td>'.$row['ADDRESS'].'</td>
                        </tr>
                        <tr>
                        <td></td>
                        <td></td>
                        <td><b>PINCODE</b></td>
                        <td>'.$row['PINCODE'].'</td>
                        </tr>
                        <tr>
                        <td></td>
                        <td></td>
                        <td><b>LANDMARK</b></td>
                        <td>'.$row['LANDMARK'].'</td>
                        </table>
                    
                         </div>';
                        
                    }
                    echo '<br<br><br>';
                    }
                    else{
                       echo '<center><h1>Oops ! NO HOUSES FOUND </h1></center> ';
                    }
                    
                    
                    
                    }
                    else if(isset($_POST['search_state']) && trim($_POST['search_state']) !== "" && isset($_POST['select_room'])&& trim($_POST['select_room']) !== ""){
                      /*Create query*/ 
                      //echo empty($_POST['ac']);
                      $qry = "SELECT  * FROM sellers WHERE ROOM_TYPE='$room_type'AND STATE='$state'  "; 
                      
                      $result = mysqli_query($link, $qry);
                      
                      if(mysqli_num_rows($result)>0){
                        echo '<center><h1>The Houses are - </h1></center>';
                      
                        while ($row = mysqli_fetch_assoc($result))
                          {
                      
                        echo'<div class="perfect" >
                          <table style="width:50%" > 
                          <tr>
                          <th colspan="2">OWNER DETAILS</th>
                          <th colspan="2">ROOM DETAILS</th>
                          </tr>
                      
                          <tr>
                          <td> <b>FULL NAME : </b> </td> 
                          <td>'.$row['FULL_NAME'].'</td>
                          <td><b>HOUSE NO : </b></td>
                          <td>'.$row['HOUSE_NO'].'</td>
                          </tr>
                          <tr>
                          <td><b>EMAIL :<b></td>
                          <td>'.$row['EMAIL'].'</td> 
                          <td><b>ROOM TYPE</b></td>
                          <td>'.$row['ROOM_TYPE'].'</td>
                          </tr>
                          <tr>
                          <td><b>PHONE NUMBER</b></td>
                          <td>'.$row['PHONE_NUMBER'].'</td> 
                          <td><b>AC/NOT</b></td>
                          <td>'.$row['AC_OR_NOT'].'</td>
                          </tr>
                          <tr>
                          <td><b>USERNAME</b></td>
                          <td>'.$row['USER_NAME'].'</td>
                          <td><b>RENT/SALE</b></td>
                          <td>'.$row['RENT_OR_SALE'].'</td>
                          </tr>
                          <tr>
                          <td><b>COUNTRY</b></td>
                          <td>'.$row['COUNTRY'].'</td>
                          <td><b>STATUS</b></td>
                          <td>'.$row['STATUS'].'</td>
                          </tr>
                          <tr>
                          <td style="height:30px" ><b>DESCRIPTION</b></td>
                          <td>'.$row['DESCRIPTION'].'</td>
                          <td><b>STATE</b></td>
                          <td>'.$row['STATE'].'</td>
                          </tr>
                          <tr>
                          <td></td>
                          <td></td>
                          <td><b>CITY</b></td>
                          <td>'.$row['CITY'].'</td>
                          </tr>
                          <tr>
                          <td></td>
                          <td></td>
                          <td><b>ADDRESS</b></td>
                          <td>'.$row['ADDRESS'].'</td>
                          </tr>
                          <tr>
                          <td></td>
                          <td></td>
                          <td><b>PINCODE</b></td>
                          <td>'.$row['PINCODE'].'</td>
                          </tr>
                          <tr>
                          <td></td>
                          <td></td>
                          <td><b>LANDMARK</b></td>
                          <td>'.$row['LANDMARK'].'</td>
                          </table>
                      
                           </div>';
                          
                      }
                      echo '<br<br><br>';
                      }
                      else{
                         echo '<center><h1>Oops ! NO HOUSES FOUND </h1></center> ';
                      }
                      
                      
                      
                      }


                      else if(isset($_POST['search_state']) && trim($_POST['search_state']) !== "" ){
                        /*Create query*/ 
                        //echo empty($_POST['ac']);
                        $qry = "SELECT  * FROM sellers WHERE STATE='$state'"; 
                        
                        $result = mysqli_query($link, $qry);
                        
                        if(mysqli_num_rows($result)>0){
                          echo '<center><h1>The Houses are - </h1></center>';
                        
                          while ($row = mysqli_fetch_assoc($result))
                            {
                        
                          echo'<div class="perfect" >
                            <table style="width:50%" > 
                            <tr>
                            <th colspan="2">OWNER DETAILS</th>
                            <th colspan="2">ROOM DETAILS</th>
                            </tr>
                        
                            <tr>
                            <td> <b>FULL NAME : </b> </td> 
                            <td>'.$row['FULL_NAME'].'</td>
                            <td><b>HOUSE NO : </b></td>
                            <td>'.$row['HOUSE_NO'].'</td>
                            </tr>
                            <tr>
                            <td><b>EMAIL :<b></td>
                            <td>'.$row['EMAIL'].'</td> 
                            <td><b>ROOM TYPE</b></td>
                            <td>'.$row['ROOM_TYPE'].'</td>
                            </tr>
                            <tr>
                            <td><b>PHONE NUMBER</b></td>
                            <td>'.$row['PHONE_NUMBER'].'</td> 
                            <td><b>AC/NOT</b></td>
                            <td>'.$row['AC_OR_NOT'].'</td>
                            </tr>
                            <tr>
                            <td><b>USERNAME</b></td>
                            <td>'.$row['USER_NAME'].'</td>
                            <td><b>RENT/SALE</b></td>
                            <td>'.$row['RENT_OR_SALE'].'</td>
                            </tr>
                            <tr>
                            <td><b>COUNTRY</b></td>
                            <td>'.$row['COUNTRY'].'</td>
                            <td><b>STATUS</b></td>
                            <td>'.$row['STATUS'].'</td>
                            </tr>
                            <tr>
                            <td style="height:30px" ><b>DESCRIPTION</b></td>
                            <td>'.$row['DESCRIPTION'].'</td>
                            <td><b>STATE</b></td>
                            <td>'.$row['STATE'].'</td>
                            </tr>
                            <tr>
                            <td></td>
                            <td></td>
                            <td><b>CITY</b></td>
                            <td>'.$row['CITY'].'</td>
                            </tr>
                            <tr>
                            <td></td>
                            <td></td>
                            <td><b>ADDRESS</b></td>
                            <td>'.$row['ADDRESS'].'</td>
                            </tr>
                            <tr>
                            <td></td>
                            <td></td>
                            <td><b>PINCODE</b></td>
                            <td>'.$row['PINCODE'].'</td>
                            </tr>
                            <tr>
                            <td></td>
                            <td></td>
                            <td><b>LANDMARK</b></td>
                            <td>'.$row['LANDMARK'].'</td>
                            </table>
                        
                             </div>';
                            
                        }
                        echo '<br<br><br>';
                        }
                        else{
                           echo '<center><h1>Oops ! NO HOUSES FOUND </h1></center> ';
                        }
                        
                        
                        
                        }




                    }






















else if($_POST['all']=='search_all_houses'){

    $link = mysqli_connect('localhost', 'root', '', 'house_rent');  
    if(!$link)
    { 
    die('Failed to connect to server: ');
    } 
    $qry = "SELECT  FULL_NAME,EMAIL,PHONE_NUMBER,COUNTRY,STATE,CITY,ADDRESS,DESCRIPTION,FACILITIES,PINCODE,LANDMARK,AC_OR_NOT,ROOM_TYPE,STATUS,RENT_OR_SALE,USER_NAME,HOUSE_NO FROM sellers WHERE 1 AND STATUS='Vacant'";

    $result=mysqli_query($link,$qry);
   
    if(mysqli_num_rows($result)>0){
     
    echo '<center><h1>HOUSES ARE  - </h1></center>';

    while ($row = mysqli_fetch_assoc($result))
    {

  echo'<div class="perfect" >
    <table style="width:100%" > 
    <tr>
    <th colspan="2">OWNER DETAILS</th>
    <th colspan="2">ROOM DETAILS</th>
    </tr>

    <tr>
    <td> <b>FULL NAME : </b> </td> 
    <td>'.$row['FULL_NAME'].'</td>
    <td><b>HOUSE NO : </b></td>
    <td>'.$row['HOUSE_NO'].'</td>
    </tr>
    <tr>
    <td><b>EMAIL :<b></td>
    <td>'.$row['EMAIL'].'</td> 
    <td><b>ROOM TYPE</b></td>
    <td>'.$row['ROOM_TYPE'].'</td>
    </tr>
    <tr>
    <td><b>PHONE NUMBER</b></td>
    <td>'.$row['PHONE_NUMBER'].'</td> 
    <td><b><AC/NOT</b></td>
    <td>'.$row['AC_OR_NOT'].'</td>
    </tr>
    <tr>
    <td><b>USERNAME</b></td>
    <td>'.$row['USER_NAME'].'</td>
    <td><b>RENT/SALE</b></td>
    <td>'.$row['RENT_OR_SALE'].'</td>
    </tr>
    <tr>
    <td><b>COUNTRY</b></td>
    <td>'.$row['COUNTRY'].'</td>
    <td><b>STATUS</b></td>
    <td>'.$row['STATUS'].'</td>
    </tr>
    <tr>
    <td style="height:30px" ><b>DESCRIPTION</b></td>
    <td>'.$row['DESCRIPTION'].'</td>
    <td><b>STATE</b></td>
    <td>'.$row['STATE'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td><b>CITY</b></td>
    <td>'.$row['CITY'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td><b>ADDRESS</b></td>
    <td>'.$row['ADDRESS'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td><b>PINCODE</b></td>
    <td>'.$row['PINCODE'].'</td>
    </tr>
    <tr>
    <td></td>
    <td></td>
    <td><b>LANDMARK</b></td>
    <td>'.$row['LANDMARK'].'</td>
    </table>

     </div>';
    
}
 echo '<br><br><br>';
}
else{
    echo '<center><h1>Oops ! NO HOUSES FOUND </h1></center> ';
 }
}
      


?>




</body>
</html>
&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;












<!DOCTYPE html>
<html>
<head>
<style>
 .firsttable{
 width=55%;
 }
 .secondtable{
 background-color:orange;
 text-align:center;
 padding:10px;
 border:1px solid black;
 }
 table,td,tr{       
	    margin-left:auto;
		margin-right:auto;
	   }
 #c1{
   color:blue;
   text-align:center;
   }
   .about-section {
     display:block;
  padding:50px;
  text-align: center;
  background-color: #474e5d;
  color: white;
  }
  div.ex1 {
  width:100px;
  background-color: yellow;
  text-align:center;
}

div.ex2 {
  width: 400px;
  padding: 25px;
  box-sizing: border-box;
  background-color: lightblue;
  
}

</head>
</style>


<body>



<table class="firsttable">

 <tr>
   <td style="padding-right: 80px;"><img src="https://image.shutterstock.com/image-vector/family-moving-countryside-area-realtor-260nw-1559004740.jpg" alt="APK file" </td>
   <td style="padding-right: 80px;"><img src="https://image.shutterstock.com/image-photo/classic-house-model-on-sale-260nw-1590287107.jpg" alt="APK file" </td>
   <td style="padding-right: 80px;"><img src="https://img.staticmb.com/mbimages/project/Photo_h310_w462/2021/02/10/Project-Photo-7-GP-Elegant-Castle-Chennai-5230041_600_800_310_462.jpg" alt="APK file" </td>
   </tr>
   </table>
   
 <h3 id="c1" style="font-size:35px;" >VIDEO REVIEW FOR NEW USERS</h3>
  <center> <iframe width="560" height="315" src="https://www.youtube.com/embed/u4Ad6OfXuz4" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></center>
  <h3 id="c1" style="font-size:30px;" >OUR SERVICES TO USERS</h3>
  <table class="secondtable">
  <tr>
  <th>BUY</th>
  <th>RENT</th>
  </tr>
  <tr>
  <td>Buy a home</td>
  <td>Rent a home</td>
  </tr>
  <tr>
  <td>Buy an appartment</td>
  <td>Rent an appartment</td>
  </tr>
  <tr>
  <td>Hostels for students</td>
  <td>commercial appartments</td>
  </tr>
  </table>
  <br><br>  
<br>

</body>
</html>









































