<!DOCTYPE html>
<html lang="en">
<head>
    <style>
        h1
        {
            color:black;
            text-align:center;
            padding:100px;
            padding-bottom:20px;
        }
        a
        {
            text-align:center;
            text-decoration:none;
            font-size:25px;
            padding-left:650px;
            padding-bottom:20px;
        }
        </style>
</head>
<body>
    <h1>Please Enter Valid UserName and Password and Role....</h1>
    <a href="http://localhost/House_rental/Login.php">Login Here</a>
    <h1>Don't Have a Account....</h1>
    <a href="http://localhost/House_rental/Login.php">Sign Up</a>
</body>