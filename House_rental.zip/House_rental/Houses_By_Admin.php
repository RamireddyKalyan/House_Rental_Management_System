<!DOCTYPE html>
<html>
<head>
<style>

h1
        {
            text-align:center;
        }
        table.H
        {
           position: relative;
           left:0px;
           border-collapse:collapse;
        }
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color:rgb(119, 240, 220);
  border:1px solid black;
  border-collapse: collapse;
}

li {
  border:1px solid black;
   width:150px;
  text-align:center;
  font-weight: bold;
  float: left;
  border-collapse: collapse;
}

li a, .dropbtn {
  display: inline-block;
  color:rgb(17, 14, 14);
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}
li a:hover, .dropdown:hover .dropbtn {
  background-color: rgb(97, 185, 219);
  width:117px;
}

li.dropdown {
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #A0DAA9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {
  width:83%;
  background-color: #f1b4f1;}

.dropdown:hover .dropdown-content {
  display: block;
}

.start{
            border:1px solid black;
            background-color: #B55A30;
            display:block;
            text-align: center;
        }
        table,th{
        border-color:blue;
        border:2px solid black;
        border-collapse: collapse;
  
      }
    th,td{
      padding:20px;
    }
   tr:nth-child(even){ 
  background-color:#eee;
  }
  tr:nth-child(odd){
  background-color:#fff;
  }
      th{
        background-color: rgb(209, 186, 214);
     }
     .button {
        background-color: skyblue;
        border: 2px solid black;
        padding: 8px 8px;
        text-align: center;
        text-decoration: none;
        color:red;
        width:170px;
        display: inline-block;
        font-size:20px;
    }
    .perfect{
      margin:50px 60px;
      float:left;
    }
</style>
</head>
<body>

  <div class="start"> <h2> RENTAL HOUSE MANAGEMENT SYSTEM </h2></div>
<ul>
  <li><a href="Houses_By_Admin.php"><img src="http://localhost/House_rental/Images/House_image.png" style="width:25px; height:25px;">

Houses</a></li>
  <li><a href="Contracts.php"><img src="http://localhost/House_rental/Images/contract.png" style="width:25px; height:25px;">

Contracts</a></li>
  <li><a href="Sellers_By_Admin.php"><img src="http://localhost/House_rental/Images/group.png" style="width:25px; height:25px;" >
Sellers</a></li>
  <li><a href="Tenents_By_Admin.php"><img src="http://localhost/House_rental/Images/group.png" style="width:25px; height:25px;" >
Tenents</a></li>
  <li><a href="Payments_By_Admin.php"><img src="http://localhost/House_rental/Images/payment.png" style="width:25px; height:25px;" >
Payments</a></li>
  <li><a href="Complaints_By_Admin.php"><img src="http://localhost/House_rental/Images/complaint.png" style="width:25px; height:25px;" >

Complaints</a></li>
  <li class="dropdown" style="float:right;">
  <?php
  session_start();
  $Name=$_SESSION['Uname'];  
  echo '<a href="#" class="dropbtn"><img src="http://localhost/House_rental/Images/user.png" style="width:25px; height:25px;" >
  '.$Name.'</a>';

?>


  <div class="dropdown-content">
      <a href="Start.php">Sign out</a>
    </div>
  </li>
</ul>

<?php 


 /*Connect to mysql server*/ 
$link = mysqli_connect('localhost', 'root', '', 'house_rent');  

/*Check link to the mysql server*/ 
if(!$link)
{ 
die('Failed to connect to server: ');
 } 

 /*Create query*/ 
$qry = 'SELECT *  FROM sellers'; 

/*Execute query*/ 
$result = mysqli_query($link, $qry);
if(mysqli_num_rows($result)>0){
echo '<h1>The House Details are - </h1>';

 /*Draw the table for Players*/ 
 while ($row = mysqli_fetch_assoc($result))
  {

    if($row['RENT_OR_SALE']=='Rent'){

      echo '<center><table style="width:75%" > 
      <tr>
      <th colspan="2">OWNER DETAILS</th>
      <th colspan="2">ROOM DETAILS</th>
      </tr>
    
      <tr>
      <td> FULL NAME </td> 
      <td>'.$row['FULL_NAME'].'</td>
      <td>HOUSE NO</td>
      <td>'.$row['HOUSE_NO'].'</td>
      </tr>
      <tr>
      <td>EMAIL</td>
      <td>'.$row['EMAIL'].'</td> 
      <td>ROOM TYPE</td>
      <td>'.$row['ROOM_TYPE'].'</td>
      </tr>
      <tr>
      <td>PHONE NUMBER</td>
      <td>'.$row['PHONE_NUMBER'].'</td> 
      <td>AC/NOT</td>
      <td>'.$row['AC_OR_NOT'].'</td>
      </tr>
      <tr>
      <td>USERNAME</td>
      <td>'.$row['USER_NAME'].'</td>
      <td>RENT/SALE</td>
      <td>'.$row['RENT_OR_SALE'].'</td>
      </tr>
      <tr>
      <td>COUNTRY</td>
      <td>'.$row['COUNTRY'].'</td>
      <td>STATUS</td>
      <td>'.$row['STATUS'].'</td>
      </tr>
      <tr>
      <td style="height:30px" >DESCRIPTION</td>
      <td>'.$row['DESCRIPTION'].'</td>
      <td>STATE</td>
      <td>'.$row['STATE'].'</td>
      </tr>
      <tr>
      <td rowspan="4">
        <img src="http://localhost/House_rental/Images/'.$row['IMAGE'].'" width="200px" height="200px" >
        </td>
      <td></td>
      <td>CITY</td>
      <td>'.$row['CITY'].'</td>
      </tr>

      <tr>
      <td></td>
      <td>ADDRESS</td>
      <td>'.$row['ADDRESS'].'</td>
      </tr>

      <tr>
      <td></td>
      <td>RENT PER DAY </td>
      <td>'.$row['RENTPRICE'].'</td>
      </tr>
      <tr>
      <td></td>
      <td>PINCODE</td>
      <td>'.$row['PINCODE'].'</td>
      </tr>

      <tr>
      <td><a class="button" href="tenent_registration(rent).php">Rent</a></td>
      <td><a class="button" href="Update_Delete_House.php">Delete</a></td>
      <td>LANDMARK</td>
      <td>'.$row['LANDMARK'].'</td>
      </table> </center>';
      }
      else{
       
        echo '<center><table style="width:75%" > 
        <tr>
        <th colspan="2">OWNER DETAILS</th>
        <th colspan="2">ROOM DETAILS</th>
        </tr>
      
        <tr>
        <td> FULL NAME </td> 
        <td>'.$row['FULL_NAME'].'</td>
        <td>HOUSE NO</td>
        <td>'.$row['HOUSE_NO'].'</td>
        </tr>
        <tr>
        <td>EMAIL</td>
        <td>'.$row['EMAIL'].'</td> 
        <td>ROOM TYPE</td>
        <td>'.$row['ROOM_TYPE'].'</td>
        </tr>
        <tr>
        <td>PHONE NUMBER</td>
        <td>'.$row['PHONE_NUMBER'].'</td> 
        <td>AC/NOT</td>
        <td>'.$row['AC_OR_NOT'].'</td>
        </tr>
        <tr>
        <td>USERNAME</td>
        <td>'.$row['USER_NAME'].'</td>
        <td>RENT/SALE</td>
        <td>'.$row['RENT_OR_SALE'].'</td>
        </tr>
        <tr>
        <td>COUNTRY</td>
        <td>'.$row['COUNTRY'].'</td>
        <td>STATUS</td>
        <td>'.$row['STATUS'].'</td>
        </tr>
        <tr>
        <td style="height:30px" >DESCRIPTION</td>
        <td>'.$row['DESCRIPTION'].'</td>
        <td>STATE</td>
        <td>'.$row['STATE'].'</td>
        </tr>

        <tr>
        <td rowspan="4">
        <img src="http://localhost/House_rental/Images/'.$row['IMAGE'].'" width="200px" height="200px" >
        </td>
        <td></td>
        <td>CITY</td>
        <td>'.$row['CITY'].'</td>
        </tr>
        <tr>
        
        <td></td>
        <td>ADDRESS</td>
        <td>'.$row['ADDRESS'].'</td>
        </tr>

        <tr>
        <td></td>
        <td>SELLING PRICE</td>
        <td>'.$row['SELLINGPRICE'].'</td>
        </tr>
        <tr>
        <td></td>
        <td>PINCODE</td>
        <td>'.$row['PINCODE'].'</td>
        </tr>
        <tr>
        <td><a class="button" href="tenent_registration(buy).php">Sale</a></td>
        <td><a class="button" href="Update_Delete_House.php">Delete</a></td>
        <td>LANDMARK</td>
        <td>'.$row['LANDMARK'].'</td>
        </table> </center>';
    
      }
      echo '<br><br><br><br><br><br><br>';
    }
  
  

}
else{
  echo '<center><h1>Oops ! NO HOUSES FOUND </h1></center> ';
}

?>


</body>
</html>




















