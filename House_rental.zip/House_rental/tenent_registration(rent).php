<?php 
//session_start(); 
?>  
<!DOCTYPE html>   
<html>   
<head>  
<meta name="viewport" content="width=device-width, initial-scale=1">  
<title> Tenant Registration Form (Rent)</title>  
<style>   

Body {  
  font-family: Calibri, Helvetica, sans-serif;  
  background-color:skyblue;  
}  
  
  .label{
      font-weight: bold;
      font-size: 20px;
  }
  
   input{   

        width: 80%;   
        margin: 8px 0;  
        padding: 10px 00px;   
        display: inline-block;   
        border: 2px solid blue; 
        box-sizing: border-box;
        border-radius:15px;
        text-align: center;
    }  

    input[type="submit"]{     
        width: 20%;  
        background-color:skyblue;
        color: red;   
        padding: 10px;   
        font-size:17px;
        font-weight:bold;
        margin: 10px 0px;   
        border: 1px solid black;   
        cursor: pointer; 
        border-radius:10px;
         }   

    td,tr{
    size:15px;
    border-radius:15px;
    }

    form
    {
          background-color: rgb(232, 238, 234);
          padding-left: 50px;
          padding-right: 0px;
          padding-top: 50px;
          padding-bottom: 50px;
          width:75%;

    }

</style>   
</head>    
<body>

    <center> <h1> TENANT REGISTRATION (Rent)</h1> </center>
   <center> <form method="post" action="Save_Tenants_Rent.php">  
    <table>
         <tr>  
            <td><label class ="label" for="a">Full Name</label> <br>    
                <input type="text" id="a" placeholder="Full name" size="50px" name="full_name" ></td>  
    
            <td><label  class="label" for="b">Email</label><br>
                <input type="email" id="b" placeholder="Email" name="email" size="50px" ></td>

            <td><label  class="label" >Phone number</label><br>
                <input type="text" placeholder="10 digits phone number " name="phone_number" size="50px" ></td>
         </tr>
              
            
        <tr>
            <td><label  class="label" >Seller User Name</label><br>
                <input type="text" placeholder="Seller user name" name="sell_username" size="50px" ></td>
                <td><label  class="label" >Your User name </label><br>
                    <input type="text" placeholder="your user name" name="user_name" size="50px" ></td>
                    <td><label  class="label" >Aadhar card No : </label><br>
                        <input type="number" placeholder="enter Aadhar number" name="aadhar_number" size="50px" ></td>
        </tr>

        <tr>
            <td><label  class="label" >Occupation</label><br>
                <input type="text" placeholder="current job" name="occupation" size="50px" ></td>
                <td><label  class="label" >House No: </label><br>
                    <input type="text" placeholder="House No" name="house_no" size="50px" ></td>
                    <td><label  class="label" >No of days</label><br>
                        <input type="number" placeholder="Enter number of days u would like to stay" name="days" size="50px" ></td>
        </tr>
        
        <tr>
            <td><label  class="label" >State</label><br>
                <input type="text" placeholder="Enter your state" name="state" size="50px" ></td>
                <td><label  class="label" >City/Region</label><br>
                    <input type="text" placeholder="Name of the home town " name="city" size="50px" ></td>
                    <td><label  class="label" >Pincode</label><br>
                        <input type="number" placeholder="pincode" name="pincode" size="50px" ></td>
        </tr>

        
         
         </table>

     <center>  <input  type="submit" name="To_Rent" value="Request Owner"></center>  
     
    </form>     </center>
</body>     
</html>  